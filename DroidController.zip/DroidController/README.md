# DroidController

Turns an Android phone into a Bluetooth game controller. Bluetooth only: the app has no network permission. The other device (phone, tablet, PC) sees a gamepad
and needs nothing installed.

## Build

Open this folder in Android Studio (Koala or newer), or push it to GitHub and let the **Build** workflow
(`.github/workflows/build.yml`) produce the APK: Actions tab, open the run, download *DroidController-debug-apk*.
Needs Android 9 (API 28) or newer on the controller phone.

## Use

1. Pick a profile, then **1. Turn on Bluetooth gamepad**, **2. Make this phone discoverable**.
2. On the other device, pair this phone in Bluetooth settings as a game controller. If it doesn't connect by
   itself, press **3. Connect to a paired device**.
3. **Start controller**. A "● Connected" banner shows for a few seconds once the link is up.

## Profiles and the layout editor

Built in: **Xbox**, **PlayStation**, **Switch** (full on-screen pads with that console's layout and labels) and
**Racing (tilt)** (almost empty screen: tilt steers, big left/right pedals, volume keys = A and B).

**Edit layout & mapping** opens the controller in edit mode. Nothing is added, every control already exists:

- **Drag** to move a control, **pinch** (or − / +) to resize it.
- **Remap** picks what it sends: any gamepad button, trigger, stick or D-pad. A stick can act as the D-pad and
  the D-pad can act as a stick.
- **Toggle** (on a selected button): tap once to press and keep it held, tap again to release. Good for sprint, gas or
  crouch. Toggle buttons show a small green dot (filled while held). Held toggles are released when you leave the
  controller screen. Not available for TURBO and macro buttons.
- **Hide / Show** removes controls you don't need (hidden ones show dashed in the editor).
- **Motion & keys** maps tilt and the volume keys, which have no spot on the screen.
- **Look** switches Xbox / PlayStation / Switch labels and colours. **Reset** restores the starting layout.
- **Save as…** keeps a copy under a new name. Changes are saved as you go.

In play mode a 3-finger tap recalibrates tilt.

## Touch controls (per profile)

Set from the main screen ("Touch controls") or the editor's **Touch** button. They are saved with the profile.

- **Touch look**: drag on the right half of the screen (anywhere that is not a button) to move the right stick. It works
  like a floating stick: the ring stays where your finger landed and follows if you drag past its edge. Sensitivity and
  invert Y are adjustable. The editor shows the zone as a dashed outline.
- **Floating left stick / Floating right stick**: the stick appears under your thumb anywhere on that half of the
  screen. The on-screen stick is then only used for its size and what it sends. Off = the normal fixed stick. Floating
  right stick and touch look share the right half, so turning one on turns the other off.
- **Lock left stick forward** (off by default): slide the left stick up into the lock ring and let go; it stays pushed
  forward (sprint / auto-run). Touch the left stick again to release it. In the editor, drag the lock ring up or down
  to set how far you have to drag; it stops at the top of the screen or at the first control in the way.

## Touchpad

A **TOUCHPAD** control (hidden by default: Edit layout, tap TOUCHPAD, Show) that you can move and resize like any other
control. Swipe on it like a trackpad: the swipe speed moves the right stick (or the left stick, see Remap) and the stick
eases back to centre when your finger stops, so it works as a mouse-style camera. Sensitivity and invert Y are the same
"Look" options as touch look. A quick tap presses a button of your choice (select the pad, **Tap: …**; nothing by default).

**Remap → Real touchpad** turns the pad into an actual touchpad for the other device: instead of moving a stick, your
finger's position on the pad is sent as a touch, so the other device lists a touchpad and moves its pointer when you
swipe. It follows the same rules as every other control: hidden until you show it, move / resize / hide in the editor,
saved with the profile, skin colours, vibration and press effects. The tap button still works.

To use it, switch on **Report a real touchpad** in the Bluetooth section of the main screen, then press **1. Turn on
Bluetooth gamepad** again. It is off by default because it changes what the other device sees (a touchpad next to the
gamepad). Hosts remember what a paired device is, so if the touchpad doesn't show up, forget this phone on the other
device and pair it again. The pad shows a hint if you touch it while the switch is off.

Notes: a real touchpad is absolute, so the other device decides the pointer speed (Sensitivity and invert Y don't apply),
and macros don't record it (they record sticks, tilt and buttons). It is a generic one-finger touchpad, not a DualShock /
DualSense one: Android does not let an app pose as a PlayStation controller, so games that look for that exact touchpad
will not detect it. Which hosts treat it as a touchpad depends on the host (Linux and Android hosts accept this kind;
Windows may treat it as a basic touch device). With the switch off or the pad on a stick, the other device sees only
stick and button input.

## Button icons

In the editor, select a button and tap **Icon** to show a picture instead of its text: Jump, Sprint, Crouch, Slide,
Prone, Shoot, Aim, Reload, Melee, Grenade, Weapon swap, Block, Ability, Interact, Inventory, Map, Heal, Flashlight,
Vehicle, Ping, Gas, Brake, Nitro, Handbrake. Icons only change how a button looks, what it sends is still set with
**Remap**. They follow the skin's colours (including Neon's glow). The Racing profile starts with Brake and Gas icons.

## Skins, effects, turbo, macros, vibration

- **Look** (main screen, or Look in the editor): Xbox, PlayStation, Switch, **Retro (SNES)**, **Neon**, **Minimal**,
  **Terminal**.
- **Animation**: what a button does when pressed. None, Shrink, Glow, Ripple, Bounce.
- **Vibration**: Off / Light / Medium / Strong when you press a button. Only shown if the phone has a vibrator.
- **Turbo**: switch it on in the app and set the speed (one press every N ms). In game, **hold** the button you want
  and tap the **TURBO** button (hidden by default: Edit layout, tap TURBO, Show). Tap again while holding to turn it off.
  Turbo buttons show a small yellow T.
- **Macros**: Record on the main screen starts the controller in recording mode. Recording begins at your first
  input; sticks, tilt and buttons are all captured. Stop & save (or Back) ends it. Then map any button, or a volume
  key, to **Macro 1-4** with Remap, or show the hidden **M1-M4** buttons. Press a macro button to play it,
  press again to stop it.

## What the other device sees

A generic Bluetooth gamepad with the Xbox One S button layout. Android does not let apps set the vendor and product
ID, so it is not literally an Xbox controller. It works for Android games and most PC games (DirectInput, SDL, Steam
Input). Games that only accept XInput can be helped with Steam Input. Consoles and iPhone/iPad do not accept it.
Some phone makers block Bluetooth gamepad mode.

## Files

- `Model.kt` buttons, controls, profiles, what each control can send
- `ProfileStore.kt` saved profiles and the built-in layouts
- `BtHid.kt` Bluetooth gamepad (descriptor, registration, reports, optional real touchpad)
- `ControllerView.kt` draws a layout; plays it or edits it
- `ControllerActivity.kt` play screen and tilt. `EditorActivity.kt` layout editor
- `Settings.kt` (animation, vibration, turbo options and haptics), `Macros.kt` (macro slots)
- `MainActivity.kt`, `Skins.kt` (skin colours and labels), `Ui.kt`
