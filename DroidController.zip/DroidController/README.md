# DroidController

Turns an Android phone into a Bluetooth game controller. Bluetooth only: the app has no network permission. The other device (phone, tablet, PC) sees a gamepad
and needs nothing installed.

## Build

Open this folder in Android Studio (Koala or newer), or push it to GitHub and let the **Build** workflow
(`.github/workflows/build.yml`) produce the APK: Actions tab, open the run, download *DroidController-debug-apk*.
Needs Android 9 (API 28) or newer on the controller phone.

## Use

The home screen has four tabs. The profile picker, the connection pill and **Start controller** are always visible.

- **Startup**: the three Bluetooth steps (**1 Turn on**, **2 Discoverable**, **3 Connect…**), plus *Turn on Bluetooth
  automatically* and *Also appear as a mouse*.
- **Look & feel**: skin, press animation, vibration.
- **Controls**: touch options, mouse touchpad, turbo, macros (a dropdown with Record / Clear).
- **Editor**: opens the layout editor, and switches for the hidden extras (TURBO, M1–M4, stick touchpad, mouse touchpad).

1. Pick a profile, then **1 Turn on** and **2 Discoverable**.
2. On the other device, pair this phone in Bluetooth settings as a game controller. If it doesn't connect by
   itself, press **3 Connect…**.
3. **Start controller**. A "● Connected" banner shows for a few seconds once the link is up.

## Profiles and the layout editor

Built in: **Xbox**, **PlayStation**, **Switch** (full on-screen pads with that console's layout and labels) and
**Racing (tilt)** (almost empty screen: tilt steers, big left/right pedals, volume keys = A and B).

**Edit layout & mapping** (Editor tab) opens the controller in edit mode. The toolbar has Look, Touch, Mouse,
Motion & keys, More (Save as, Reset, Delete) and Done. Nothing is added, every control already exists:

- **Drag** to move a control, **pinch** (or − / +) to resize it.
- **Remap** picks what it sends: any gamepad button, trigger, stick or D-pad. A stick can act as the D-pad and
  the D-pad can act as a stick.
- **Toggle** (on a selected button): tap once to press and keep it held, tap again to release. Good for sprint, gas or
  crouch. Toggle buttons show a small green dot (filled while held). Held toggles are released when you leave the
  controller screen. Not available for TURBO and macro buttons.
- **Hide / Show** removes controls you don't need (hidden ones show dashed in the editor).
- **Motion & keys** maps tilt and the volume keys, which have no spot on the screen.
- **Look** switches Xbox / PlayStation / Switch labels and colours. **Reset** restores the starting layout.
- **Save as…** keeps a copy under a new name. Changes are saved as you go.

In play mode a 3-finger tap recalibrates tilt.

## Touch controls (per profile)

Set from the **Controls** tab (Touch card) or the editor's **Touch** button. They are saved with the profile.

- **Touch look**: drag on the right half of the screen (anywhere that is not a button) to move the right stick. It works
  like a floating stick: the ring stays where your finger landed and follows if you drag past its edge. Sensitivity and
  invert Y are adjustable. The editor shows the zone as a dashed outline.
- **Floating left stick / Floating right stick**: the stick appears under your thumb anywhere on that half of the
  screen. The on-screen stick is then only used for its size and what it sends. Off = the normal fixed stick. Floating
  right stick and touch look share the right half, so turning one on turns the other off.
- **Lock left stick forward** (off by default): slide the left stick up into the lock ring and let go; it stays pushed
  forward (sprint / auto-run). Touch the left stick again to release it. In the editor, drag the lock ring up or down
  to set how far you have to drag; it stops at the top of the screen or at the first control in the way.

## Mouse touchpad (Bluetooth mouse)

A real touchpad that moves the cursor on the other device. It is a **MOUSEPAD** control, so it follows the layout
rules: move, resize, hide / show, remap (Mouse or Nothing) and skins all work, and it works at the same time as the
gamepad. It is hidden by default: **Controls** tab → Mouse touchpad → *Show on screen* (or Editor tab, or Edit layout →
MOUSEPAD → Show).

- **One finger**: moves the cursor (with optional pointer acceleration).
- **Tap**: left click. **Two-finger tap**: right click. **Three-finger tap**: middle click.
- **Tap, then touch again and drag**: holds the left button (drag, select, move windows). Lift to let go.
- **Two-finger swipe**: scroll up / down / sideways. *Natural scrolling* flips the direction.
- **Click buttons (L / R strip)**: an optional strip along the bottom of the pad that works like physical touchpad
  buttons. Hold one with a thumb and move with another finger.

Options (per profile): cursor speed, pointer acceleration, tap to click, natural scrolling, click buttons. They are in
the **Controls** tab and in the editor's **Mouse** button.

The gamepad and the mouse are one Bluetooth device. *Also appear as a mouse* (Startup tab, on by default) adds the
mouse to it. **Pair again after changing that switch**: the other device remembers what the phone was when it first
paired, so forget the phone in its Bluetooth list and pair once more. Android hosts show a mouse cursor while a mouse is
connected, so switch it off if you only want a gamepad. Mouse movement is not recorded by macros.

## Stick touchpad

A **TOUCHPAD** control (hidden by default: Edit layout, tap TOUCHPAD, Show) that you can move and resize like any other
control. Swipe on it like a trackpad: the swipe speed moves the right stick (or the left stick, see Remap) and the stick
eases back to centre when your finger stops, so it works as a mouse-style camera. Sensitivity and invert Y are the same
"Look" options as touch look. A quick tap presses a button of your choice (select the pad, **Tap: …**; nothing by default).

The other device sees stick and button input, not a real touchpad: Android does not let an app pose as a PlayStation
controller, so games or apps that specifically look for a DualShock / DualSense touchpad will not detect one.

## Button icons

In the editor, select a button and tap **Icon** to show a picture instead of its text: Jump, Sprint, Crouch, Slide,
Prone, Shoot, Aim, Reload, Melee, Grenade, Weapon swap, Block, Ability, Interact, Inventory, Map, Heal, Flashlight,
Vehicle, Ping, Gas, Brake, Nitro, Handbrake. Icons only change how a button looks, what it sends is still set with
**Remap**. They follow the skin's colours (including Neon's glow). The Racing profile starts with Brake and Gas icons.

## Skins, effects, turbo, macros, vibration

- **Look & feel** tab (or Look in the editor): Xbox, PlayStation, Switch, **Retro (SNES)**, **Neon**, **Minimal**,
  **Terminal**.
- **Animation**: what a button does when pressed. None, Shrink, Glow, Ripple, Bounce.
- **Vibration**: Off / Light / Medium / Strong when you press a button. Only shown if the phone has a vibrator.
- **Turbo**: switch it on in the app and set the speed (one press every N ms). In game, **hold** the button you want
  and tap the **TURBO** button (hidden by default: Edit layout, tap TURBO, Show). Tap again while holding to turn it off.
  Turbo buttons show a small yellow T.
- **Macros**: Record (Controls tab) starts the controller in recording mode. Recording begins at your first
  input; sticks, tilt and buttons are all captured. Stop & save (or Back) ends it. Then map any button, or a volume
  key, to **Macro 1-4** with Remap, or show the hidden **M1-M4** buttons. Press a macro button to play it,
  press again to stop it.

## What the other device sees

A generic Bluetooth gamepad with the Xbox One S button layout (plus a standard relative mouse with scroll wheel and
horizontal scroll, if the mouse is on). Android does not let apps set the vendor and product
ID, so it is not literally an Xbox controller. It works for Android games and most PC games (DirectInput, SDL, Steam
Input). Games that only accept XInput can be helped with Steam Input. Consoles and iPhone/iPad do not accept it.
Some phone makers block Bluetooth gamepad mode.

## Files

- `Model.kt` buttons, controls, profiles, what each control can send (including the mouse touchpad options)
- `ProfileStore.kt` saved profiles and the built-in layouts
- `BtHid.kt` Bluetooth gamepad + mouse (descriptors, registration, reports)
- `ControllerView.kt` draws a layout; plays it or edits it; holds the mouse touchpad gestures
- `ControllerActivity.kt` play screen and tilt. `EditorActivity.kt` layout editor
- `Settings.kt` (animation, vibration, turbo options and haptics), `Macros.kt` (macro slots)
- `MainActivity.kt` (tabbed home screen), `Skins.kt` (skin colours and labels), `Ui.kt` (cards, sliders, option lists)
