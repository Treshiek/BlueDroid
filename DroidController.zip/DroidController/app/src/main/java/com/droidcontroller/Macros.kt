package com.droidcontroller

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** The gamepad at one moment of a recording, [t] = milliseconds since the first input. */
class MacroFrame(
    val t: Long, val buttons: Int, val hat: Int,
    val lx: Float, val ly: Float, val rx: Float, val ry: Float, val lt: Float, val rt: Float
)

class Macro(val frames: List<MacroFrame>, val durationMs: Long)

/** Four macro slots, saved as JSON. */
class MacroStore(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("droidcontroller", Context.MODE_PRIVATE)

    fun get(n: Int): Macro? {
        val raw = sp.getString("macro$n", null) ?: return null
        return runCatching {
            val o = JSONObject(raw)
            val a = o.getJSONArray("f")
            val frames = (0 until a.length()).map {
                val f = a.getJSONArray(it)
                MacroFrame(f.getLong(0), f.getInt(1), f.getInt(2),
                    f.getDouble(3).toFloat(), f.getDouble(4).toFloat(), f.getDouble(5).toFloat(),
                    f.getDouble(6).toFloat(), f.getDouble(7).toFloat(), f.getDouble(8).toFloat())
            }
            Macro(frames, o.getLong("d"))
        }.getOrNull()?.takeIf { it.frames.isNotEmpty() }
    }

    fun save(n: Int, m: Macro) {
        val arr = JSONArray()
        m.frames.forEach {
            arr.put(JSONArray(listOf(it.t, it.buttons, it.hat, it.lx.toDouble(), it.ly.toDouble(),
                it.rx.toDouble(), it.ry.toDouble(), it.lt.toDouble(), it.rt.toDouble())))
        }
        sp.edit().putString("macro$n", JSONObject().put("d", m.durationMs).put("f", arr).toString()).apply()
    }

    fun clear(n: Int) { sp.edit().remove("macro$n").apply() }
}
