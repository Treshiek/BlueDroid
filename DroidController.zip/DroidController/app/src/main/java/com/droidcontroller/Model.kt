package com.droidcontroller

/**
 * Buttons by *position* (not by label), so every skin sends identical data.
 * [bit] is the bit index inside the 15-button HID report. The numbering follows
 * the Xbox One S Bluetooth layout, which Android's generic gamepad key layout understands:
 * button 1=A, 2=B, 4=X, 5=Y, 7=LB, 8=RB, 11=View, 12=Menu, 13=Guide, 14=LS, 15=RS.
 */
enum class Btn(val bit: Int) {
    SOUTH(0), EAST(1), WEST(3), NORTH(4),
    LB(6), RB(7),
    VIEW(10), MENU(11), GUIDE(12),
    LS(13), RS(14)
}

enum class Skin { XBOX, PLAYSTATION, SWITCH, RETRO, NEON, MINIMAL, TERMINAL }

/**
 * What a control is. BUTTON, STICK and DPAD are drawn on screen.
 * KEY (volume keys) and AXIS (tilt) are physical inputs: not drawn, but they can be remapped.
 */
enum class Kind { BUTTON, STICK, DPAD, KEY, AXIS }

/**
 * One control on the layout. Position is the centre as a fraction of the screen (0..1),
 * [size] is the radius as a fraction of screen height, [out] is what it sends (see [Outputs]).
 */
data class Control(
    val id: String,
    val kind: Kind,
    val x: Float,
    val y: Float,
    val size: Float,
    val visible: Boolean,
    val out: String,
    /** Optional picture drawn instead of the text label (see [Icons]); "" = text. Only changes how it looks. */
    val icon: String = "",
    /** Toggle mode: tap once to press and keep it pressed, tap again to release (sprint, gas...). */
    val latch: Boolean = false
)

/**
 * Touch-screen extras, saved per profile.
 * [lookOn]: dragging on the right half of the screen (not on a control) moves the right stick.
 * [floatLeft]: the left stick appears wherever you touch on the left half of the screen.
 * [floatRight]: the same for the right stick on the right half (replaces touch look, they share that half).
 * [lockForward]: push the left stick up past the lock ring and it stays pushed forward after you let go (touch it again to release).
 */
data class TouchOpts(
    val lookOn: Boolean = false,
    val lookSens: Float = 1f,
    val lookInvertY: Boolean = false,
    val floatLeft: Boolean = false,
    val floatRight: Boolean = false,
    val lockForward: Boolean = false
)

data class Profile(
    val name: String,
    val skin: Skin,
    val controls: List<Control>,
    val touch: TouchOpts = TouchOpts()
)

/** One snapshot of a gamepad. Y axes: -1 = up, +1 = down (same as HID). */
class GamepadState {
    var buttons = 0
    /** 0 = neutral, 1=N 2=NE 3=E 4=SE 5=S 6=SW 7=W 8=NW */
    var hat = 0
    var lx = 0f
    var ly = 0f
    var rx = 0f
    var ry = 0f
    var lt = 0f
    var rt = 0f

    // Working fields, only used while a state is being assembled.
    var dpU = false
    var dpD = false
    var dpL = false
    var dpR = false

    fun press(b: Btn) { buttons = buttons or (1 shl b.bit) }

    /** Overlays one recorded macro frame on top of what the fingers are doing. */
    fun merge(f: MacroFrame) {
        buttons = buttons or f.buttons
        when (f.hat) {
            1 -> dpU = true
            2 -> { dpU = true; dpR = true }
            3 -> dpR = true
            4 -> { dpR = true; dpD = true }
            5 -> dpD = true
            6 -> { dpD = true; dpL = true }
            7 -> dpL = true
            8 -> { dpL = true; dpU = true }
        }
        lx += f.lx; ly += f.ly; rx += f.rx; ry += f.ry
        lt = maxOf(lt, f.lt); rt = maxOf(rt, f.rt)
    }

    /** Call once after all contributions are added. */
    fun finish() {
        hat = hatOf(dpU, dpD, dpL, dpR)
        lx = lx.coerceIn(-1f, 1f)
        ly = ly.coerceIn(-1f, 1f)
        rx = rx.coerceIn(-1f, 1f)
        ry = ry.coerceIn(-1f, 1f)
        lt = lt.coerceIn(0f, 1f)
        rt = rt.coerceIn(0f, 1f)
    }

    companion object {
        fun hatOf(up: Boolean, down: Boolean, left: Boolean, right: Boolean): Int {
            val u = up && !down
            val d = down && !up
            val l = left && !right
            val r = right && !left
            return when {
                u && r -> 2
                r && d -> 4
                d && l -> 6
                l && u -> 8
                u -> 1
                r -> 3
                d -> 5
                l -> 7
                else -> 0
            }
        }
    }
}

/** Everything a control can send. Codes are stored in profiles as text. */
object Outputs {
    class Out(val code: String, val label: String)

    private val off = Out("OFF", "Nothing")
    private val buttons = listOf(
        Out("SOUTH", "Bottom face button (A / ✕ / B)"),
        Out("EAST", "Right face button (B / ○ / A)"),
        Out("WEST", "Left face button (X / □ / Y)"),
        Out("NORTH", "Top face button (Y / △ / X)"),
        Out("LB", "Left bumper"),
        Out("RB", "Right bumper"),
        Out("LT", "Left trigger"),
        Out("RT", "Right trigger"),
        Out("VIEW", "View / Create / −"),
        Out("MENU", "Menu / Options / +"),
        Out("GUIDE", "Guide / PS / Home"),
        Out("LS", "Left stick click"),
        Out("RS", "Right stick click"),
        Out("DPAD_UP", "D-pad up"),
        Out("DPAD_DOWN", "D-pad down"),
        Out("DPAD_LEFT", "D-pad left"),
        Out("DPAD_RIGHT", "D-pad right")
    )

    private val macros = (1..4).map { Out("MACRO$it", "Macro $it (plays what you recorded)") }
    private val turbo = Out("TURBO", "Turbo toggle (hold a button, then tap this)")

    fun options(kind: Kind): List<Out> = when (kind) {
        Kind.BUTTON -> listOf(off) + buttons + turbo + macros
        Kind.KEY -> listOf(off) + buttons + macros
        Kind.STICK -> listOf(
            Out("STICK_LEFT", "Left stick"),
            Out("STICK_RIGHT", "Right stick"),
            Out("STICK_DPAD", "D-pad (stick pushes act as D-pad presses)"),
            off
        )
        Kind.DPAD -> listOf(
            Out("DPAD", "D-pad"),
            Out("DPAD_LSTICK", "Left stick (D-pad pushes act as the stick)"),
            Out("DPAD_RSTICK", "Right stick (D-pad pushes act as the stick)"),
            off
        )
        Kind.AXIS -> listOf(
            Out("AX_LX", "Left stick X"),
            Out("AX_LY", "Left stick Y"),
            Out("AX_RX", "Right stick X"),
            Out("AX_RY", "Right stick Y"),
            off
        )
    }

    fun isValid(kind: Kind, out: String) = options(kind).any { it.code == out }

    /** Short text drawn on a control. */
    fun display(skin: Skin, code: String): String {
        Btn.values().firstOrNull { it.name == code }?.let { return Skins.label(skin, it) }
        return when (code) {
            "LT" -> Skins.trigger(skin, true)
            "RT" -> Skins.trigger(skin, false)
            "DPAD_UP" -> "▲"
            "DPAD_DOWN" -> "▼"
            "DPAD_LEFT" -> "◀"
            "DPAD_RIGHT" -> "▶"
            "STICK_LEFT", "AX_LX", "AX_LY", "DPAD_LSTICK" -> "L-STICK"
            "STICK_RIGHT", "AX_RX", "AX_RY", "DPAD_RSTICK" -> "R-STICK"
            "STICK_DPAD" -> "D-PAD"
            "DPAD" -> "D-PAD"
            "OFF" -> "—"
            "TURBO" -> "TURBO"
            "MACRO1", "MACRO2", "MACRO3", "MACRO4" -> "M" + code.last()
            else -> code
        }
    }

    // --- Turning a control's state into input -------------------------------------------------

    fun pressButton(s: GamepadState, out: String) {
        when (out) {
            "OFF" -> {}
            "LT" -> s.lt = 1f
            "RT" -> s.rt = 1f
            "DPAD_UP" -> s.dpU = true
            "DPAD_DOWN" -> s.dpD = true
            "DPAD_LEFT" -> s.dpL = true
            "DPAD_RIGHT" -> s.dpR = true
            else -> Btn.values().firstOrNull { it.name == out }?.let { s.press(it) }
        }
    }

    private fun pushDpad(s: GamepadState, vx: Float, vy: Float, t: Float) {
        if (vy < -t) s.dpU = true
        if (vy > t) s.dpD = true
        if (vx < -t) s.dpL = true
        if (vx > t) s.dpR = true
    }

    fun moveStick(s: GamepadState, out: String, vx: Float, vy: Float) {
        when (out) {
            "STICK_LEFT" -> { s.lx += vx; s.ly += vy }
            "STICK_RIGHT" -> { s.rx += vx; s.ry += vy }
            "STICK_DPAD" -> pushDpad(s, vx, vy, 0.4f)
        }
    }

    fun moveDpad(s: GamepadState, out: String, vx: Float, vy: Float) {
        // A D-pad is pushed all the way or not at all, so the stick versions snap to full deflection.
        fun snap(v: Float) = if (v < -0.35f) -1f else if (v > 0.35f) 1f else 0f
        when (out) {
            "DPAD" -> pushDpad(s, vx, vy, 0.35f)
            "DPAD_LSTICK" -> { s.lx += snap(vx); s.ly += snap(vy) }
            "DPAD_RSTICK" -> { s.rx += snap(vx); s.ry += snap(vy) }
        }
    }

    fun axis(s: GamepadState, out: String, v: Float) {
        when (out) {
            "AX_LX" -> s.lx += v
            "AX_LY" -> s.ly += v
            "AX_RX" -> s.rx += v
            "AX_RY" -> s.ry += v
        }
    }
}
