package com.droidcontroller

/** Labels and colours that make the on-screen pad look like an Xbox, PlayStation or Switch controller. */
object Skins {
    fun label(skin: Skin, b: Btn): String = when (b) {
        Btn.SOUTH -> pick(skin, "A", "✕", "B")
        Btn.EAST -> pick(skin, "B", "○", "A")
        Btn.WEST -> pick(skin, "X", "□", "Y")
        Btn.NORTH -> pick(skin, "Y", "△", "X")
        Btn.LB -> pick(skin, "LB", "L1", "L")
        Btn.RB -> pick(skin, "RB", "R1", "R")
        Btn.VIEW -> pick(skin, "VIEW", "CREATE", "−")
        Btn.MENU -> pick(skin, "MENU", "OPTIONS", "+")
        Btn.GUIDE -> pick(skin, "XBOX", "PS", "HOME")
        Btn.LS -> "L3"
        Btn.RS -> "R3"
    }

    fun trigger(skin: Skin, left: Boolean): String =
        if (left) pick(skin, "LT", "L2", "ZL") else pick(skin, "RT", "R2", "ZR")

    fun isFace(b: Btn) = b == Btn.SOUTH || b == Btn.EAST || b == Btn.WEST || b == Btn.NORTH

    fun color(skin: Skin, b: Btn): Int {
        if (!isFace(b)) return 0xFF3A3A42.toInt()
        return when (skin) {
            Skin.XBOX -> when (b) {
                Btn.SOUTH -> 0xFF3FA34D.toInt()
                Btn.EAST -> 0xFFD0393E.toInt()
                Btn.WEST -> 0xFF2F6FD6.toInt()
                else -> 0xFFE0B02A.toInt()
            }
            Skin.PLAYSTATION -> when (b) {
                Btn.SOUTH -> 0xFF5B8DEF.toInt()
                Btn.EAST -> 0xFFE5484D.toInt()
                Btn.WEST -> 0xFFD981BD.toInt()
                else -> 0xFF3DD6A0.toInt()
            }
            Skin.SWITCH -> 0xFF8E8E96.toInt()
        }
    }

    private fun pick(skin: Skin, xbox: String, ps: String, sw: String) = when (skin) {
        Skin.XBOX -> xbox
        Skin.PLAYSTATION -> ps
        Skin.SWITCH -> sw
    }
}
