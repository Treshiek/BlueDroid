package com.droidcontroller

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.hypot
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws a layout (a list of [Control]s) and either plays it (touches become input) or edits it
 * (touches select, drag and pinch-resize controls).
 */
class ControllerView(
    ctx: Context,
    private var skin: Skin,
    controls: List<Control>,
    private val edit: Boolean,
    private val cfg: Settings,
    touchOpts: TouchOpts = TouchOpts(),
    /** Play mode: a finger changed something, call [compose] to read the new state. */
    private val onPlay: () -> Unit = {},
    /** Edit mode: selection or layout changed. The Boolean is true when the layout must be saved. */
    private val onEdit: (List<Control>, String?, Boolean) -> Unit = { _, _, _ -> },
    /** Play mode: a control mapped to Macro 1-4 was pressed. */
    private val onMacro: (Int) -> Unit = {},
    /** Play mode: a short message for the player (turbo on/off, how to use turbo). */
    private val onHint: (String) -> Unit = {},
    /** Edit mode: the lock ring was dragged, touch options changed and must be saved. */
    private val onTouch: (TouchOpts) -> Unit = {},
    /** Play mode: the mouse touchpad made the cursor do something (buttons held, move, wheel, horizontal scroll). */
    private val onMouse: (buttons: Int, dx: Int, dy: Int, wheel: Int, pan: Int) -> Unit = { _, _, _, _, _ -> }
) : View(ctx) {

    private val list = ArrayList(controls)

    private class Rt {
        var down = false
        var vx = 0f
        var vy = 0f
        var downAt = -10_000L
        var upAt = -10_000L
        /** Floating stick: where this touch started. NaN = not used yet. */
        var ox = Float.NaN
        var oy = Float.NaN
        /** Finger is far enough up that letting go would lock the stick forward. */
        var lockReady = false
        // Touchpad
        var lx = 0f
        var ly = 0f
        var lt = 0L
        var sx = 0f
        var sy = 0f
        var mvAt = -10_000L
        var moved = false
        var tapUntil = -10_000L
    }

    private var touch = touchOpts

    // Touch look (drives the right stick) and the left-stick lock
    private val LOOK_ID = "\$LOOK"
    private var lookDown = false
    private var lookOx = 0f
    private var lookOy = 0f
    private var lookX = 0f
    private var lookY = 0f
    private var lvx = 0f
    private var lvy = 0f
    private var leftLocked = false

    private val haptics = Haptics(ctx, cfg)
    private val turbo = HashSet<String>() // controls with turbo on (this session only)
    private val latched = HashSet<String>() // toggle-mode buttons that are currently held on
    private var animating = false

    private val rt = HashMap<String, Rt>()
    private val owner = HashMap<Int, String>() // pointer id -> control id

    var selected: String? = null
        private set
    private var dragId: String? = null
    private var dragDx = 0f
    private var dragDy = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x66FFFFFF; strokeWidth = 3f }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }

    private val scale = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            resizeSelected(d.scaleFactor)
            return true
        }

        override fun onScaleEnd(d: ScaleGestureDetector) {
            dragId = null
            commit()
        }
    })

    // --- Geometry -----------------------------------------------------------------------------

    private fun isPill(c: Control) = c.id == "LB" || c.id == "RB" || c.id == "LT" || c.id == "RT"
    private fun isPad(c: Control) = c.kind == Kind.PAD || c.kind == Kind.MOUSE
    private fun isCircle(c: Control) = !isPill(c) && !isPad(c)
    private fun drawable(c: Control) = c.kind == Kind.BUTTON || c.kind == Kind.STICK || c.kind == Kind.DPAD || c.kind == Kind.PAD || c.kind == Kind.MOUSE

    /** The left stick is drawn and used wherever the finger lands instead of at a fixed spot. */
    private fun floatingHere(c: Control) = !edit &&
        ((touch.floatLeft && c.id == "STICK_L") || (touch.floatRight && c.id == "STICK_R"))

    private fun stick(id: String): Control? = list.firstOrNull { it.id == id && it.out != "OFF" }
    private fun leftStick(): Control? = stick("STICK_L")

    private fun lookRadius() = height * 0.12f / touch.lookSens

    /** How far up (pixels) the finger has to go to lock: the profile's setting, kept reachable near the top edge. */
    private fun lockDistPx(cy: Float, rad: Float): Float {
        val reach = cy - height * .04f - rad * .3f
        return minOf(touch.lockDist * height, maxOf(rad * 1.1f, reach))
    }

    private fun lockFactor(cy: Float, rad: Float) = lockDistPx(cy, rad) / rad

    // --- Lock ring placement (editor) ---

    private var dragLock = false

    private fun lockStickCtl(): Control? = list.firstOrNull { it.id == "STICK_L" }

    private fun ringHits(cx: Float, cy: Float, ir: Float, skipId: String): Boolean = list.any { o ->
        if (o.id == skipId || !drawable(o) || !o.visible) return@any false
        val ob = bounds(o)
        hypot(cx - cx.coerceIn(ob.left, ob.right), cy - cy.coerceIn(ob.top, ob.bottom)) < ir
    }

    /** Highest the ring can go: the top of the screen or the first other control in the way. */
    private fun lockMaxPx(c: Control): Float {
        val b = bounds(c)
        val rad = b.width() / 2f
        val ir = rad * .3f
        val step = maxOf(2f, rad * .04f)
        var d = rad * 1.1f
        while (true) {
            val cy = b.centerY() - (d + step)
            if (cy - ir < height * .02f || ringHits(b.centerX(), cy, ir, c.id)) break
            d += step
        }
        return d
    }

    private fun editLockPx(c: Control): Float {
        val rad = bounds(c).width() / 2f
        return (touch.lockDist * height).coerceIn(rad * 1.1f, maxOf(rad * 1.1f, lockMaxPx(c)))
    }

    private fun drawLockHandle(canvas: Canvas, t: Theme) {
        val c = lockStickCtl() ?: return
        val b = bounds(c)
        val rad = b.width() / 2f
        val cy = b.centerY() - editLockPx(c)
        val col = Skins.accent(skin, c.out) ?: if (t.hollow) t.outline else 0xFFFFFFFF.toInt()
        val old = line.pathEffect
        val oldColor = line.color
        line.pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
        line.color = withAlpha(col, 140)
        canvas.drawLine(b.centerX(), b.centerY() - rad, b.centerX(), cy + rad * .3f, line)
        line.pathEffect = old
        line.color = oldColor
        lockIconAt(canvas, b.centerX(), cy, rad * .3f, dragLock, col)
    }

    /** Editor: grab the lock ring and drag it up / down. Returns true while it is handling the touch. */
    private fun lockEdit(ev: MotionEvent): Boolean {
        val c = lockStickCtl()
        if (!touch.lockForward || c == null) { dragLock = false; return false }
        val b = bounds(c)
        val rad = b.width() / 2f
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val cy = b.centerY() - editLockPx(c)
                if (hypot(ev.x - b.centerX(), ev.y - cy) <= rad * .3f * 1.7f) {
                    dragLock = true
                    invalidate()
                    return true
                }
            }
            MotionEvent.ACTION_MOVE -> if (dragLock) {
                val d = (b.centerY() - ev.y).coerceIn(rad * 1.1f, maxOf(rad * 1.1f, lockMaxPx(c)))
                touch = touch.copy(lockDist = d / height)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragLock) {
                dragLock = false
                onTouch(touch)
                invalidate()
                return true
            }
        }
        return dragLock
    }

    private fun bounds(c: Control): RectF {
        val cx = c.x * width
        val cy = c.y * height
        val r = c.size * height
        return when {
            isPill(c) -> RectF(cx - 1.8f * r, cy - .95f * r, cx + 1.8f * r, cy + .95f * r)
            isPad(c) -> RectF(cx - 2f * r, cy - r, cx + 2f * r, cy + r)
            else -> RectF(cx - r, cy - r, cx + r, cy + r)
        }
    }

    private fun hit(x: Float, y: Float): Control? {
        for (c in list.asReversed()) {
            if (!drawable(c) || (!c.visible && !edit)) continue
            if (floatingHere(c)) continue
            if (!edit && c.out == "TURBO" && !cfg.turboEnabled) continue
            if (!edit && c.kind == Kind.MOUSE && c.out == "OFF") continue
            val b = bounds(c)
            val inside = if (isCircle(c)) {
                val grow = if (c.kind == Kind.STICK || c.kind == Kind.DPAD) 1.15f else 1.1f
                hypot(x - b.centerX(), y - b.centerY()) <= b.width() / 2f * grow
            } else b.contains(x, y)
            if (inside) return c
        }
        return null
    }

    // --- Drawing ------------------------------------------------------------------------------

    private fun shade(c: Int, down: Boolean): Int {
        if (down) return c
        val k = 0.55f
        return Color.rgb(
            (Color.red(c) * k + 0x1B * (1 - k)).toInt(),
            (Color.green(c) * k + 0x1B * (1 - k)).toInt(),
            (Color.blue(c) * k + 0x20 * (1 - k)).toInt()
        )
    }

    private fun buttonColor(c: Control): Int {
        Skins.accent(skin, c.out)?.let { return it }
        val b = Btn.values().firstOrNull { it.name == c.id }
        return if (b != null && Skins.isFace(b) && c.out == c.id) Skins.color(skin, b) else Skins.plain(skin)
    }

    private fun withAlpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun mix(a: Int, b: Int, k: Float): Int = Color.rgb(
        (Color.red(a) * (1 - k) + Color.red(b) * k).toInt(),
        (Color.green(a) * (1 - k) + Color.green(b) * k).toInt(),
        (Color.blue(a) * (1 - k) + Color.blue(b) * k).toInt()
    )

    override fun onDraw(canvas: Canvas) {
        val t = Skins.theme(skin)
        canvas.drawColor(t.bg)
        animating = false
        val now = SystemClock.uptimeMillis()
        if (edit) drawZones(canvas, t)
        for (c in list) {
            if (!drawable(c)) continue
            if (floatingHere(c)) {
                // Only shown while a finger is on it (or it is locked), at the spot it was touched.
                val r = rt[c.id]
                if (c.out == "OFF" || r == null || r.ox.isNaN() ||
                    !(r.down || (c.id == "STICK_L" && leftLocked))) continue
            } else if (!c.visible && !edit) continue
            if (!edit && c.out == "TURBO" && !cfg.turboEnabled) continue
            val dim = !c.visible && !floatingHere(c)
            val saved = if (dim) canvas.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), 80) else -1
            drawControl(canvas, c, t, now)
            if (dim) canvas.restoreToCount(saved)
            if (edit && c.id == selected) {
                val b = bounds(c)
                val old = line.color
                line.color = 0xFFFFD54F.toInt()
                line.strokeWidth = 6f
                if (isCircle(c)) canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f + 8f, line)
                else canvas.drawRoundRect(b.left - 8f, b.top - 8f, b.right + 8f, b.bottom + 8f, 24f, 24f, line)
                line.color = old
                line.strokeWidth = 3f
            }
        }
        if (edit && touch.lockForward) drawLockHandle(canvas, t)
        if (!edit && lookDown) drawLook(canvas, t)
        if (animating) postInvalidateOnAnimation()
    }

    /** Edit mode: shows which half of the screen the touch features use. */
    private fun drawZones(canvas: Canvas, t: Theme) {
        if (!touch.lookOn && !touch.floatLeft && !touch.floatRight) return
        val old = line.pathEffect
        val oldColor = line.color
        line.pathEffect = DashPathEffect(floatArrayOf(18f, 12f), 0f)
        line.color = withAlpha(t.text, 70)
        text.color = withAlpha(t.text, 90)
        text.textSize = height * .045f
        val mid = width / 2f
        val pad = 14f
        if (touch.floatLeft) {
            canvas.drawRoundRect(pad, pad, mid - pad, height - pad, 28f, 28f, line)
            canvas.drawText("FLOATING STICK", mid / 2f, height * .5f, text)
        }
        if (touch.floatRight || touch.lookOn) {
            canvas.drawRoundRect(mid + pad, pad, width - pad, height - pad, 28f, 28f, line)
            canvas.drawText(if (touch.floatRight) "FLOATING STICK" else "TOUCH LOOK", mid + mid / 2f, height * .5f, text)
        }
        line.pathEffect = old
        line.color = oldColor
        text.color = Color.WHITE
    }

    /** Play mode: ring where the look touch started and a dot under the finger. */
    private fun drawLook(canvas: Canvas, t: Theme) {
        val col = Skins.accent(skin, "STICK_RIGHT") ?: if (t.hollow) t.outline else 0xFFFFFFFF.toInt()
        val rad = lookRadius()
        stroke.color = col; stroke.alpha = 110; stroke.strokeWidth = 4f
        canvas.drawCircle(lookOx, lookOy, rad, stroke)
        fill.color = withAlpha(col, 150)
        canvas.drawCircle(lookX, lookY, rad * .28f, fill)
    }

    private fun drawShape(canvas: Canvas, c: Control, b: RectF, p: Paint) {
        if (isCircle(c)) canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f, p)
        else {
            val r = b.height() * .35f
            canvas.drawRoundRect(b, r, r, p)
        }
    }

    /** One outline pass, [grow] pixels outside the control's edge. */
    private fun ringPass(canvas: Canvas, c: Control, b: RectF, grow: Float, color: Int, alpha: Int, w: Float) {
        stroke.color = color
        stroke.alpha = alpha.coerceIn(0, 255)
        stroke.strokeWidth = w
        if (isCircle(c)) canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f + grow, stroke)
        else {
            val r = b.height() * .35f + grow
            canvas.drawRoundRect(b.left - grow, b.top - grow, b.right + grow, b.bottom + grow, r, r, stroke)
        }
    }

    private fun pressScale(a: PressAnim, r: Rt?, now: Long): Float {
        if (r == null) return 1f
        if (r.down) return if (a == PressAnim.SHRINK) .88f else .86f
        val k = (now - r.upAt) / (if (a == PressAnim.SHRINK) 140f else 300f)
        if (k >= 1f) return 1f
        return if (a == PressAnim.SHRINK) .88f + .12f * k
        else { val e = 1f - k; 1f - .14f * e * e * e + .10f * sin(PI * k).toFloat() * e }
    }

    private fun drawControl(canvas: Canvas, c: Control, t: Theme, now: Long) {
        val b = bounds(c)
        val r = rt[c.id]
        val toggles = c.kind == Kind.BUTTON && c.latch && turboable(c.out)
        val on = !edit && (if (toggles) c.id in latched else r?.down == true)
        if (!edit && r != null && (now - r.upAt < 400 || now - r.downAt < 400)) animating = true
        when (c.kind) {
            Kind.BUTTON -> {
                val base = buttonColor(c)
                val anim = if (edit) PressAnim.NONE else cfg.anim
                val sc = if (anim == PressAnim.SHRINK || anim == PressAnim.BOUNCE) pressScale(anim, r, now) else 1f
                canvas.save()
                canvas.scale(sc, sc, b.centerX(), b.centerY())
                if (t.hollow) {
                    if (on) { fill.color = withAlpha(base, 0x66); drawShape(canvas, c, b, fill) }
                    if (t.glow) {
                        ringPass(canvas, c, b, 0f, base, 50, 12f)
                        ringPass(canvas, c, b, 0f, base, 25, 22f)
                    }
                    ringPass(canvas, c, b, 0f, base, 255, 4f)
                } else {
                    fill.color = shade(base, on)
                    drawShape(canvas, c, b, fill)
                    ringPass(canvas, c, b, 0f, t.outline, Color.alpha(t.outline), 3f)
                }
                val ink = if (t.hollow) base else t.text
                if (c.icon.isNotEmpty()) Icons.draw(canvas, c.icon, b.centerX(), b.centerY(), min(b.width(), b.height()) * .32f, ink)
                else label(canvas, b, Outputs.display(skin, c.out), ink)
                canvas.restore()
                if (!edit && r != null) effects(canvas, c, b, base, anim, r, now, t)
                if (!edit && c.id in turbo) badge(canvas, b)
                if (toggles) toggleMark(canvas, b, on)
            }
            Kind.STICK -> {
                val oc = Skins.accent(skin, c.out) ?: t.outline
                val rad = b.width() / 2f
                // A floating stick is drawn where it was touched.
                val sb = if (floatingHere(c) && r != null && !r.ox.isNaN())
                    RectF(r.ox - rad, r.oy - rad, r.ox + rad, r.oy + rad) else b
                val locked = c.id == "STICK_L" && leftLocked && !on
                fill.color = t.panel
                canvas.drawCircle(sb.centerX(), sb.centerY(), rad, fill)
                if (t.glow) ringPass(canvas, c, sb, 0f, oc, 40, 12f)
                ringPass(canvas, c, sb, 0f, oc, Color.alpha(oc), 3f)
                fill.color = knobColor(t, on || locked, oc)
                val vx = if (on) r!!.vx else 0f
                val vy = if (on) r!!.vy else if (locked) -1f else 0f
                val kx = sb.centerX() + vx * rad * .55f
                val ky = sb.centerY() + vy * rad * .55f
                canvas.drawCircle(kx, ky, rad * .5f, fill)
                if (t.hollow) {
                    stroke.color = oc; stroke.alpha = 255; stroke.strokeWidth = 3f
                    canvas.drawCircle(kx, ky, rad * .5f, stroke)
                }
                if (!edit && c.id == "STICK_L" && touch.lockForward && (on || locked)) lockIcon(canvas, sb, rad, r, locked, oc)
                if (edit || (c.out != "STICK_LEFT" && c.out != "STICK_RIGHT")) caption(canvas, sb, Outputs.display(skin, c.out), t)
            }
            Kind.DPAD -> {
                val accent = Skins.accent(skin, c.out)
                val oc = accent ?: t.outline
                val tc = accent ?: t.text
                val rad = b.width() / 2f
                fill.color = t.panel
                canvas.drawCircle(b.centerX(), b.centerY(), rad, fill)
                if (t.glow) ringPass(canvas, c, b, 0f, oc, 40, 12f)
                ringPass(canvas, c, b, 0f, oc, Color.alpha(oc), 3f)
                val d = rad * .6f
                text.textSize = rad * .45f
                val vx = if (on) r!!.vx else 0f
                val vy = if (on) r!!.vy else 0f
                arrow(canvas, "▲", b.centerX(), b.centerY() - d, vy < -.35f, tc)
                arrow(canvas, "▼", b.centerX(), b.centerY() + d, vy > .35f, tc)
                arrow(canvas, "◀", b.centerX() - d, b.centerY(), vx < -.35f, tc)
                arrow(canvas, "▶", b.centerX() + d, b.centerY(), vx > .35f, tc)
                if (edit || c.out != "DPAD") caption(canvas, b, Outputs.display(skin, c.out), t)
            }
            Kind.PAD -> {
                val oc = Skins.accent(skin, c.out) ?: t.outline
                val rr = b.height() * .16f
                fill.color = t.panel
                canvas.drawRoundRect(b, rr, rr, fill)
                if (on) {
                    fill.color = withAlpha(oc, 40)
                    canvas.drawRoundRect(b, rr, rr, fill)
                }
                if (t.glow) {
                    stroke.color = oc; stroke.alpha = 40; stroke.strokeWidth = 12f
                    canvas.drawRoundRect(b, rr, rr, stroke)
                }
                stroke.color = oc; stroke.alpha = Color.alpha(oc); stroke.strokeWidth = 3f
                canvas.drawRoundRect(b, rr, rr, stroke)
                if (on && r != null) {
                    fill.color = withAlpha(oc, 160)
                    canvas.drawCircle(r.lx.coerceIn(b.left, b.right), r.ly.coerceIn(b.top, b.bottom), b.height() * .1f, fill)
                }
                text.textSize = b.height() * .17f
                text.color = withAlpha(t.text, 170)
                canvas.drawText(if (edit) "TOUCHPAD → " + Outputs.display(skin, c.out) else "TOUCHPAD",
                    b.centerX(), b.centerY() + text.textSize * .35f, text)
                text.color = Color.WHITE
            }
            Kind.MOUSE -> drawMouse(canvas, c, b, t)
            else -> {}
        }
        if (edit && !c.visible) {
            val old = line.pathEffect
            line.pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
            if (isCircle(c)) canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f, line)
            else canvas.drawRoundRect(b, 24f, 24f, line)
            line.pathEffect = old
        }
    }

    private fun knobColor(t: Theme, on: Boolean, outline: Int = t.outline): Int =
        if (!t.hollow) shade(t.knob, on) else if (on) mix(t.knob, outline, .45f) else t.knob

    /** Ring above the left stick: slide into it and let go to lock the stick forward. */
    private fun lockIcon(canvas: Canvas, sb: RectF, rad: Float, r: Rt?, locked: Boolean, color: Int) {
        val ready = locked || r?.lockReady == true
        lockIconAt(canvas, sb.centerX(), sb.centerY() - rad * lockFactor(sb.centerY(), rad), rad * .3f, ready, color)
    }

    private fun lockIconAt(canvas: Canvas, cx: Float, cy: Float, ir: Float, ready: Boolean, color: Int) {
        fill.color = if (ready) withAlpha(0xFFFFD54F.toInt(), 220) else withAlpha(color, 50)
        canvas.drawCircle(cx, cy, ir, fill)
        stroke.color = if (ready) 0xFFFFD54F.toInt() else color
        stroke.alpha = if (ready) 255 else 140
        stroke.strokeWidth = 3f
        canvas.drawCircle(cx, cy, ir, stroke)
        text.textSize = ir * 1.1f
        text.color = Color.WHITE
        canvas.drawText("🔒", cx, cy + text.textSize * .35f, text)
    }

    /** Glow halo and ripple ring, drawn around (not scaled with) the button. */
    private fun effects(canvas: Canvas, c: Control, b: RectF, base: Int, anim: PressAnim, r: Rt, now: Long, t: Theme) {
        val eff = if (base == Skins.plain(skin) && !t.hollow) 0xFFFFFFFF.toInt() else base
        when (anim) {
            PressAnim.GLOW -> {
                val a = if (r.down) 1f else (1f - (now - r.upAt) / 220f).coerceIn(0f, 1f)
                if (a > 0f) {
                    ringPass(canvas, c, b, 6f, eff, (a * 200).toInt(), 10f)
                    ringPass(canvas, c, b, 13f, eff, (a * 90).toInt(), 16f)
                }
            }
            PressAnim.RIPPLE -> {
                val k = (now - r.downAt) / 380f
                if (k in 0f..1f) ringPass(canvas, c, b, b.height() * .35f * k, eff, ((1f - k) * 190).toInt(), 5f)
            }
            else -> {}
        }
    }

    /** Small dot on a toggle button: green ring when off, filled when it is held on. */
    private fun toggleMark(canvas: Canvas, b: RectF, held: Boolean) {
        val rad = min(b.width(), b.height()) * .13f
        val cx = b.left + rad * 1.2f
        val cy = b.top + rad * 1.2f
        fill.color = if (held) 0xFF7CFC9A.toInt() else 0x55000000
        canvas.drawCircle(cx, cy, rad, fill)
        stroke.color = 0xFF7CFC9A.toInt(); stroke.alpha = 255; stroke.strokeWidth = 3f
        canvas.drawCircle(cx, cy, rad, stroke)
    }

    /** Lets go of everything that is being held on (toggles and the left-stick lock), e.g. when the screen is left. */
    fun releaseLatches() {
        latched.clear()
        leftLocked = false
        releaseMouse()
        invalidate()
    }

    /** Small yellow "T" on a control that has turbo on. */
    private fun badge(canvas: Canvas, b: RectF) {
        val rad = min(b.width(), b.height()) * .2f
        val cx = b.right - rad * .4f
        val cy = b.top + rad * .4f
        fill.color = 0xFFFFD54F.toInt()
        canvas.drawCircle(cx, cy, rad, fill)
        text.color = 0xFF000000.toInt()
        text.textSize = rad * 1.3f
        canvas.drawText("T", cx, cy + text.textSize * .35f, text)
        text.color = Color.WHITE
    }

    private fun label(canvas: Canvas, b: RectF, label: String, color: Int) {
        val base = min(b.width(), b.height())
        text.color = color
        text.textSize = if (label.length > 3) base * .26f else base * .5f
        canvas.drawText(label, b.centerX(), b.centerY() + text.textSize * .35f, text)
        text.color = Color.WHITE
    }

    /** Small text under a stick / D-pad that is not doing its default job. */
    private fun caption(canvas: Canvas, b: RectF, label: String, t: Theme) {
        text.textSize = b.width() * .13f
        text.color = withAlpha(t.text, 200)
        canvas.drawText(label, b.centerX(), b.centerY() + text.textSize * .35f, text)
        text.color = Color.WHITE
    }

    private fun arrow(canvas: Canvas, glyph: String, x: Float, y: Float, on: Boolean, col: Int) {
        text.color = if (on) col else withAlpha(col, 0x88)
        canvas.drawText(glyph, x, y + text.textSize * .35f, text)
        text.color = Color.WHITE
    }

    // --- Touch --------------------------------------------------------------------------------

    override fun onTouchEvent(ev: MotionEvent): Boolean = if (edit) editTouch(ev) else playTouch(ev)

    private fun playTouch(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = ev.actionIndex
                val x = ev.getX(i)
                val y = ev.getY(i)
                val pid = ev.getPointerId(i)
                val hitControl = hit(x, y)
                if (hitControl == null) {
                    val ls = leftStick()
                    if (touch.floatLeft && ls != null && x < width / 2f && none(ls.id)) {
                        // Floating left stick: the stick starts under the finger.
                        leftLocked = false
                        owner[pid] = ls.id
                        val r = rt.getOrPut(ls.id) { Rt() }
                        r.down = true; r.vx = 0f; r.vy = 0f; r.lockReady = false
                        r.ox = x; r.oy = y
                        r.downAt = SystemClock.uptimeMillis()
                        haptics.tap()
                    } else if (touch.floatRight && stick("STICK_R") != null && x >= width / 2f && none("STICK_R")) {
                        val rs = stick("STICK_R")!!
                        owner[pid] = rs.id
                        val r = rt.getOrPut(rs.id) { Rt() }
                        r.down = true; r.vx = 0f; r.vy = 0f; r.lockReady = false
                        r.ox = x; r.oy = y
                        r.downAt = SystemClock.uptimeMillis()
                        haptics.tap()
                    } else if (touch.lookOn && !touch.floatRight && x >= width / 2f && !lookDown) {
                        owner[pid] = LOOK_ID
                        lookDown = true
                        lookOx = x; lookOy = y; lookX = x; lookY = y
                        lvx = 0f; lvy = 0f
                    }
                }
                hitControl?.let { c ->
                    if (c.kind == Kind.MOUSE) {
                        owner[pid] = c.id
                        mouseDown(c, pid, x, y, ev.eventTime)
                        return@let
                    }
                    if (c.id == "STICK_L") leftLocked = false // touching the stick lets go of the lock
                    owner[pid] = c.id
                    val r = rt.getOrPut(c.id) { Rt() }
                    r.down = true
                    r.vx = 0f
                    r.vy = 0f
                    r.lockReady = false
                    r.downAt = SystemClock.uptimeMillis()
                    track(c, r, x, y)
                    if (c.kind == Kind.PAD) {
                        r.lx = x; r.ly = y; r.sx = x; r.sy = y
                        r.lt = ev.eventTime
                        r.mvAt = -10_000L
                        r.moved = false
                    }
                    if (c.kind == Kind.BUTTON && c.latch && turboable(c.out)) {
                        if (!latched.add(c.id)) latched.remove(c.id) // tap: on, tap again: off
                    }
                    when {
                        c.out == "TURBO" -> toggleTurbo()
                        c.out.startsWith("MACRO") -> {
                            haptics.tap()
                            c.out.removePrefix("MACRO").toIntOrNull()?.let { onMacro(it) }
                        }
                        else -> haptics.tap()
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                var mouseMoved = false
                for (i in 0 until ev.pointerCount) {
                    val id = owner[ev.getPointerId(i)] ?: continue
                    if (id == LOOK_ID) { lookMove(ev.getX(i), ev.getY(i)); continue }
                    val c = list.firstOrNull { it.id == id } ?: continue
                    if (c.kind == Kind.MOUSE) { mouseMoved = true; continue }
                    rt[id]?.let {
                        if (c.kind == Kind.PAD) padMove(c, it, ev.getX(i), ev.getY(i), ev.eventTime)
                        else track(c, it, ev.getX(i), ev.getY(i))
                    }
                }
                if (mouseMoved) mouseMove(ev)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> release(ev.getPointerId(ev.actionIndex))
            MotionEvent.ACTION_CANCEL -> {
                mSessionMoved = true // a cancelled touch never clicks
                rt.values.forEach { it.lockReady = false; it.moved = true } // a cancelled touch never locks or taps
                owner.keys.toList().forEach { release(it) }
            }
        }
        onPlay()
        invalidate()
        return true
    }

    private fun track(c: Control, r: Rt, x: Float, y: Float) {
        val b = bounds(c)
        when (c.kind) {
            Kind.STICK -> {
                val rad = b.width() / 2f
                val cx = if (floatingHere(c) && !r.ox.isNaN()) r.ox else b.centerX()
                val cy = if (floatingHere(c) && !r.oy.isNaN()) r.oy else b.centerY()
                var dx = (x - cx) / rad
                var dy = (y - cy) / rad
                if (c.id == "STICK_L" && touch.lockForward) {
                    r.lockReady = -dy >= lockFactor(cy, rad) && kotlin.math.abs(dx) < .9f
                }
                val len = hypot(dx, dy)
                if (len > 1f) { dx /= len; dy /= len }
                r.vx = dx
                r.vy = dy
            }
            Kind.DPAD -> {
                val rad = b.width() / 2f
                r.vx = ((x - b.centerX()) / rad).coerceIn(-1f, 1f)
                r.vy = ((y - b.centerY()) / rad).coerceIn(-1f, 1f)
            }
            else -> {}
        }
    }

    private fun release(pointer: Int) {
        val id = owner.remove(pointer) ?: return
        if (mPtrs.containsKey(pointer)) { mouseUp(pointer, SystemClock.uptimeMillis()); return }
        if (id == LOOK_ID) {
            lookDown = false
            lvx = 0f
            lvy = 0f
            return
        }
        if (owner.values.none { it == id }) rt[id]?.apply {
            val pad = list.firstOrNull { it.id == id }?.takeIf { it.kind == Kind.PAD }
            if (pad != null && !moved && SystemClock.uptimeMillis() - downAt < 220 && pad.tap != "OFF") {
                tapUntil = SystemClock.uptimeMillis() + 90 // a quick tap = a short button press
                haptics.tap()
            }
            if (id == "STICK_L" && lockReady && touch.lockForward) {
                leftLocked = true
                haptics.toggle()
            }
            lockReady = false
            down = false; vx = 0f; vy = 0f; upAt = SystemClock.uptimeMillis()
        }
    }

    /**
     * Touchpad: swipe speed becomes stick movement (like a mouse-style camera), and the stick eases back
     * to centre when the finger stops. A touch that barely moves and ends quickly counts as a tap.
     */
    private fun padMove(c: Control, r: Rt, x: Float, y: Float, time: Long) {
        val dt = (time - r.lt).coerceAtLeast(1L)
        val dx = x - r.lx
        val dy = y - r.ly
        if (!r.moved && hypot(x - r.sx, y - r.sy) > 10f * resources.displayMetrics.density) r.moved = true
        // Full deflection at roughly three pad-heights per second (scaled by the look sensitivity).
        val full = bounds(c).height() * 3f / touch.lookSens
        val ix = (dx / dt * 1000f / full).coerceIn(-1f, 1f)
        val iy = (dy / dt * 1000f / full).coerceIn(-1f, 1f)
        r.vx = r.vx * .4f + ix * .6f
        r.vy = r.vy * .4f + iy * .6f
        r.lx = x; r.ly = y; r.lt = time
        if (dx != 0f || dy != 0f) r.mvAt = SystemClock.uptimeMillis()
    }

    private fun none(controlId: String) = owner.values.none { it == controlId }

    /**
     * Touch look: the finger works like a floating right stick. The ring stays where the touch began;
     * if you drag past its edge the ring follows, so turning back the other way is always quick.
     */
    private fun lookMove(x: Float, y: Float) {
        val rad = lookRadius()
        lookX = x
        lookY = y
        var dx = x - lookOx
        var dy = y - lookOy
        val len = hypot(dx, dy)
        if (len > rad) {
            val k = (len - rad) / len
            lookOx += dx * k
            lookOy += dy * k
            dx = x - lookOx
            dy = y - lookOy
        }
        var vx = dx / rad
        var vy = dy / rad
        val m = hypot(vx, vy)
        val dead = .06f
        if (m < dead) { vx = 0f; vy = 0f } else {
            val k = (m - dead) / (1f - dead) / m
            vx *= k; vy *= k
        }
        lvx = vx.coerceIn(-1f, 1f)
        lvy = vy.coerceIn(-1f, 1f)
    }

    // --- Mouse touchpad ----------------------------------------------------------------------

    private class MPtr(var x: Float, val sx: Float, var y: Float, val sy: Float, var t: Long, val strip: Int) {
        var moved = false
    }

    private val mPtrs = LinkedHashMap<Int, MPtr>() // pointer id -> finger on the mouse touchpad
    private var mCtl: String? = null
    private var mButtons = 0 // buttons currently held: 1 left, 2 right, 4 middle
    private var mDragging = false // tap-and-drag: left button held by a finger
    private var mLastTapUp = -10_000L
    private var mLastTapX = 0f
    private var mLastTapY = 0f
    private var mMaxFingers = 0
    private var mSessionMoved = false
    private var mSessionT0 = 0L
    private var mRemX = 0f
    private var mRemY = 0f
    private var mScrX = 0f
    private var mScrY = 0f

    private val density get() = resources.displayMetrics.density

    private fun stripTop(b: RectF) = b.bottom - b.height() * .26f

    private fun surfaceCount() = mPtrs.values.count { it.strip == 0 }

    private fun setButtons(mask: Int) {
        mButtons = mask
        onMouse(mButtons, 0, 0, 0, 0)
        invalidate()
    }

    /** A quick press and release of one button. */
    private fun click(bit: Int) {
        haptics.tap()
        setButtons(mButtons or bit)
        postDelayed({ setButtons(mButtons and bit.inv()) }, 40)
    }

    private fun mouseDown(c: Control, pid: Int, x: Float, y: Float, time: Long) {
        val b = bounds(c)
        val strip = if (touch.mouseButtons && y >= stripTop(b)) (if (x < b.centerX()) 1 else 2) else 0
        mPtrs[pid] = MPtr(x, x, y, y, time, strip)
        mCtl = c.id
        val r = rt.getOrPut(c.id) { Rt() }
        r.down = true
        r.downAt = SystemClock.uptimeMillis()
        if (strip != 0) {
            haptics.tap()
            setButtons(mButtons or strip) // strip: left = 1, right = 2
            return
        }
        val fingers = surfaceCount()
        if (fingers == 1) {
            mSessionT0 = time
            mSessionMoved = false
            mMaxFingers = 1
            mRemX = 0f; mRemY = 0f; mScrX = 0f; mScrY = 0f
            // Touch down again right after a tap: hold the left button while this finger moves (drag / select).
            if (touch.mouseTap && time - mLastTapUp < 280 &&
                hypot(x - mLastTapX, y - mLastTapY) < 48f * density) {
                mDragging = true
                setButtons(mButtons or 1)
            }
        } else {
            mMaxFingers = maxOf(mMaxFingers, fingers)
        }
    }

    private fun mouseMove(ev: MotionEvent) {
        val dens = density
        val slop = 7f * dens
        var sdx = 0f
        var sdy = 0f
        var n = 0
        var dt = 1L
        var crossed = false
        for (i in 0 until ev.pointerCount) {
            val p = mPtrs[ev.getPointerId(i)] ?: continue
            if (p.strip != 0) continue
            val x = ev.getX(i)
            val y = ev.getY(i)
            var dx = x - p.x
            var dy = y - p.y
            dt = maxOf(dt, (ev.eventTime - p.t).coerceAtLeast(1L))
            if (!p.moved) {
                if (hypot(x - p.sx, y - p.sy) > slop) {
                    p.moved = true
                    mSessionMoved = true
                    dx = x - p.sx; dy = y - p.sy // the cursor catches up with the distance spent on the tap slop
                    crossed = true
                } else { dx = 0f; dy = 0f }
            }
            p.x = x; p.y = y; p.t = ev.eventTime
            sdx += dx; sdy += dy; n++
        }
        // Strip fingers keep their own bookkeeping (they only hold a button).
        for (i in 0 until ev.pointerCount) mPtrs[ev.getPointerId(i)]?.let { if (it.strip != 0) { it.x = ev.getX(i); it.y = ev.getY(i); it.t = ev.eventTime } }
        if (n == 0) return
        if (n == 1 && mMaxFingers < 2) {
            if (sdx != 0f || sdy != 0f) moveCursor(sdx, sdy, if (crossed) 16L else dt)
        } else if (n >= 2) {
            scroll(sdx / n, sdy / n)
        }
        invalidate()
    }

    private fun moveCursor(dx: Float, dy: Float, dt: Long) {
        val dens = density
        var gain = 2.4f * touch.mouseSpeed
        if (touch.mouseAccel) {
            val v = hypot(dx, dy) / dens / dt // dp per millisecond
            gain *= 1f + 2f * (v / 1.4f).coerceAtMost(1f)
        }
        mRemX += dx / dens * gain
        mRemY += dy / dens * gain
        val ix = mRemX.toInt()
        val iy = mRemY.toInt()
        mRemX -= ix
        mRemY -= iy
        if (ix != 0 || iy != 0) onMouse(mButtons, ix, iy, 0, 0)
    }

    /** Two fingers moving together: vertical and horizontal scroll, one notch per ~14 dp. */
    private fun scroll(dx0: Float, dy0: Float) {
        var dx = dx0
        var dy = dy0
        if (kotlin.math.abs(dy) > kotlin.math.abs(dx) * 2f) dx = 0f
        if (kotlin.math.abs(dx) > kotlin.math.abs(dy) * 2f) dy = 0f
        mScrX += dx
        mScrY += dy
        val unit = 14f * density
        val ny = (mScrY / unit).toInt()
        val nx = (mScrX / unit).toInt()
        mScrY -= ny * unit
        mScrX -= nx * unit
        if (ny == 0 && nx == 0) return
        // Natural: the page follows your fingers. Otherwise: fingers down = scroll down.
        val wheel = if (touch.mouseNatural) ny else -ny
        val pan = if (touch.mouseNatural) -nx else nx
        onMouse(mButtons, 0, 0, wheel, pan)
    }

    private fun mouseUp(pid: Int, time: Long) {
        val p = mPtrs.remove(pid) ?: return
        if (p.strip != 0) {
            setButtons(mButtons and p.strip.inv())
        } else if (surfaceCount() == 0) {
            val quick = time - mSessionT0 < 300 && !mSessionMoved
            if (mDragging) {
                mDragging = false
                mLastTapUp = -10_000L
                setButtons(mButtons and 1.inv())
            } else if (touch.mouseTap && quick) {
                when (mMaxFingers) {
                    1 -> { click(1); mLastTapUp = time; mLastTapX = p.x; mLastTapY = p.y }
                    2 -> click(2)
                    else -> click(4)
                }
            }
            mMaxFingers = 0
        }
        if (mPtrs.isEmpty()) {
            rt[mCtl ?: return]?.let { it.down = false; it.upAt = SystemClock.uptimeMillis() }
        }
        invalidate()
    }

    /** Lets go of every finger and button on the mouse touchpad (leaving the screen, cancelled touches). */
    private fun releaseMouse() {
        val had = mButtons != 0
        mPtrs.clear()
        mDragging = false
        mMaxFingers = 0
        mButtons = 0
        rt[mCtl ?: return]?.down = false
        if (had) onMouse(0, 0, 0, 0, 0)
    }

    private fun drawMouse(canvas: Canvas, c: Control, b: RectF, t: Theme) {
        val oc = Skins.accent(skin, c.out) ?: t.outline
        val rr = b.height() * .14f
        val touching = !edit && mPtrs.isNotEmpty() && mCtl == c.id
        fill.color = t.panel
        canvas.drawRoundRect(b, rr, rr, fill)
        if (touching) {
            fill.color = withAlpha(oc, 36)
            canvas.drawRoundRect(b, rr, rr, fill)
        }
        if (t.glow) {
            stroke.color = oc; stroke.alpha = 40; stroke.strokeWidth = 12f
            canvas.drawRoundRect(b, rr, rr, stroke)
        }
        var labelBottom = b.bottom
        if (touch.mouseButtons) {
            val top = stripTop(b)
            labelBottom = top
            val half = b.centerX()
            for (side in 0..1) {
                val held = !edit && (mButtons and (1 shl side)) != 0
                if (held) {
                    fill.color = withAlpha(oc, 110)
                    canvas.save()
                    canvas.clipRect(if (side == 0) b.left else half, top, if (side == 0) half else b.right, b.bottom)
                    canvas.drawRoundRect(b, rr, rr, fill)
                    canvas.restore()
                }
            }
            line.color = withAlpha(oc, 150)
            canvas.drawLine(b.left, top, b.right, top, line)
            canvas.drawLine(half, top, half, b.bottom, line)
            line.color = 0x66FFFFFF
            text.textSize = (b.bottom - top) * .45f
            text.color = withAlpha(t.text, 190)
            val ty = (top + b.bottom) / 2f + text.textSize * .35f
            canvas.drawText("L", (b.left + half) / 2f, ty, text)
            canvas.drawText("R", (half + b.right) / 2f, ty, text)
        }
        stroke.color = oc; stroke.alpha = Color.alpha(oc); stroke.strokeWidth = 3f
        canvas.drawRoundRect(b, rr, rr, stroke)
        if (touching) {
            fill.color = withAlpha(oc, 170)
            for (p in mPtrs.values) {
                if (p.strip != 0) continue
                canvas.drawCircle(p.x.coerceIn(b.left, b.right), p.y.coerceIn(b.top, labelBottom), b.height() * .09f, fill)
            }
        }
        text.textSize = b.height() * .15f
        text.color = withAlpha(t.text, 150)
        canvas.drawText(if (edit) "MOUSE TOUCHPAD" else "MOUSE", b.centerX(),
            (b.top + labelBottom) / 2f + text.textSize * .35f, text)
        text.color = Color.WHITE
    }

    /** Called when the profile's touch options change (editor / settings). */
    fun setTouch(t: TouchOpts) {
        touch = t
        if (!t.lockForward) leftLocked = false
        invalidate()
    }

    private fun turboable(out: String) = out != "OFF" && out != "TURBO" && !out.startsWith("MACRO")

    /** Tapping the TURBO button flips turbo on every button that is being held right now. */
    private fun toggleTurbo() {
        val held = list.filter { it.visible && it.kind == Kind.BUTTON && !it.latch && turboable(it.out) && rt[it.id]?.down == true }
        if (held.isEmpty()) {
            onHint("Hold a button, then tap TURBO")
            return
        }
        val parts = held.map { c ->
            val nowOn = turbo.add(c.id)
            if (!nowOn) turbo.remove(c.id)
            Outputs.display(skin, c.out) + if (nowOn) " on" else " off"
        }
        haptics.toggle()
        onHint("Turbo: " + parts.joinToString(", "))
    }

    /** True while something needs to be re-sent without a finger moving (a held turbo button). */
    fun needsTick(): Boolean {
        val now = SystemClock.uptimeMillis()
        return list.any {
            it.visible && ((it.id in turbo && rt[it.id]?.down == true) ||
                (it.kind == Kind.PAD && rt[it.id]?.let { r -> (r.down && now - r.mvAt < 150) || now < r.tapUntil } == true))
        }
    }

    /** Adds what the fingers are doing right now to [s]. */
    fun compose(s: GamepadState, now: Long = SystemClock.uptimeMillis()) {
        val half = (cfg.turboMs / 2).coerceAtLeast(20).toLong()
        for (c in list) {
            if (!c.visible && !floatingHere(c)) continue
            val r = rt[c.id] ?: continue
            when (c.kind) {
                Kind.BUTTON -> if (c.latch && turboable(c.out)) {
                    if (c.id in latched) Outputs.pressButton(s, c.out) // toggle mode: stays pressed until tapped again
                } else if (r.down) {
                    // Turbo: pressed for half the interval, released for the other half, starting pressed.
                    if (c.id !in turbo || ((now - r.downAt) / half) % 2L == 0L) Outputs.pressButton(s, c.out)
                }
                Kind.STICK -> if (r.down) Outputs.moveStick(s, c.out, r.vx, r.vy)
                Kind.DPAD -> if (r.down) Outputs.moveDpad(s, c.out, r.vx, r.vy)
                Kind.PAD -> {
                    if (r.down) {
                        val f = (1f - (now - r.mvAt) / 110f).coerceIn(0f, 1f) // eases to centre when the finger stops
                        val flip = if (touch.lookInvertY && c.out == "PAD_RSTICK") -1f else 1f
                        Outputs.padStick(s, c.out, r.vx * f, r.vy * f * flip)
                    }
                    if (now < r.tapUntil && c.tap != "OFF") Outputs.pressButton(s, c.tap)
                }
                else -> {}
            }
        }
        if (leftLocked) leftStick()?.let { if (rt[it.id]?.down != true) Outputs.moveStick(s, it.out, 0f, -1f) }
        if (lookDown) {
            s.rx += lvx
            s.ry += if (touch.lookInvertY) -lvy else lvy
        }
    }

    // --- Editing ------------------------------------------------------------------------------

    private fun editTouch(ev: MotionEvent): Boolean {
        scale.onTouchEvent(ev)
        if (scale.isInProgress) return true
        if (lockEdit(ev)) return true
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val c = hit(ev.x, ev.y)
                selected = c?.id
                dragId = c?.id
                if (c != null) {
                    dragDx = c.x * width - ev.x
                    dragDy = c.y * height - ev.y
                }
                onEdit(controls(), selected, false)
            }
            MotionEvent.ACTION_MOVE -> dragId?.let { id ->
                update(id) {
                    it.copy(
                        x = ((ev.x + dragDx) / width).coerceIn(0f, 1f),
                        y = ((ev.y + dragDy) / height).coerceIn(0f, 1f)
                    )
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragId != null) commit()
                dragId = null
            }
        }
        invalidate()
        return true
    }

    private fun update(id: String, f: (Control) -> Control) {
        val i = list.indexOfFirst { it.id == id }
        if (i >= 0) list[i] = f(list[i])
        invalidate()
    }

    fun controls(): List<Control> = list.toList()

    /** Tell the editor the layout changed and should be saved. */
    fun commit() = onEdit(controls(), selected, true)

    fun resizeSelected(factor: Float) {
        selected?.let { id -> update(id) { it.copy(size = (it.size * factor).coerceIn(0.03f, 0.45f)) } }
    }

    fun setOut(id: String, out: String) {
        update(id) { it.copy(out = out) }
        commit()
    }

    fun setIcon(id: String, icon: String) {
        update(id) { it.copy(icon = icon) }
        commit()
    }

    fun setTap(id: String, tap: String) {
        update(id) { it.copy(tap = tap) }
        commit()
    }

    fun setLatch(id: String, on: Boolean) {
        update(id) { it.copy(latch = on) }
        commit()
    }

    fun toggleVisible(id: String) {
        update(id) { it.copy(visible = !it.visible) }
        commit()
    }

    fun setSkin(s: Skin) {
        skin = s
        invalidate()
    }

    fun reset(newControls: List<Control>) {
        list.clear()
        list.addAll(newControls)
        selected = null
        invalidate()
        commit()
    }
}
