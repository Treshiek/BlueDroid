package com.droidcontroller

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/**
 * Draws a layout (a list of [Control]s) and either plays it (touches become input) or edits it
 * (touches select, drag and pinch-resize controls).
 */
class ControllerView(
    ctx: Context,
    private var skin: Skin,
    controls: List<Control>,
    private val edit: Boolean,
    /** Play mode: a finger changed something, call [compose] to read the new state. */
    private val onPlay: () -> Unit = {},
    /** Edit mode: selection or layout changed. The Boolean is true when the layout must be saved. */
    private val onEdit: (List<Control>, String?, Boolean) -> Unit = { _, _, _ -> }
) : View(ctx) {

    private val list = ArrayList(controls)

    private class Rt {
        var down = false
        var vx = 0f
        var vy = 0f
    }

    private val rt = HashMap<String, Rt>()
    private val owner = HashMap<Int, String>() // pointer id -> control id

    var selected: String? = null
        private set
    private var dragId: String? = null
    private var dragDx = 0f
    private var dragDy = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x66FFFFFF; strokeWidth = 3f }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }

    private val scale = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            resizeSelected(d.scaleFactor)
            return true
        }

        override fun onScaleEnd(d: ScaleGestureDetector) {
            dragId = null
            commit()
        }
    })

    // --- Geometry -----------------------------------------------------------------------------

    private fun isPill(c: Control) = c.id == "LB" || c.id == "RB" || c.id == "LT" || c.id == "RT"
    private fun isCircle(c: Control) = !isPill(c)
    private fun drawable(c: Control) = c.kind == Kind.BUTTON || c.kind == Kind.STICK || c.kind == Kind.DPAD

    private fun bounds(c: Control): RectF {
        val cx = c.x * width
        val cy = c.y * height
        val r = c.size * height
        return when {
            isPill(c) -> RectF(cx - 1.8f * r, cy - .95f * r, cx + 1.8f * r, cy + .95f * r)
            else -> RectF(cx - r, cy - r, cx + r, cy + r)
        }
    }

    private fun hit(x: Float, y: Float): Control? {
        for (c in list.asReversed()) {
            if (!drawable(c) || (!c.visible && !edit)) continue
            val b = bounds(c)
            val inside = if (isCircle(c)) {
                val grow = if (c.kind == Kind.STICK || c.kind == Kind.DPAD) 1.15f else 1.1f
                hypot(x - b.centerX(), y - b.centerY()) <= b.width() / 2f * grow
            } else b.contains(x, y)
            if (inside) return c
        }
        return null
    }

    // --- Drawing ------------------------------------------------------------------------------

    private fun shade(c: Int, down: Boolean): Int {
        if (down) return c
        val k = 0.55f
        return Color.rgb(
            (Color.red(c) * k + 0x1B * (1 - k)).toInt(),
            (Color.green(c) * k + 0x1B * (1 - k)).toInt(),
            (Color.blue(c) * k + 0x20 * (1 - k)).toInt()
        )
    }

    private fun buttonColor(c: Control): Int {
        val b = Btn.values().firstOrNull { it.name == c.id }
        return if (b != null && Skins.isFace(b) && c.out == c.id) Skins.color(skin, b) else 0xFF3A3A42.toInt()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(0xFF111114.toInt())
        for (c in list) {
            if (!drawable(c)) continue
            if (!c.visible && !edit) continue
            val dim = !c.visible
            val saved = if (dim) canvas.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), 80) else -1
            drawControl(canvas, c)
            if (dim) canvas.restoreToCount(saved)
            if (edit && c.id == selected) {
                val b = bounds(c)
                val old = line.color
                line.color = 0xFFFFD54F.toInt()
                line.strokeWidth = 6f
                if (isCircle(c)) canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f + 8f, line)
                else canvas.drawRoundRect(b.left - 8f, b.top - 8f, b.right + 8f, b.bottom + 8f, 24f, 24f, line)
                line.color = old
                line.strokeWidth = 3f
            }
        }
    }

    private fun drawControl(canvas: Canvas, c: Control) {
        val b = bounds(c)
        val r = rt[c.id]
        val on = !edit && r?.down == true
        when (c.kind) {
            Kind.BUTTON -> {
                fill.color = shade(buttonColor(c), on)
                shape(canvas, c, b)
                label(canvas, b, Outputs.display(skin, c.out))
            }
            Kind.STICK -> {
                val rad = b.width() / 2f
                fill.color = 0xFF1E1E24.toInt()
                canvas.drawCircle(b.centerX(), b.centerY(), rad, fill)
                canvas.drawCircle(b.centerX(), b.centerY(), rad, line)
                fill.color = shade(0xFF55555E.toInt(), on)
                val vx = if (on) r!!.vx else 0f
                val vy = if (on) r!!.vy else 0f
                canvas.drawCircle(b.centerX() + vx * rad * .55f, b.centerY() + vy * rad * .55f, rad * .5f, fill)
                if (edit || (c.out != "STICK_LEFT" && c.out != "STICK_RIGHT")) caption(canvas, b, Outputs.display(skin, c.out))
            }
            Kind.DPAD -> {
                val rad = b.width() / 2f
                fill.color = 0xFF1E1E24.toInt()
                canvas.drawCircle(b.centerX(), b.centerY(), rad, fill)
                canvas.drawCircle(b.centerX(), b.centerY(), rad, line)
                val t = rad * .6f
                text.textSize = rad * .45f
                val vx = if (on) r!!.vx else 0f
                val vy = if (on) r!!.vy else 0f
                arrow(canvas, "▲", b.centerX(), b.centerY() - t, vy < -.35f)
                arrow(canvas, "▼", b.centerX(), b.centerY() + t, vy > .35f)
                arrow(canvas, "◀", b.centerX() - t, b.centerY(), vx < -.35f)
                arrow(canvas, "▶", b.centerX() + t, b.centerY(), vx > .35f)
                if (edit || c.out != "DPAD") caption(canvas, b, Outputs.display(skin, c.out))
            }
            else -> {}
        }
        if (edit && !c.visible) {
            val old = line.pathEffect
            line.pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
            if (isCircle(c)) canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f, line)
            else canvas.drawRoundRect(b, 24f, 24f, line)
            line.pathEffect = old
        }
    }

    private fun shape(canvas: Canvas, c: Control, b: RectF) {
        if (isCircle(c)) {
            canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f, fill)
            canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f, line)
        } else {
            val r = b.height() * .35f
            canvas.drawRoundRect(b, r, r, fill)
            canvas.drawRoundRect(b, r, r, line)
        }
    }

    private fun label(canvas: Canvas, b: RectF, label: String) {
        val base = min(b.width(), b.height())
        text.textSize = if (label.length > 3) base * .26f else base * .5f
        canvas.drawText(label, b.centerX(), b.centerY() + text.textSize * .35f, text)
    }

    /** Small text under a stick / D-pad that is not doing its default job. */
    private fun caption(canvas: Canvas, b: RectF, label: String) {
        text.textSize = b.width() * .13f
        text.alpha = 200
        canvas.drawText(label, b.centerX(), b.centerY() + text.textSize * .35f, text)
        text.alpha = 255
    }

    private fun arrow(canvas: Canvas, glyph: String, x: Float, y: Float, on: Boolean) {
        text.color = if (on) Color.WHITE else 0x88FFFFFF.toInt()
        canvas.drawText(glyph, x, y + text.textSize * .35f, text)
        text.color = Color.WHITE
    }

    // --- Touch --------------------------------------------------------------------------------

    override fun onTouchEvent(ev: MotionEvent): Boolean = if (edit) editTouch(ev) else playTouch(ev)

    private fun playTouch(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = ev.actionIndex
                val x = ev.getX(i)
                val y = ev.getY(i)
                hit(x, y)?.let { c ->
                    owner[ev.getPointerId(i)] = c.id
                    val r = rt.getOrPut(c.id) { Rt() }
                    r.down = true
                    r.vx = 0f
                    r.vy = 0f
                    track(c, r, x, y)
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                }
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until ev.pointerCount) {
                val id = owner[ev.getPointerId(i)] ?: continue
                val c = list.firstOrNull { it.id == id } ?: continue
                rt[id]?.let { track(c, it, ev.getX(i), ev.getY(i)) }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> release(ev.getPointerId(ev.actionIndex))
            MotionEvent.ACTION_CANCEL -> owner.keys.toList().forEach { release(it) }
        }
        onPlay()
        invalidate()
        return true
    }

    private fun track(c: Control, r: Rt, x: Float, y: Float) {
        val b = bounds(c)
        when (c.kind) {
            Kind.STICK -> {
                val rad = b.width() / 2f
                var dx = (x - b.centerX()) / rad
                var dy = (y - b.centerY()) / rad
                val len = hypot(dx, dy)
                if (len > 1f) { dx /= len; dy /= len }
                r.vx = dx
                r.vy = dy
            }
            Kind.DPAD -> {
                val rad = b.width() / 2f
                r.vx = ((x - b.centerX()) / rad).coerceIn(-1f, 1f)
                r.vy = ((y - b.centerY()) / rad).coerceIn(-1f, 1f)
            }
            else -> {}
        }
    }

    private fun release(pointer: Int) {
        val id = owner.remove(pointer) ?: return
        if (owner.values.none { it == id }) rt[id]?.apply { down = false; vx = 0f; vy = 0f }
    }

    /** Adds what the fingers are doing right now to [s]. */
    fun compose(s: GamepadState) {
        for (c in list) {
            if (!c.visible) continue
            val r = rt[c.id] ?: continue
            when (c.kind) {
                Kind.BUTTON -> if (r.down) Outputs.pressButton(s, c.out)
                Kind.STICK -> if (r.down) Outputs.moveStick(s, c.out, r.vx, r.vy)
                Kind.DPAD -> if (r.down) Outputs.moveDpad(s, c.out, r.vx, r.vy)
                else -> {}
            }
        }
    }

    // --- Editing ------------------------------------------------------------------------------

    private fun editTouch(ev: MotionEvent): Boolean {
        scale.onTouchEvent(ev)
        if (scale.isInProgress) return true
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val c = hit(ev.x, ev.y)
                selected = c?.id
                dragId = c?.id
                if (c != null) {
                    dragDx = c.x * width - ev.x
                    dragDy = c.y * height - ev.y
                }
                onEdit(controls(), selected, false)
            }
            MotionEvent.ACTION_MOVE -> dragId?.let { id ->
                update(id) {
                    it.copy(
                        x = ((ev.x + dragDx) / width).coerceIn(0f, 1f),
                        y = ((ev.y + dragDy) / height).coerceIn(0f, 1f)
                    )
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragId != null) commit()
                dragId = null
            }
        }
        invalidate()
        return true
    }

    private fun update(id: String, f: (Control) -> Control) {
        val i = list.indexOfFirst { it.id == id }
        if (i >= 0) list[i] = f(list[i])
        invalidate()
    }

    fun controls(): List<Control> = list.toList()

    /** Tell the editor the layout changed and should be saved. */
    fun commit() = onEdit(controls(), selected, true)

    fun resizeSelected(factor: Float) {
        selected?.let { id -> update(id) { it.copy(size = (it.size * factor).coerceIn(0.03f, 0.45f)) } }
    }

    fun setOut(id: String, out: String) {
        update(id) { it.copy(out = out) }
        commit()
    }

    fun toggleVisible(id: String) {
        update(id) { it.copy(visible = !it.visible) }
        commit()
    }

    fun setSkin(s: Skin) {
        skin = s
        invalidate()
    }

    fun reset(newControls: List<Control>) {
        list.clear()
        list.addAll(newControls)
        selected = null
        invalidate()
        commit()
    }
}
