package com.droidcontroller

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.hypot
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws a layout (a list of [Control]s) and either plays it (touches become input) or edits it
 * (touches select, drag and pinch-resize controls).
 */
class ControllerView(
    ctx: Context,
    private var skin: Skin,
    controls: List<Control>,
    private val edit: Boolean,
    private val cfg: Settings,
    touchOpts: TouchOpts = TouchOpts(),
    /** Play mode: a finger changed something, call [compose] to read the new state. */
    private val onPlay: () -> Unit = {},
    /** Edit mode: selection or layout changed. The Boolean is true when the layout must be saved. */
    private val onEdit: (List<Control>, String?, Boolean) -> Unit = { _, _, _ -> },
    /** Play mode: a control mapped to Macro 1-4 was pressed. */
    private val onMacro: (Int) -> Unit = {},
    /** Play mode: a short message for the player (turbo on/off, how to use turbo). */
    private val onHint: (String) -> Unit = {}
) : View(ctx) {

    private val list = ArrayList(controls)

    private class Rt {
        var down = false
        var vx = 0f
        var vy = 0f
        var downAt = -10_000L
        var upAt = -10_000L
        /** Floating stick: where this touch started. NaN = not used yet. */
        var ox = Float.NaN
        var oy = Float.NaN
        /** Finger is far enough up that letting go would lock the stick forward. */
        var lockReady = false
    }

    private var touch = touchOpts

    // Touch look (drives the right stick) and the left-stick lock
    private val LOOK_ID = "\$LOOK"
    private var lookDown = false
    private var lookOx = 0f
    private var lookOy = 0f
    private var lookX = 0f
    private var lookY = 0f
    private var lvx = 0f
    private var lvy = 0f
    private var leftLocked = false

    private val haptics = Haptics(ctx, cfg)
    private val turbo = HashSet<String>() // controls with turbo on (this session only)
    private val latched = HashSet<String>() // toggle-mode buttons that are currently held on
    private var animating = false

    private val rt = HashMap<String, Rt>()
    private val owner = HashMap<Int, String>() // pointer id -> control id

    var selected: String? = null
        private set
    private var dragId: String? = null
    private var dragDx = 0f
    private var dragDy = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x66FFFFFF; strokeWidth = 3f }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }

    private val scale = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            resizeSelected(d.scaleFactor)
            return true
        }

        override fun onScaleEnd(d: ScaleGestureDetector) {
            dragId = null
            commit()
        }
    })

    // --- Geometry -----------------------------------------------------------------------------

    private fun isPill(c: Control) = c.id == "LB" || c.id == "RB" || c.id == "LT" || c.id == "RT"
    private fun isCircle(c: Control) = !isPill(c)
    private fun drawable(c: Control) = c.kind == Kind.BUTTON || c.kind == Kind.STICK || c.kind == Kind.DPAD

    /** The left stick is drawn and used wherever the finger lands instead of at a fixed spot. */
    private fun floatingHere(c: Control) = !edit &&
        ((touch.floatLeft && c.id == "STICK_L") || (touch.floatRight && c.id == "STICK_R"))

    private fun stick(id: String): Control? = list.firstOrNull { it.id == id && it.out != "OFF" }
    private fun leftStick(): Control? = stick("STICK_L")

    private fun lookRadius() = height * 0.12f / touch.lookSens

    /** How far (in stick radii) the finger has to go up to lock, kept reachable near the top edge. */
    private fun lockFactor(cy: Float, rad: Float) = ((cy - height * .05f) / rad).coerceIn(1.1f, 1.5f)

    private fun bounds(c: Control): RectF {
        val cx = c.x * width
        val cy = c.y * height
        val r = c.size * height
        return when {
            isPill(c) -> RectF(cx - 1.8f * r, cy - .95f * r, cx + 1.8f * r, cy + .95f * r)
            else -> RectF(cx - r, cy - r, cx + r, cy + r)
        }
    }

    private fun hit(x: Float, y: Float): Control? {
        for (c in list.asReversed()) {
            if (!drawable(c) || (!c.visible && !edit)) continue
            if (floatingHere(c)) continue
            if (!edit && c.out == "TURBO" && !cfg.turboEnabled) continue
            val b = bounds(c)
            val inside = if (isCircle(c)) {
                val grow = if (c.kind == Kind.STICK || c.kind == Kind.DPAD) 1.15f else 1.1f
                hypot(x - b.centerX(), y - b.centerY()) <= b.width() / 2f * grow
            } else b.contains(x, y)
            if (inside) return c
        }
        return null
    }

    // --- Drawing ------------------------------------------------------------------------------

    private fun shade(c: Int, down: Boolean): Int {
        if (down) return c
        val k = 0.55f
        return Color.rgb(
            (Color.red(c) * k + 0x1B * (1 - k)).toInt(),
            (Color.green(c) * k + 0x1B * (1 - k)).toInt(),
            (Color.blue(c) * k + 0x20 * (1 - k)).toInt()
        )
    }

    private fun buttonColor(c: Control): Int {
        Skins.accent(skin, c.out)?.let { return it }
        val b = Btn.values().firstOrNull { it.name == c.id }
        return if (b != null && Skins.isFace(b) && c.out == c.id) Skins.color(skin, b) else Skins.plain(skin)
    }

    private fun withAlpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun mix(a: Int, b: Int, k: Float): Int = Color.rgb(
        (Color.red(a) * (1 - k) + Color.red(b) * k).toInt(),
        (Color.green(a) * (1 - k) + Color.green(b) * k).toInt(),
        (Color.blue(a) * (1 - k) + Color.blue(b) * k).toInt()
    )

    override fun onDraw(canvas: Canvas) {
        val t = Skins.theme(skin)
        canvas.drawColor(t.bg)
        animating = false
        val now = SystemClock.uptimeMillis()
        if (edit) drawZones(canvas, t)
        for (c in list) {
            if (!drawable(c)) continue
            if (floatingHere(c)) {
                // Only shown while a finger is on it (or it is locked), at the spot it was touched.
                val r = rt[c.id]
                if (c.out == "OFF" || r == null || r.ox.isNaN() ||
                    !(r.down || (c.id == "STICK_L" && leftLocked))) continue
            } else if (!c.visible && !edit) continue
            if (!edit && c.out == "TURBO" && !cfg.turboEnabled) continue
            val dim = !c.visible && !floatingHere(c)
            val saved = if (dim) canvas.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), 80) else -1
            drawControl(canvas, c, t, now)
            if (dim) canvas.restoreToCount(saved)
            if (edit && c.id == selected) {
                val b = bounds(c)
                val old = line.color
                line.color = 0xFFFFD54F.toInt()
                line.strokeWidth = 6f
                if (isCircle(c)) canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f + 8f, line)
                else canvas.drawRoundRect(b.left - 8f, b.top - 8f, b.right + 8f, b.bottom + 8f, 24f, 24f, line)
                line.color = old
                line.strokeWidth = 3f
            }
        }
        if (!edit && lookDown) drawLook(canvas, t)
        if (animating) postInvalidateOnAnimation()
    }

    /** Edit mode: shows which half of the screen the touch features use. */
    private fun drawZones(canvas: Canvas, t: Theme) {
        if (!touch.lookOn && !touch.floatLeft && !touch.floatRight) return
        val old = line.pathEffect
        val oldColor = line.color
        line.pathEffect = DashPathEffect(floatArrayOf(18f, 12f), 0f)
        line.color = withAlpha(t.text, 70)
        text.color = withAlpha(t.text, 90)
        text.textSize = height * .045f
        val mid = width / 2f
        val pad = 14f
        if (touch.floatLeft) {
            canvas.drawRoundRect(pad, pad, mid - pad, height - pad, 28f, 28f, line)
            canvas.drawText("FLOATING STICK", mid / 2f, height * .5f, text)
        }
        if (touch.floatRight || touch.lookOn) {
            canvas.drawRoundRect(mid + pad, pad, width - pad, height - pad, 28f, 28f, line)
            canvas.drawText(if (touch.floatRight) "FLOATING STICK" else "TOUCH LOOK", mid + mid / 2f, height * .5f, text)
        }
        line.pathEffect = old
        line.color = oldColor
        text.color = Color.WHITE
    }

    /** Play mode: ring where the look touch started and a dot under the finger. */
    private fun drawLook(canvas: Canvas, t: Theme) {
        val col = Skins.accent(skin, "STICK_RIGHT") ?: if (t.hollow) t.outline else 0xFFFFFFFF.toInt()
        val rad = lookRadius()
        stroke.color = col; stroke.alpha = 110; stroke.strokeWidth = 4f
        canvas.drawCircle(lookOx, lookOy, rad, stroke)
        fill.color = withAlpha(col, 150)
        canvas.drawCircle(lookX, lookY, rad * .28f, fill)
    }

    private fun drawShape(canvas: Canvas, c: Control, b: RectF, p: Paint) {
        if (isCircle(c)) canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f, p)
        else {
            val r = b.height() * .35f
            canvas.drawRoundRect(b, r, r, p)
        }
    }

    /** One outline pass, [grow] pixels outside the control's edge. */
    private fun ringPass(canvas: Canvas, c: Control, b: RectF, grow: Float, color: Int, alpha: Int, w: Float) {
        stroke.color = color
        stroke.alpha = alpha.coerceIn(0, 255)
        stroke.strokeWidth = w
        if (isCircle(c)) canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f + grow, stroke)
        else {
            val r = b.height() * .35f + grow
            canvas.drawRoundRect(b.left - grow, b.top - grow, b.right + grow, b.bottom + grow, r, r, stroke)
        }
    }

    private fun pressScale(a: PressAnim, r: Rt?, now: Long): Float {
        if (r == null) return 1f
        if (r.down) return if (a == PressAnim.SHRINK) .88f else .86f
        val k = (now - r.upAt) / (if (a == PressAnim.SHRINK) 140f else 300f)
        if (k >= 1f) return 1f
        return if (a == PressAnim.SHRINK) .88f + .12f * k
        else { val e = 1f - k; 1f - .14f * e * e * e + .10f * sin(PI * k).toFloat() * e }
    }

    private fun drawControl(canvas: Canvas, c: Control, t: Theme, now: Long) {
        val b = bounds(c)
        val r = rt[c.id]
        val toggles = c.kind == Kind.BUTTON && c.latch && turboable(c.out)
        val on = !edit && (if (toggles) c.id in latched else r?.down == true)
        if (!edit && r != null && (now - r.upAt < 400 || now - r.downAt < 400)) animating = true
        when (c.kind) {
            Kind.BUTTON -> {
                val base = buttonColor(c)
                val anim = if (edit) PressAnim.NONE else cfg.anim
                val sc = if (anim == PressAnim.SHRINK || anim == PressAnim.BOUNCE) pressScale(anim, r, now) else 1f
                canvas.save()
                canvas.scale(sc, sc, b.centerX(), b.centerY())
                if (t.hollow) {
                    if (on) { fill.color = withAlpha(base, 0x66); drawShape(canvas, c, b, fill) }
                    if (t.glow) {
                        ringPass(canvas, c, b, 0f, base, 50, 12f)
                        ringPass(canvas, c, b, 0f, base, 25, 22f)
                    }
                    ringPass(canvas, c, b, 0f, base, 255, 4f)
                } else {
                    fill.color = shade(base, on)
                    drawShape(canvas, c, b, fill)
                    ringPass(canvas, c, b, 0f, t.outline, Color.alpha(t.outline), 3f)
                }
                val ink = if (t.hollow) base else t.text
                if (c.icon.isNotEmpty()) Icons.draw(canvas, c.icon, b.centerX(), b.centerY(), min(b.width(), b.height()) * .32f, ink)
                else label(canvas, b, Outputs.display(skin, c.out), ink)
                canvas.restore()
                if (!edit && r != null) effects(canvas, c, b, base, anim, r, now, t)
                if (!edit && c.id in turbo) badge(canvas, b)
                if (toggles) toggleMark(canvas, b, on)
            }
            Kind.STICK -> {
                val oc = Skins.accent(skin, c.out) ?: t.outline
                val rad = b.width() / 2f
                // A floating stick is drawn where it was touched.
                val sb = if (floatingHere(c) && r != null && !r.ox.isNaN())
                    RectF(r.ox - rad, r.oy - rad, r.ox + rad, r.oy + rad) else b
                val locked = c.id == "STICK_L" && leftLocked && !on
                fill.color = t.panel
                canvas.drawCircle(sb.centerX(), sb.centerY(), rad, fill)
                if (t.glow) ringPass(canvas, c, sb, 0f, oc, 40, 12f)
                ringPass(canvas, c, sb, 0f, oc, Color.alpha(oc), 3f)
                fill.color = knobColor(t, on || locked, oc)
                val vx = if (on) r!!.vx else 0f
                val vy = if (on) r!!.vy else if (locked) -1f else 0f
                val kx = sb.centerX() + vx * rad * .55f
                val ky = sb.centerY() + vy * rad * .55f
                canvas.drawCircle(kx, ky, rad * .5f, fill)
                if (t.hollow) {
                    stroke.color = oc; stroke.alpha = 255; stroke.strokeWidth = 3f
                    canvas.drawCircle(kx, ky, rad * .5f, stroke)
                }
                if (!edit && c.id == "STICK_L" && touch.lockForward && (on || locked)) lockIcon(canvas, sb, rad, r, locked, oc)
                if (edit || (c.out != "STICK_LEFT" && c.out != "STICK_RIGHT")) caption(canvas, sb, Outputs.display(skin, c.out), t)
            }
            Kind.DPAD -> {
                val accent = Skins.accent(skin, c.out)
                val oc = accent ?: t.outline
                val tc = accent ?: t.text
                val rad = b.width() / 2f
                fill.color = t.panel
                canvas.drawCircle(b.centerX(), b.centerY(), rad, fill)
                if (t.glow) ringPass(canvas, c, b, 0f, oc, 40, 12f)
                ringPass(canvas, c, b, 0f, oc, Color.alpha(oc), 3f)
                val d = rad * .6f
                text.textSize = rad * .45f
                val vx = if (on) r!!.vx else 0f
                val vy = if (on) r!!.vy else 0f
                arrow(canvas, "▲", b.centerX(), b.centerY() - d, vy < -.35f, tc)
                arrow(canvas, "▼", b.centerX(), b.centerY() + d, vy > .35f, tc)
                arrow(canvas, "◀", b.centerX() - d, b.centerY(), vx < -.35f, tc)
                arrow(canvas, "▶", b.centerX() + d, b.centerY(), vx > .35f, tc)
                if (edit || c.out != "DPAD") caption(canvas, b, Outputs.display(skin, c.out), t)
            }
            else -> {}
        }
        if (edit && !c.visible) {
            val old = line.pathEffect
            line.pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
            if (isCircle(c)) canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f, line)
            else canvas.drawRoundRect(b, 24f, 24f, line)
            line.pathEffect = old
        }
    }

    private fun knobColor(t: Theme, on: Boolean, outline: Int = t.outline): Int =
        if (!t.hollow) shade(t.knob, on) else if (on) mix(t.knob, outline, .45f) else t.knob

    /** Ring above the left stick: slide into it and let go to lock the stick forward. */
    private fun lockIcon(canvas: Canvas, sb: RectF, rad: Float, r: Rt?, locked: Boolean, color: Int) {
        val ready = locked || r?.lockReady == true
        val cy = sb.centerY() - rad * lockFactor(sb.centerY(), rad)
        val ir = rad * .3f
        fill.color = if (ready) withAlpha(0xFFFFD54F.toInt(), 220) else withAlpha(color, 50)
        canvas.drawCircle(sb.centerX(), cy, ir, fill)
        stroke.color = if (ready) 0xFFFFD54F.toInt() else color
        stroke.alpha = if (ready) 255 else 140
        stroke.strokeWidth = 3f
        canvas.drawCircle(sb.centerX(), cy, ir, stroke)
        text.textSize = ir * 1.1f
        canvas.drawText("🔒", sb.centerX(), cy + text.textSize * .35f, text)
    }

    /** Glow halo and ripple ring, drawn around (not scaled with) the button. */
    private fun effects(canvas: Canvas, c: Control, b: RectF, base: Int, anim: PressAnim, r: Rt, now: Long, t: Theme) {
        val eff = if (base == Skins.plain(skin) && !t.hollow) 0xFFFFFFFF.toInt() else base
        when (anim) {
            PressAnim.GLOW -> {
                val a = if (r.down) 1f else (1f - (now - r.upAt) / 220f).coerceIn(0f, 1f)
                if (a > 0f) {
                    ringPass(canvas, c, b, 6f, eff, (a * 200).toInt(), 10f)
                    ringPass(canvas, c, b, 13f, eff, (a * 90).toInt(), 16f)
                }
            }
            PressAnim.RIPPLE -> {
                val k = (now - r.downAt) / 380f
                if (k in 0f..1f) ringPass(canvas, c, b, b.height() * .35f * k, eff, ((1f - k) * 190).toInt(), 5f)
            }
            else -> {}
        }
    }

    /** Small dot on a toggle button: green ring when off, filled when it is held on. */
    private fun toggleMark(canvas: Canvas, b: RectF, held: Boolean) {
        val rad = min(b.width(), b.height()) * .13f
        val cx = b.left + rad * 1.2f
        val cy = b.top + rad * 1.2f
        fill.color = if (held) 0xFF7CFC9A.toInt() else 0x55000000
        canvas.drawCircle(cx, cy, rad, fill)
        stroke.color = 0xFF7CFC9A.toInt(); stroke.alpha = 255; stroke.strokeWidth = 3f
        canvas.drawCircle(cx, cy, rad, stroke)
    }

    /** Lets go of everything that is being held on (toggles and the left-stick lock), e.g. when the screen is left. */
    fun releaseLatches() {
        latched.clear()
        leftLocked = false
        invalidate()
    }

    /** Small yellow "T" on a control that has turbo on. */
    private fun badge(canvas: Canvas, b: RectF) {
        val rad = min(b.width(), b.height()) * .2f
        val cx = b.right - rad * .4f
        val cy = b.top + rad * .4f
        fill.color = 0xFFFFD54F.toInt()
        canvas.drawCircle(cx, cy, rad, fill)
        text.color = 0xFF000000.toInt()
        text.textSize = rad * 1.3f
        canvas.drawText("T", cx, cy + text.textSize * .35f, text)
        text.color = Color.WHITE
    }

    private fun label(canvas: Canvas, b: RectF, label: String, color: Int) {
        val base = min(b.width(), b.height())
        text.color = color
        text.textSize = if (label.length > 3) base * .26f else base * .5f
        canvas.drawText(label, b.centerX(), b.centerY() + text.textSize * .35f, text)
        text.color = Color.WHITE
    }

    /** Small text under a stick / D-pad that is not doing its default job. */
    private fun caption(canvas: Canvas, b: RectF, label: String, t: Theme) {
        text.textSize = b.width() * .13f
        text.color = withAlpha(t.text, 200)
        canvas.drawText(label, b.centerX(), b.centerY() + text.textSize * .35f, text)
        text.color = Color.WHITE
    }

    private fun arrow(canvas: Canvas, glyph: String, x: Float, y: Float, on: Boolean, col: Int) {
        text.color = if (on) col else withAlpha(col, 0x88)
        canvas.drawText(glyph, x, y + text.textSize * .35f, text)
        text.color = Color.WHITE
    }

    // --- Touch --------------------------------------------------------------------------------

    override fun onTouchEvent(ev: MotionEvent): Boolean = if (edit) editTouch(ev) else playTouch(ev)

    private fun playTouch(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = ev.actionIndex
                val x = ev.getX(i)
                val y = ev.getY(i)
                val pid = ev.getPointerId(i)
                val hitControl = hit(x, y)
                if (hitControl == null) {
                    val ls = leftStick()
                    if (touch.floatLeft && ls != null && x < width / 2f && none(ls.id)) {
                        // Floating left stick: the stick starts under the finger.
                        leftLocked = false
                        owner[pid] = ls.id
                        val r = rt.getOrPut(ls.id) { Rt() }
                        r.down = true; r.vx = 0f; r.vy = 0f; r.lockReady = false
                        r.ox = x; r.oy = y
                        r.downAt = SystemClock.uptimeMillis()
                        haptics.tap()
                    } else if (touch.floatRight && stick("STICK_R") != null && x >= width / 2f && none("STICK_R")) {
                        val rs = stick("STICK_R")!!
                        owner[pid] = rs.id
                        val r = rt.getOrPut(rs.id) { Rt() }
                        r.down = true; r.vx = 0f; r.vy = 0f; r.lockReady = false
                        r.ox = x; r.oy = y
                        r.downAt = SystemClock.uptimeMillis()
                        haptics.tap()
                    } else if (touch.lookOn && !touch.floatRight && x >= width / 2f && !lookDown) {
                        owner[pid] = LOOK_ID
                        lookDown = true
                        lookOx = x; lookOy = y; lookX = x; lookY = y
                        lvx = 0f; lvy = 0f
                    }
                }
                hitControl?.let { c ->
                    if (c.id == "STICK_L") leftLocked = false // touching the stick lets go of the lock
                    owner[pid] = c.id
                    val r = rt.getOrPut(c.id) { Rt() }
                    r.down = true
                    r.vx = 0f
                    r.vy = 0f
                    r.lockReady = false
                    r.downAt = SystemClock.uptimeMillis()
                    track(c, r, x, y)
                    if (c.kind == Kind.BUTTON && c.latch && turboable(c.out)) {
                        if (!latched.add(c.id)) latched.remove(c.id) // tap: on, tap again: off
                    }
                    when {
                        c.out == "TURBO" -> toggleTurbo()
                        c.out.startsWith("MACRO") -> {
                            haptics.tap()
                            c.out.removePrefix("MACRO").toIntOrNull()?.let { onMacro(it) }
                        }
                        else -> haptics.tap()
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until ev.pointerCount) {
                val id = owner[ev.getPointerId(i)] ?: continue
                if (id == LOOK_ID) { lookMove(ev.getX(i), ev.getY(i)); continue }
                val c = list.firstOrNull { it.id == id } ?: continue
                rt[id]?.let { track(c, it, ev.getX(i), ev.getY(i)) }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> release(ev.getPointerId(ev.actionIndex))
            MotionEvent.ACTION_CANCEL -> {
                rt.values.forEach { it.lockReady = false } // a cancelled touch never locks
                owner.keys.toList().forEach { release(it) }
            }
        }
        onPlay()
        invalidate()
        return true
    }

    private fun track(c: Control, r: Rt, x: Float, y: Float) {
        val b = bounds(c)
        when (c.kind) {
            Kind.STICK -> {
                val rad = b.width() / 2f
                val cx = if (floatingHere(c) && !r.ox.isNaN()) r.ox else b.centerX()
                val cy = if (floatingHere(c) && !r.oy.isNaN()) r.oy else b.centerY()
                var dx = (x - cx) / rad
                var dy = (y - cy) / rad
                if (c.id == "STICK_L" && touch.lockForward) {
                    r.lockReady = -dy >= lockFactor(cy, rad) && kotlin.math.abs(dx) < .9f
                }
                val len = hypot(dx, dy)
                if (len > 1f) { dx /= len; dy /= len }
                r.vx = dx
                r.vy = dy
            }
            Kind.DPAD -> {
                val rad = b.width() / 2f
                r.vx = ((x - b.centerX()) / rad).coerceIn(-1f, 1f)
                r.vy = ((y - b.centerY()) / rad).coerceIn(-1f, 1f)
            }
            else -> {}
        }
    }

    private fun release(pointer: Int) {
        val id = owner.remove(pointer) ?: return
        if (id == LOOK_ID) {
            lookDown = false
            lvx = 0f
            lvy = 0f
            return
        }
        if (owner.values.none { it == id }) rt[id]?.apply {
            if (id == "STICK_L" && lockReady && touch.lockForward) {
                leftLocked = true
                haptics.toggle()
            }
            lockReady = false
            down = false; vx = 0f; vy = 0f; upAt = SystemClock.uptimeMillis()
        }
    }

    private fun none(controlId: String) = owner.values.none { it == controlId }

    /**
     * Touch look: the finger works like a floating right stick. The ring stays where the touch began;
     * if you drag past its edge the ring follows, so turning back the other way is always quick.
     */
    private fun lookMove(x: Float, y: Float) {
        val rad = lookRadius()
        lookX = x
        lookY = y
        var dx = x - lookOx
        var dy = y - lookOy
        val len = hypot(dx, dy)
        if (len > rad) {
            val k = (len - rad) / len
            lookOx += dx * k
            lookOy += dy * k
            dx = x - lookOx
            dy = y - lookOy
        }
        var vx = dx / rad
        var vy = dy / rad
        val m = hypot(vx, vy)
        val dead = .06f
        if (m < dead) { vx = 0f; vy = 0f } else {
            val k = (m - dead) / (1f - dead) / m
            vx *= k; vy *= k
        }
        lvx = vx.coerceIn(-1f, 1f)
        lvy = vy.coerceIn(-1f, 1f)
    }

    /** Called when the profile's touch options change (editor / settings). */
    fun setTouch(t: TouchOpts) {
        touch = t
        if (!t.lockForward) leftLocked = false
        invalidate()
    }

    private fun turboable(out: String) = out != "OFF" && out != "TURBO" && !out.startsWith("MACRO")

    /** Tapping the TURBO button flips turbo on every button that is being held right now. */
    private fun toggleTurbo() {
        val held = list.filter { it.visible && it.kind == Kind.BUTTON && !it.latch && turboable(it.out) && rt[it.id]?.down == true }
        if (held.isEmpty()) {
            onHint("Hold a button, then tap TURBO")
            return
        }
        val parts = held.map { c ->
            val nowOn = turbo.add(c.id)
            if (!nowOn) turbo.remove(c.id)
            Outputs.display(skin, c.out) + if (nowOn) " on" else " off"
        }
        haptics.toggle()
        onHint("Turbo: " + parts.joinToString(", "))
    }

    /** True while something needs to be re-sent without a finger moving (a held turbo button). */
    fun needsTick(): Boolean = list.any { it.visible && it.id in turbo && rt[it.id]?.down == true }

    /** Adds what the fingers are doing right now to [s]. */
    fun compose(s: GamepadState, now: Long = SystemClock.uptimeMillis()) {
        val half = (cfg.turboMs / 2).coerceAtLeast(20).toLong()
        for (c in list) {
            if (!c.visible && !floatingHere(c)) continue
            val r = rt[c.id] ?: continue
            when (c.kind) {
                Kind.BUTTON -> if (c.latch && turboable(c.out)) {
                    if (c.id in latched) Outputs.pressButton(s, c.out) // toggle mode: stays pressed until tapped again
                } else if (r.down) {
                    // Turbo: pressed for half the interval, released for the other half, starting pressed.
                    if (c.id !in turbo || ((now - r.downAt) / half) % 2L == 0L) Outputs.pressButton(s, c.out)
                }
                Kind.STICK -> if (r.down) Outputs.moveStick(s, c.out, r.vx, r.vy)
                Kind.DPAD -> if (r.down) Outputs.moveDpad(s, c.out, r.vx, r.vy)
                else -> {}
            }
        }
        if (leftLocked) leftStick()?.let { if (rt[it.id]?.down != true) Outputs.moveStick(s, it.out, 0f, -1f) }
        if (lookDown) {
            s.rx += lvx
            s.ry += if (touch.lookInvertY) -lvy else lvy
        }
    }

    // --- Editing ------------------------------------------------------------------------------

    private fun editTouch(ev: MotionEvent): Boolean {
        scale.onTouchEvent(ev)
        if (scale.isInProgress) return true
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val c = hit(ev.x, ev.y)
                selected = c?.id
                dragId = c?.id
                if (c != null) {
                    dragDx = c.x * width - ev.x
                    dragDy = c.y * height - ev.y
                }
                onEdit(controls(), selected, false)
            }
            MotionEvent.ACTION_MOVE -> dragId?.let { id ->
                update(id) {
                    it.copy(
                        x = ((ev.x + dragDx) / width).coerceIn(0f, 1f),
                        y = ((ev.y + dragDy) / height).coerceIn(0f, 1f)
                    )
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragId != null) commit()
                dragId = null
            }
        }
        invalidate()
        return true
    }

    private fun update(id: String, f: (Control) -> Control) {
        val i = list.indexOfFirst { it.id == id }
        if (i >= 0) list[i] = f(list[i])
        invalidate()
    }

    fun controls(): List<Control> = list.toList()

    /** Tell the editor the layout changed and should be saved. */
    fun commit() = onEdit(controls(), selected, true)

    fun resizeSelected(factor: Float) {
        selected?.let { id -> update(id) { it.copy(size = (it.size * factor).coerceIn(0.03f, 0.45f)) } }
    }

    fun setOut(id: String, out: String) {
        update(id) { it.copy(out = out) }
        commit()
    }

    fun setIcon(id: String, icon: String) {
        update(id) { it.copy(icon = icon) }
        commit()
    }

    fun setLatch(id: String, on: Boolean) {
        update(id) { it.copy(latch = on) }
        commit()
    }

    fun toggleVisible(id: String) {
        update(id) { it.copy(visible = !it.visible) }
        commit()
    }

    fun setSkin(s: Skin) {
        skin = s
        invalidate()
    }

    fun reset(newControls: List<Control>) {
        list.clear()
        list.addAll(newControls)
        selected = null
        invalidate()
        commit()
    }
}
