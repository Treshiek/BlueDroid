package com.droidcontroller

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.hypot
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws a layout (a list of [Control]s) and either plays it (touches become input) or edits it
 * (touches select, drag and pinch-resize controls).
 */
class ControllerView(
    ctx: Context,
    private var skin: Skin,
    controls: List<Control>,
    private val edit: Boolean,
    private val cfg: Settings,
    /** Play mode: a finger changed something, call [compose] to read the new state. */
    private val onPlay: () -> Unit = {},
    /** Edit mode: selection or layout changed. The Boolean is true when the layout must be saved. */
    private val onEdit: (List<Control>, String?, Boolean) -> Unit = { _, _, _ -> },
    /** Play mode: a control mapped to Macro 1-4 was pressed. */
    private val onMacro: (Int) -> Unit = {},
    /** Play mode: a short message for the player (turbo on/off, how to use turbo). */
    private val onHint: (String) -> Unit = {}
) : View(ctx) {

    private val list = ArrayList(controls)

    private class Rt {
        var down = false
        var vx = 0f
        var vy = 0f
        var downAt = -10_000L
        var upAt = -10_000L
    }

    private val haptics = Haptics(ctx, cfg)
    private val turbo = HashSet<String>() // controls with turbo on (this session only)
    private var animating = false

    private val rt = HashMap<String, Rt>()
    private val owner = HashMap<Int, String>() // pointer id -> control id

    var selected: String? = null
        private set
    private var dragId: String? = null
    private var dragDx = 0f
    private var dragDy = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x66FFFFFF; strokeWidth = 3f }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }

    private val scale = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            resizeSelected(d.scaleFactor)
            return true
        }

        override fun onScaleEnd(d: ScaleGestureDetector) {
            dragId = null
            commit()
        }
    })

    // --- Geometry -----------------------------------------------------------------------------

    private fun isPill(c: Control) = c.id == "LB" || c.id == "RB" || c.id == "LT" || c.id == "RT"
    private fun isCircle(c: Control) = !isPill(c)
    private fun drawable(c: Control) = c.kind == Kind.BUTTON || c.kind == Kind.STICK || c.kind == Kind.DPAD

    private fun bounds(c: Control): RectF {
        val cx = c.x * width
        val cy = c.y * height
        val r = c.size * height
        return when {
            isPill(c) -> RectF(cx - 1.8f * r, cy - .95f * r, cx + 1.8f * r, cy + .95f * r)
            else -> RectF(cx - r, cy - r, cx + r, cy + r)
        }
    }

    private fun hit(x: Float, y: Float): Control? {
        for (c in list.asReversed()) {
            if (!drawable(c) || (!c.visible && !edit)) continue
            if (!edit && c.out == "TURBO" && !cfg.turboEnabled) continue
            val b = bounds(c)
            val inside = if (isCircle(c)) {
                val grow = if (c.kind == Kind.STICK || c.kind == Kind.DPAD) 1.15f else 1.1f
                hypot(x - b.centerX(), y - b.centerY()) <= b.width() / 2f * grow
            } else b.contains(x, y)
            if (inside) return c
        }
        return null
    }

    // --- Drawing ------------------------------------------------------------------------------

    private fun shade(c: Int, down: Boolean): Int {
        if (down) return c
        val k = 0.55f
        return Color.rgb(
            (Color.red(c) * k + 0x1B * (1 - k)).toInt(),
            (Color.green(c) * k + 0x1B * (1 - k)).toInt(),
            (Color.blue(c) * k + 0x20 * (1 - k)).toInt()
        )
    }

    private fun buttonColor(c: Control): Int {
        val b = Btn.values().firstOrNull { it.name == c.id }
        return if (b != null && Skins.isFace(b) && c.out == c.id) Skins.color(skin, b) else Skins.plain(skin)
    }

    private fun withAlpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun mix(a: Int, b: Int, k: Float): Int = Color.rgb(
        (Color.red(a) * (1 - k) + Color.red(b) * k).toInt(),
        (Color.green(a) * (1 - k) + Color.green(b) * k).toInt(),
        (Color.blue(a) * (1 - k) + Color.blue(b) * k).toInt()
    )

    override fun onDraw(canvas: Canvas) {
        val t = Skins.theme(skin)
        canvas.drawColor(t.bg)
        animating = false
        val now = SystemClock.uptimeMillis()
        for (c in list) {
            if (!drawable(c)) continue
            if (!c.visible && !edit) continue
            if (!edit && c.out == "TURBO" && !cfg.turboEnabled) continue
            val dim = !c.visible
            val saved = if (dim) canvas.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), 80) else -1
            drawControl(canvas, c, t, now)
            if (dim) canvas.restoreToCount(saved)
            if (edit && c.id == selected) {
                val b = bounds(c)
                val old = line.color
                line.color = 0xFFFFD54F.toInt()
                line.strokeWidth = 6f
                if (isCircle(c)) canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f + 8f, line)
                else canvas.drawRoundRect(b.left - 8f, b.top - 8f, b.right + 8f, b.bottom + 8f, 24f, 24f, line)
                line.color = old
                line.strokeWidth = 3f
            }
        }
        if (animating) postInvalidateOnAnimation()
    }

    private fun drawShape(canvas: Canvas, c: Control, b: RectF, p: Paint) {
        if (isCircle(c)) canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f, p)
        else {
            val r = b.height() * .35f
            canvas.drawRoundRect(b, r, r, p)
        }
    }

    /** One outline pass, [grow] pixels outside the control's edge. */
    private fun ringPass(canvas: Canvas, c: Control, b: RectF, grow: Float, color: Int, alpha: Int, w: Float) {
        stroke.color = color
        stroke.alpha = alpha.coerceIn(0, 255)
        stroke.strokeWidth = w
        if (isCircle(c)) canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f + grow, stroke)
        else {
            val r = b.height() * .35f + grow
            canvas.drawRoundRect(b.left - grow, b.top - grow, b.right + grow, b.bottom + grow, r, r, stroke)
        }
    }

    private fun pressScale(a: PressAnim, r: Rt?, now: Long): Float {
        if (r == null) return 1f
        if (r.down) return if (a == PressAnim.SHRINK) .88f else .86f
        val k = (now - r.upAt) / (if (a == PressAnim.SHRINK) 140f else 300f)
        if (k >= 1f) return 1f
        return if (a == PressAnim.SHRINK) .88f + .12f * k
        else { val e = 1f - k; 1f - .14f * e * e * e + .10f * sin(PI * k).toFloat() * e }
    }

    private fun drawControl(canvas: Canvas, c: Control, t: Theme, now: Long) {
        val b = bounds(c)
        val r = rt[c.id]
        val on = !edit && r?.down == true
        if (!edit && r != null && (now - r.upAt < 400 || now - r.downAt < 400)) animating = true
        when (c.kind) {
            Kind.BUTTON -> {
                val base = buttonColor(c)
                val anim = if (edit) PressAnim.NONE else cfg.anim
                val sc = if (anim == PressAnim.SHRINK || anim == PressAnim.BOUNCE) pressScale(anim, r, now) else 1f
                canvas.save()
                canvas.scale(sc, sc, b.centerX(), b.centerY())
                if (t.hollow) {
                    if (on) { fill.color = withAlpha(base, 0x66); drawShape(canvas, c, b, fill) }
                    if (t.glow) {
                        ringPass(canvas, c, b, 0f, base, 50, 12f)
                        ringPass(canvas, c, b, 0f, base, 25, 22f)
                    }
                    ringPass(canvas, c, b, 0f, base, 255, 4f)
                } else {
                    fill.color = shade(base, on)
                    drawShape(canvas, c, b, fill)
                    ringPass(canvas, c, b, 0f, t.outline, Color.alpha(t.outline), 3f)
                }
                label(canvas, b, Outputs.display(skin, c.out), if (t.hollow) base else t.text)
                canvas.restore()
                if (!edit && r != null) effects(canvas, c, b, base, anim, r, now, t)
                if (!edit && c.id in turbo) badge(canvas, b)
            }
            Kind.STICK -> {
                val rad = b.width() / 2f
                fill.color = t.panel
                canvas.drawCircle(b.centerX(), b.centerY(), rad, fill)
                if (t.glow) ringPass(canvas, c, b, 0f, t.outline, 40, 12f)
                ringPass(canvas, c, b, 0f, t.outline, Color.alpha(t.outline), 3f)
                fill.color = knobColor(t, on)
                val vx = if (on) r!!.vx else 0f
                val vy = if (on) r!!.vy else 0f
                val kx = b.centerX() + vx * rad * .55f
                val ky = b.centerY() + vy * rad * .55f
                canvas.drawCircle(kx, ky, rad * .5f, fill)
                if (t.hollow) {
                    stroke.color = t.outline; stroke.alpha = 255; stroke.strokeWidth = 3f
                    canvas.drawCircle(kx, ky, rad * .5f, stroke)
                }
                if (edit || (c.out != "STICK_LEFT" && c.out != "STICK_RIGHT")) caption(canvas, b, Outputs.display(skin, c.out), t)
            }
            Kind.DPAD -> {
                val rad = b.width() / 2f
                fill.color = t.panel
                canvas.drawCircle(b.centerX(), b.centerY(), rad, fill)
                if (t.glow) ringPass(canvas, c, b, 0f, t.outline, 40, 12f)
                ringPass(canvas, c, b, 0f, t.outline, Color.alpha(t.outline), 3f)
                val d = rad * .6f
                text.textSize = rad * .45f
                val vx = if (on) r!!.vx else 0f
                val vy = if (on) r!!.vy else 0f
                arrow(canvas, "▲", b.centerX(), b.centerY() - d, vy < -.35f, t)
                arrow(canvas, "▼", b.centerX(), b.centerY() + d, vy > .35f, t)
                arrow(canvas, "◀", b.centerX() - d, b.centerY(), vx < -.35f, t)
                arrow(canvas, "▶", b.centerX() + d, b.centerY(), vx > .35f, t)
                if (edit || c.out != "DPAD") caption(canvas, b, Outputs.display(skin, c.out), t)
            }
            else -> {}
        }
        if (edit && !c.visible) {
            val old = line.pathEffect
            line.pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
            if (isCircle(c)) canvas.drawCircle(b.centerX(), b.centerY(), b.width() / 2f, line)
            else canvas.drawRoundRect(b, 24f, 24f, line)
            line.pathEffect = old
        }
    }

    private fun knobColor(t: Theme, on: Boolean): Int =
        if (!t.hollow) shade(t.knob, on) else if (on) mix(t.knob, t.outline, .45f) else t.knob

    /** Glow halo and ripple ring, drawn around (not scaled with) the button. */
    private fun effects(canvas: Canvas, c: Control, b: RectF, base: Int, anim: PressAnim, r: Rt, now: Long, t: Theme) {
        val eff = if (base == Skins.plain(skin) && !t.hollow) 0xFFFFFFFF.toInt() else base
        when (anim) {
            PressAnim.GLOW -> {
                val a = if (r.down) 1f else (1f - (now - r.upAt) / 220f).coerceIn(0f, 1f)
                if (a > 0f) {
                    ringPass(canvas, c, b, 6f, eff, (a * 200).toInt(), 10f)
                    ringPass(canvas, c, b, 13f, eff, (a * 90).toInt(), 16f)
                }
            }
            PressAnim.RIPPLE -> {
                val k = (now - r.downAt) / 380f
                if (k in 0f..1f) ringPass(canvas, c, b, b.height() * .35f * k, eff, ((1f - k) * 190).toInt(), 5f)
            }
            else -> {}
        }
    }

    /** Small yellow "T" on a control that has turbo on. */
    private fun badge(canvas: Canvas, b: RectF) {
        val rad = min(b.width(), b.height()) * .2f
        val cx = b.right - rad * .4f
        val cy = b.top + rad * .4f
        fill.color = 0xFFFFD54F.toInt()
        canvas.drawCircle(cx, cy, rad, fill)
        text.color = 0xFF000000.toInt()
        text.textSize = rad * 1.3f
        canvas.drawText("T", cx, cy + text.textSize * .35f, text)
        text.color = Color.WHITE
    }

    private fun label(canvas: Canvas, b: RectF, label: String, color: Int) {
        val base = min(b.width(), b.height())
        text.color = color
        text.textSize = if (label.length > 3) base * .26f else base * .5f
        canvas.drawText(label, b.centerX(), b.centerY() + text.textSize * .35f, text)
        text.color = Color.WHITE
    }

    /** Small text under a stick / D-pad that is not doing its default job. */
    private fun caption(canvas: Canvas, b: RectF, label: String, t: Theme) {
        text.textSize = b.width() * .13f
        text.color = withAlpha(t.text, 200)
        canvas.drawText(label, b.centerX(), b.centerY() + text.textSize * .35f, text)
        text.color = Color.WHITE
    }

    private fun arrow(canvas: Canvas, glyph: String, x: Float, y: Float, on: Boolean, t: Theme) {
        text.color = if (on) t.text else withAlpha(t.text, 0x88)
        canvas.drawText(glyph, x, y + text.textSize * .35f, text)
        text.color = Color.WHITE
    }

    // --- Touch --------------------------------------------------------------------------------

    override fun onTouchEvent(ev: MotionEvent): Boolean = if (edit) editTouch(ev) else playTouch(ev)

    private fun playTouch(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = ev.actionIndex
                val x = ev.getX(i)
                val y = ev.getY(i)
                hit(x, y)?.let { c ->
                    owner[ev.getPointerId(i)] = c.id
                    val r = rt.getOrPut(c.id) { Rt() }
                    r.down = true
                    r.vx = 0f
                    r.vy = 0f
                    r.downAt = SystemClock.uptimeMillis()
                    track(c, r, x, y)
                    when {
                        c.out == "TURBO" -> toggleTurbo()
                        c.out.startsWith("MACRO") -> {
                            haptics.tap()
                            c.out.removePrefix("MACRO").toIntOrNull()?.let { onMacro(it) }
                        }
                        else -> haptics.tap()
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until ev.pointerCount) {
                val id = owner[ev.getPointerId(i)] ?: continue
                val c = list.firstOrNull { it.id == id } ?: continue
                rt[id]?.let { track(c, it, ev.getX(i), ev.getY(i)) }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> release(ev.getPointerId(ev.actionIndex))
            MotionEvent.ACTION_CANCEL -> owner.keys.toList().forEach { release(it) }
        }
        onPlay()
        invalidate()
        return true
    }

    private fun track(c: Control, r: Rt, x: Float, y: Float) {
        val b = bounds(c)
        when (c.kind) {
            Kind.STICK -> {
                val rad = b.width() / 2f
                var dx = (x - b.centerX()) / rad
                var dy = (y - b.centerY()) / rad
                val len = hypot(dx, dy)
                if (len > 1f) { dx /= len; dy /= len }
                r.vx = dx
                r.vy = dy
            }
            Kind.DPAD -> {
                val rad = b.width() / 2f
                r.vx = ((x - b.centerX()) / rad).coerceIn(-1f, 1f)
                r.vy = ((y - b.centerY()) / rad).coerceIn(-1f, 1f)
            }
            else -> {}
        }
    }

    private fun release(pointer: Int) {
        val id = owner.remove(pointer) ?: return
        if (owner.values.none { it == id }) rt[id]?.apply { down = false; vx = 0f; vy = 0f; upAt = SystemClock.uptimeMillis() }
    }

    private fun turboable(out: String) = out != "OFF" && out != "TURBO" && !out.startsWith("MACRO")

    /** Tapping the TURBO button flips turbo on every button that is being held right now. */
    private fun toggleTurbo() {
        val held = list.filter { it.visible && it.kind == Kind.BUTTON && turboable(it.out) && rt[it.id]?.down == true }
        if (held.isEmpty()) {
            onHint("Hold a button, then tap TURBO")
            return
        }
        val parts = held.map { c ->
            val nowOn = turbo.add(c.id)
            if (!nowOn) turbo.remove(c.id)
            Outputs.display(skin, c.out) + if (nowOn) " on" else " off"
        }
        haptics.toggle()
        onHint("Turbo: " + parts.joinToString(", "))
    }

    /** True while something needs to be re-sent without a finger moving (a held turbo button). */
    fun needsTick(): Boolean = list.any { it.visible && it.id in turbo && rt[it.id]?.down == true }

    /** Adds what the fingers are doing right now to [s]. */
    fun compose(s: GamepadState, now: Long = SystemClock.uptimeMillis()) {
        val half = (cfg.turboMs / 2).coerceAtLeast(20).toLong()
        for (c in list) {
            if (!c.visible) continue
            val r = rt[c.id] ?: continue
            when (c.kind) {
                Kind.BUTTON -> if (r.down) {
                    // Turbo: pressed for half the interval, released for the other half, starting pressed.
                    if (c.id !in turbo || ((now - r.downAt) / half) % 2L == 0L) Outputs.pressButton(s, c.out)
                }
                Kind.STICK -> if (r.down) Outputs.moveStick(s, c.out, r.vx, r.vy)
                Kind.DPAD -> if (r.down) Outputs.moveDpad(s, c.out, r.vx, r.vy)
                else -> {}
            }
        }
    }

    // --- Editing ------------------------------------------------------------------------------

    private fun editTouch(ev: MotionEvent): Boolean {
        scale.onTouchEvent(ev)
        if (scale.isInProgress) return true
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val c = hit(ev.x, ev.y)
                selected = c?.id
                dragId = c?.id
                if (c != null) {
                    dragDx = c.x * width - ev.x
                    dragDy = c.y * height - ev.y
                }
                onEdit(controls(), selected, false)
            }
            MotionEvent.ACTION_MOVE -> dragId?.let { id ->
                update(id) {
                    it.copy(
                        x = ((ev.x + dragDx) / width).coerceIn(0f, 1f),
                        y = ((ev.y + dragDy) / height).coerceIn(0f, 1f)
                    )
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragId != null) commit()
                dragId = null
            }
        }
        invalidate()
        return true
    }

    private fun update(id: String, f: (Control) -> Control) {
        val i = list.indexOfFirst { it.id == id }
        if (i >= 0) list[i] = f(list[i])
        invalidate()
    }

    fun controls(): List<Control> = list.toList()

    /** Tell the editor the layout changed and should be saved. */
    fun commit() = onEdit(controls(), selected, true)

    fun resizeSelected(factor: Float) {
        selected?.let { id -> update(id) { it.copy(size = (it.size * factor).coerceIn(0.03f, 0.45f)) } }
    }

    fun setOut(id: String, out: String) {
        update(id) { it.copy(out = out) }
        commit()
    }

    fun toggleVisible(id: String) {
        update(id) { it.copy(visible = !it.visible) }
        commit()
    }

    fun setSkin(s: Skin) {
        skin = s
        invalidate()
    }

    fun reset(newControls: List<Control>) {
        list.clear()
        list.addAll(newControls)
        selected = null
        invalidate()
        commit()
    }
}
