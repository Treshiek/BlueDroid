package com.droidcontroller

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.Toast
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.abs
import kotlin.math.roundToInt

/** Plays a profile: shows its layout, reads touches, tilt and volume keys, and sends them over Bluetooth. */
class ControllerActivity : Activity(), SensorEventListener {

    private lateinit var profile: Profile
    private lateinit var view: ControllerView
    private lateinit var banner: TextView
    private val ui = Handler(Looper.getMainLooper())

    // Physical inputs
    private var usesTilt = false
    private var usesVolume = false
    private var volUp = false
    private var volDown = false
    private var tiltX = 0f
    private var tiltY = 0f
    private var sm: SensorManager? = null
    private var fx = 0f
    private var fy = 0f
    private var fz = 0f
    private var haveSample = false
    private var calibrate = true
    private var baseRoll = 0f
    private var basePitch = 0f
    private var connectedSince = 0L

    private lateinit var cfg: Settings
    private lateinit var macros: MacroStore
    private var hintUntil = 0L

    // Macro playback
    private var playing: Macro? = null
    private var playingSlot = 0
    private var playStart = 0L
    private var playIdx = 0
    private var tickerOn = false

    // Macro recording (recSlot != 0 while recording)
    private var recSlot = 0
    private var recStarted = false
    private var recStart = 0L
    private val recFrames = ArrayList<MacroFrame>()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        window.attributes = window.attributes.also {
            it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        val store = ProfileStore(this)
        profile = store.get(intent.getStringExtra("profile") ?: store.current)
        cfg = Settings(this)
        macros = MacroStore(this)
        recSlot = intent.getIntExtra("record", 0)

        val active = profile.controls.filter { it.out != "OFF" }
        usesTilt = active.any { it.kind == Kind.AXIS }
        usesVolume = active.any { it.kind == Kind.KEY }

        val root = FrameLayout(this)
        view = ControllerView(this, profile.skin, profile.controls, false, cfg, profile.touch,
            onPlay = { emit(); if (view.needsTick()) ensureTick() },
            onMacro = { startMacro(it) },
            onHint = { showHint(it) },
            onMouse = { b, dx, dy, w, p -> sendMouse(b, dx, dy, w, p) })
        root.addView(view)

        banner = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xAA000000.toInt()) }
            text = "Checking connection…"
        }
        root.addView(banner, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(6) })
        if (recSlot != 0) {
            val bar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xCC000000.toInt()) }
                setPadding(dp(12), dp(2), dp(4), dp(2))
            }
            bar.addView(TextView(this).apply {
                textSize = 12f
                setTextColor(0xFFFF5252.toInt())
                text = "● REC  Macro $recSlot  (starts at your first input)  "
            })
            bar.addView(chip("■ Stop & save") { stopRecording() })
            root.addView(bar, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(2) })
        }
        setContentView(root)
    }

    /** Shows "Connected" for a few seconds once the other device is linked, and a warning if it isn't. */
    private val bannerTick = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            if (recSlot != 0) {
                banner.visibility = View.GONE
            } else if (now < hintUntil) {
                // a hint is showing, leave it alone
            } else if (BtHid.connected) {
                if (connectedSince == 0L) connectedSince = now
                banner.text = "● Connected"
                banner.setTextColor(0xFF7CFC9A.toInt())
                banner.visibility = if (now - connectedSince < 3000) View.VISIBLE else View.GONE
            } else {
                connectedSince = 0L
                banner.text = "Not connected. Go back, press the Bluetooth steps and pair with the other device."
                banner.setTextColor(0xFFFFB74D.toInt())
                banner.visibility = View.VISIBLE
            }
            ui.postDelayed(this, 300)
        }
    }

    private var mouseWarnAt = 0L

    /** Mouse touchpad output. Warns (once in a while) if the Bluetooth device was registered without a mouse. */
    private fun sendMouse(buttons: Int, dx: Int, dy: Int, wheel: Int, pan: Int) {
        if (!BtHid.mouseReady) {
            val now = SystemClock.elapsedRealtime()
            if (BtHid.connected && now - mouseWarnAt > 5000) {
                mouseWarnAt = now
                showHint("Mouse is off. Turn it on in Startup, then pair again.")
            }
            return
        }
        BtHid.sendMouse(buttons, dx, dy, wheel, pan)
    }

    private fun showHint(msg: String) {
        if (recSlot != 0) return
        banner.text = msg
        banner.setTextColor(Color.WHITE)
        banner.visibility = View.VISIBLE
        hintUntil = SystemClock.elapsedRealtime() + 1500
    }

    override fun onResume() {
        super.onResume()
        ui.post(bannerTick)
        if (usesTilt) {
            sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
            sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
                sm?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
            }
            calibrate = true
        }
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(bannerTick)
        ui.removeCallbacks(ticker)
        tickerOn = false
        playing = null
        view.releaseLatches() // toggled buttons don't stay held while the screen is away
        sm?.unregisterListener(this)
        BtHid.send(GamepadState().also { it.finish() }) // let go of everything
    }

    override fun onDestroy() {
        super.onDestroy()
        BtHid.send(GamepadState().also { it.finish() })
    }

    /** Builds one complete state from touches, tilt, volume keys and macro playback, and sends it. */
    private fun emit() {
        val s = GamepadState()
        view.compose(s, SystemClock.uptimeMillis())
        for (c in profile.controls) {
            if (c.out == "OFF") continue
            when (c.id) {
                "TILT_X" -> Outputs.axis(s, c.out, tiltX)
                "TILT_Y" -> Outputs.axis(s, c.out, tiltY)
                "VOL_UP" -> if (volUp) Outputs.pressButton(s, c.out)
                "VOL_DOWN" -> if (volDown) Outputs.pressButton(s, c.out)
            }
        }
        if (recSlot != 0) {
            s.finish()
            record(s)
        } else {
            applyMacro(s)
            s.finish()
        }
        BtHid.send(s)
    }

    // --- Turbo ticker and macros ----------------------------------------------------------------

    /** Re-sends the state every few ms while turbo is held or a macro is playing. */
    private val ticker = object : Runnable {
        override fun run() {
            emit()
            if (playing != null || view.needsTick()) ui.postDelayed(this, 8) else tickerOn = false
        }
    }

    private fun ensureTick() {
        if (tickerOn) return
        tickerOn = true
        ui.post(ticker)
    }

    private fun startMacro(n: Int) {
        if (recSlot != 0) return
        if (playing != null && playingSlot == n) { // tap again = stop
            playing = null
            emit()
            return
        }
        val m = macros.get(n)
        if (m == null) {
            showHint("Macro $n is empty. Record it from the main screen.")
            return
        }
        playing = m
        playingSlot = n
        playStart = SystemClock.uptimeMillis()
        playIdx = 0
        ensureTick()
    }

    private fun applyMacro(s: GamepadState) {
        val m = playing ?: return
        val el = SystemClock.uptimeMillis() - playStart
        if (el >= m.durationMs) { playing = null; return }
        while (playIdx + 1 < m.frames.size && m.frames[playIdx + 1].t <= el) playIdx++
        val f = m.frames[playIdx]
        if (f.t <= el) s.merge(f)
    }

    private fun q(v: Float) = (v * 100f).roundToInt()

    private fun record(s: GamepadState) {
        val now = SystemClock.uptimeMillis()
        if (!recStarted) {
            val neutral = s.buttons == 0 && s.hat == 0 && abs(s.lx) < .02f && abs(s.ly) < .02f &&
                abs(s.rx) < .02f && abs(s.ry) < .02f && s.lt < .02f && s.rt < .02f
            if (neutral) return
            recStarted = true
            recStart = now
        }
        val t = now - recStart
        val last = recFrames.lastOrNull()
        if (last != null && last.buttons == s.buttons && last.hat == s.hat &&
            q(last.lx) == q(s.lx) && q(last.ly) == q(s.ly) && q(last.rx) == q(s.rx) && q(last.ry) == q(s.ry) &&
            q(last.lt) == q(s.lt) && q(last.rt) == q(s.rt)) return
        recFrames.add(MacroFrame(t, s.buttons, s.hat, s.lx, s.ly, s.rx, s.ry, s.lt, s.rt))
        if (t > 60_000 || recFrames.size >= 4000) stopRecording()
    }

    private fun stopRecording() {
        val slot = recSlot
        if (slot == 0) return
        recSlot = 0
        if (!recStarted || recFrames.isEmpty()) {
            Toast.makeText(this, "Nothing recorded", Toast.LENGTH_SHORT).show()
        } else {
            val dur = maxOf(SystemClock.uptimeMillis() - recStart, recFrames.last().t + 1)
            macros.save(slot, Macro(ArrayList(recFrames), dur))
            Toast.makeText(this, "Saved Macro $slot (%.1f s)".format(dur / 1000.0), Toast.LENGTH_SHORT).show()
        }
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (recSlot != 0) stopRecording() else super.onBackPressed()
    }

    // --- Tilt ---------------------------------------------------------------------------------

    @Suppress("DEPRECATION")
    override fun onSensorChanged(e: SensorEvent) {
        val ax = e.values[0]
        val ay = e.values[1]
        val az = e.values[2]
        // Convert device axes to "screen right" (sr) and "screen up" (su) for the current rotation.
        val sr: Float
        val su: Float
        when (windowManager.defaultDisplay.rotation) {
            Surface.ROTATION_90 -> { sr = -ay; su = ax }
            Surface.ROTATION_270 -> { sr = ay; su = -ax }
            Surface.ROTATION_180 -> { sr = -ax; su = -ay }
            else -> { sr = ax; su = ay }
        }
        if (!haveSample) { fx = sr; fy = su; fz = az; haveSample = true }
        fx += 0.25f * (sr - fx)
        fy += 0.25f * (su - fy)
        fz += 0.25f * (az - fz)

        val roll = Math.toDegrees(atan2(-fx.toDouble(), fy.toDouble())).toFloat()                         // + = turned clockwise
        val pitch = Math.toDegrees(atan2(fz.toDouble(), hypot(fx.toDouble(), fy.toDouble()))).toFloat()   // + = top edge away
        if (calibrate) { baseRoll = roll; basePitch = pitch; calibrate = false }

        tiltX = scaleTilt(roll - baseRoll)
        tiltY = scaleTilt(pitch - basePitch)
        emit()
    }

    /** 3° dead zone, full deflection at 30°. */
    private fun scaleTilt(deg: Float): Float {
        val a = kotlin.math.abs(deg)
        if (a < 3f) return 0f
        return (Math.signum(deg) * ((a - 3f) / 27f)).coerceIn(-1f, 1f)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    // --- Volume keys and recalibration --------------------------------------------------------

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (usesVolume && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) volUp = true else volDown = true
            if (event.repeatCount == 0) {
                val id = if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) "VOL_UP" else "VOL_DOWN"
                profile.controls.firstOrNull { it.id == id }?.out?.takeIf { it.startsWith("MACRO") }
                    ?.removePrefix("MACRO")?.toIntOrNull()?.let { startMacro(it) }
            }
            emit()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (usesVolume && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) volUp = false else volDown = false
            emit()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        // Three fingers at once = "this is my neutral tilt".
        if (ev.actionMasked == MotionEvent.ACTION_POINTER_DOWN && ev.pointerCount == 3) calibrate = true
        return super.dispatchTouchEvent(ev)
    }
}
