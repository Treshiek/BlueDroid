package com.droidcontroller

import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var store: ProfileStore
    private val ui = Handler(Looper.getMainLooper())
    private var status: TextView? = null
    private var pendingAfterPermission: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProfileStore(this)
    }

    override fun onResume() {
        super.onResume()
        build()
        BtHid.listener = { msg -> status?.text = msg }
    }

    override fun onPause() {
        super.onPause()
        BtHid.listener = null
    }

    private fun build() {
        val col = column()
        setContentView(ScrollView(this).apply { addView(col) })

        col.addView(label("DroidController", 26f, bold = true))
        col.addView(label("Turn this phone into a Bluetooth game controller.", 13f, color = 0xFFAAAAAA.toInt()))

        val profiles = store.all()
        col.addView(label("Profile", 16f, bold = true))
        col.addView(spinner(profiles, profiles.indexOfFirst { it.name == store.current }, { it.name }) {
            store.current = it.name
        })
        col.addView(button("Edit layout & mapping") {
            startActivity(Intent(this, EditorActivity::class.java).putExtra("profile", store.current))
        })

        col.addView(label("Bluetooth", 16f, bold = true))
        col.addView(label("This phone becomes a Bluetooth gamepad. Nothing needs to be installed on the other device.", 12f, color = 0xFFAAAAAA.toInt()))
        col.addView(button("1. Turn on Bluetooth gamepad") { withBtPermission { BtHid.start(this) } })
        col.addView(button("2. Make this phone discoverable") {
            withBtPermission {
                startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                    .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120))
            }
        })
        col.addView(button("3. Connect to a paired device…") { withBtPermission { pickPairedDevice() } })
        col.addView(label("On the other device: open Bluetooth settings and pair \"${Build.MODEL}\" as a game controller, then do step 3 here if it doesn't connect by itself.", 12f, color = 0xFFAAAAAA.toInt()))

        col.addView(button("▶ Start controller") {
            startActivity(Intent(this, ControllerActivity::class.java).putExtra("profile", store.current))
        })

        status = label(BtHid.status, 13f, color = 0xFF9ADBA8.toInt()).also { col.addView(it) }
    }

    private fun pickPairedDevice() {
        val devices = BtHid.bonded(this)
        if (devices.isEmpty()) {
            Toast.makeText(this, "No paired devices yet. Pair from the other device first.", Toast.LENGTH_LONG).show()
            return
        }
        @Suppress("MissingPermission")
        val names = devices.map { it.name ?: it.address }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Connect to…")
            .setItems(names) { _, i -> BtHid.connect(devices[i]) }
            .show()
    }

    private fun withBtPermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT >= 31) {
            val need = arrayOf(android.Manifest.permission.BLUETOOTH_CONNECT, android.Manifest.permission.BLUETOOTH_ADVERTISE)
                .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (need.isNotEmpty()) {
                pendingAfterPermission = action
                requestPermissions(need.toTypedArray(), 1)
                return
            }
        }
        action()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            pendingAfterPermission?.invoke()
        } else {
            Toast.makeText(this, "Bluetooth permission is needed for gamepad mode", Toast.LENGTH_LONG).show()
        }
        pendingAfterPermission = null
    }
}
