package com.droidcontroller

import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.graphics.Color
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var store: ProfileStore
    private val ui = Handler(Looper.getMainLooper())
    private var status: TextView? = null
    private var pendingAfterPermission: (() -> Unit)? = null
    private var macroSel = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProfileStore(this)
    }

    override fun onResume() {
        super.onResume()
        build()
        BtHid.listener = { msg -> status?.text = msg }
    }

    override fun onPause() {
        super.onPause()
        BtHid.listener = null
    }

    private fun build() {
        val cfg = Settings(this)
        val macros = MacroStore(this)
        val grey = 0xFFAAAAAA.toInt()
        val col = column()
        setContentView(ScrollView(this).apply { addView(col) })

        col.addView(label("DroidController", 26f, bold = true))
        col.addView(label("Turn this phone into a Bluetooth game controller.", 13f, color = grey))

        // Profile
        col.addView(section("Profile", first = true))
        val profiles = store.all()
        col.addView(spinner(profiles, profiles.indexOfFirst { it.name == store.current }, { it.name }) {
            store.current = it.name
            ui.post { build() }
        })
        col.addView(button("Edit layout & mapping") {
            startActivity(Intent(this, EditorActivity::class.java).putExtra("profile", store.current))
        })

        // Look & feel
        col.addView(section("Look & feel"))
        val skins = Skin.values().toList()
        col.addView(label("Look", 12f, color = grey))
        col.addView(spinner(skins, skins.indexOf(store.get(store.current).skin), { Skins.title(it) }) {
            store.upsert(store.get(store.current).copy(skin = it))
        })
        col.addView(label("Animation", 12f, color = grey))
        col.addView(spinner(PressAnim.values().toList(), cfg.anim.ordinal, { it.title }) { cfg.anim = it })
        col.addView(label("Vibration", 12f, color = grey))
        if (Haptics(this, cfg).supported) {
            val names = listOf("Off", "Light", "Medium", "Strong")
            col.addView(spinner((0..3).toList(), cfg.vibration, { names[it] }) { cfg.vibration = it })
        } else {
            col.addView(label("Not supported on this device.", 12f, color = grey))
        }

        // Touch controls
        col.addView(section("Touch controls (this profile)"))
        col.addView(touchOptionsView(store.get(store.current).touch) { t ->
            store.upsert(store.get(store.current).copy(touch = t))
        })

        // Turbo
        col.addView(section("Turbo"))
        col.addView(Switch(this).apply {
            text = "Turbo"
            setTextColor(Color.WHITE)
            isChecked = cfg.turboEnabled
            setOnCheckedChangeListener { _, v -> cfg.turboEnabled = v }
        })
        col.addView(label("Hold a button, then tap the TURBO button (show it in Edit layout).", 12f, color = grey))
        val speed = label("", 13f)
        fun showSpeed(ms: Int) { speed.text = "Speed: $ms ms (${1000 / ms}/s)" }
        showSpeed(cfg.turboMs)
        col.addView(speed)
        col.addView(SeekBar(this).apply {
            max = 360
            progress = cfg.turboMs - 40
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    cfg.turboMs = p + 40
                    showSpeed(p + 40)
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })

        // Macros
        col.addView(section("Macros"))
        col.addView(label("Record a sequence, then map a button to Macro 1-4 in Edit layout.", 12f, color = grey))
        val macroNames = (1..4).map { n ->
            "Macro $n: " + (macros.get(n)?.let { "%.1f s".format(it.durationMs / 1000.0) } ?: "empty")
        }
        val macroActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun showMacroActions() {
            macroActions.removeAllViews()
            val n = macroSel
            macroActions.addView(chip("Record") {
                startActivity(Intent(this, ControllerActivity::class.java)
                    .putExtra("profile", store.current).putExtra("record", n))
            })
            if (macros.get(n) != null) macroActions.addView(chip("Clear") { macros.clear(n); build() })
        }
        col.addView(spinner((1..4).toList(), macroSel - 1, { macroNames[it - 1] }) { macroSel = it; showMacroActions() })
        col.addView(macroActions)
        showMacroActions()

        // Bluetooth
        col.addView(section("Bluetooth"))
        col.addView(label("Nothing needs to be installed on the other device.", 12f, color = grey))
        col.addView(button("1. Turn on Bluetooth gamepad") { withBtPermission { BtHid.start(this) } })
        col.addView(button("2. Make this phone discoverable") {
            withBtPermission {
                startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                    .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120))
            }
        })
        col.addView(button("3. Connect to a paired device…") { withBtPermission { pickPairedDevice() } })
        col.addView(label("Pair \"${Build.MODEL}\" as a game controller in the other device's Bluetooth settings, then do step 3 if it doesn't connect.", 12f, color = grey))

        col.addView(button("▶ Start controller") {
            startActivity(Intent(this, ControllerActivity::class.java).putExtra("profile", store.current))
        })

        status = label(BtHid.status, 13f, color = 0xFF9ADBA8.toInt()).also { col.addView(it) }
    }

    private fun pickPairedDevice() {
        val devices = BtHid.bonded(this)
        if (devices.isEmpty()) {
            Toast.makeText(this, "No paired devices yet. Pair from the other device first.", Toast.LENGTH_LONG).show()
            return
        }
        @Suppress("MissingPermission")
        val names = devices.map { it.name ?: it.address }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Connect to…")
            .setItems(names) { _, i -> BtHid.connect(devices[i]) }
            .show()
    }

    private fun withBtPermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT >= 31) {
            val need = arrayOf(android.Manifest.permission.BLUETOOTH_CONNECT, android.Manifest.permission.BLUETOOTH_ADVERTISE)
                .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (need.isNotEmpty()) {
                pendingAfterPermission = action
                requestPermissions(need.toTypedArray(), 1)
                return
            }
        }
        action()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            pendingAfterPermission?.invoke()
        } else {
            Toast.makeText(this, "Bluetooth permission is needed for gamepad mode", Toast.LENGTH_LONG).show()
        }
        pendingAfterPermission = null
    }
}
