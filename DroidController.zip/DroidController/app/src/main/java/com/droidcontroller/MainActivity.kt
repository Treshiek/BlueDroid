package com.droidcontroller

import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Home screen. Four tabs keep things apart: Startup (Bluetooth), Look & feel, Controls (touch, mouse, turbo, macros)
 * and Editor (layout editor and what is shown on screen). The profile and the Start button are always visible.
 */
class MainActivity : Activity() {

    private lateinit var store: ProfileStore
    private lateinit var cfg: Settings
    private var pendingAfterPermission: (() -> Unit)? = null
    private var macroSel = 1
    private var tab = 0

    private var pill: TextView? = null
    private var statusLine: TextView? = null

    private val tabNames = listOf("Startup", "Look & feel", "Controls", "Editor")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProfileStore(this)
        cfg = Settings(this)
        if (cfg.autoStart && !BtHid.active && savedInstanceState == null) {
            withBtPermission { BtHid.start(this, cfg.mouseDevice) }
        }
    }

    override fun onResume() {
        super.onResume()
        build()
        BtHid.listener = { refreshStatus() }
    }

    override fun onPause() {
        super.onPause()
        BtHid.listener = null
    }

    private fun profile() = store.get(store.current)

    private fun saveProfile(p: Profile) = store.upsert(p)

    // --- Frame: header, tabs, content, start button ---------------------------------------------

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Pal.BG)
        }
        setContentView(root)

        // Header: name + connection pill, then the profile
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(4))
        }
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(label("DroidController", 22f, bold = true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        pill = TextView(this).apply {
            textSize = 12f
            setPadding(dp(12), dp(5), dp(12), dp(5))
        }
        titleRow.addView(pill)
        header.addView(titleRow)
        val profiles = store.all()
        header.addView(dropdownRow("Profile", profiles, profiles.indexOfFirst { it.name == store.current }, { it.name }) {
            store.current = it.name
            window.decorView.post { build() }
        })
        root.addView(header)

        // Tabs
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(Pal.CARD, 12)
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val content = column()
        tabNames.forEachIndexed { i, name ->
            tabs.addView(TextView(this).apply {
                text = name
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(0, dp(9), 0, dp(9))
                setTextColor(if (i == tab) Color.WHITE else Pal.SUB)
                if (i == tab) { background = rounded(Pal.ACCENT, 10); setTypeface(typeface, android.graphics.Typeface.BOLD) }
                setOnClickListener { tab = i; build() }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(tabs, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            leftMargin = dp(16); rightMargin = dp(16); topMargin = dp(6)
        })

        root.addView(ScrollView(this).apply { addView(content) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        when (tab) {
            0 -> startupTab(content)
            1 -> lookTab(content)
            2 -> controlsTab(content)
            else -> editorTab(content)
        }

        // Always-visible start button
        val bar = LinearLayout(this).apply {
            setBackgroundColor(Pal.CARD)
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        bar.addView(actionButton("▶  Start controller", primary = true) {
            startActivity(Intent(this, ControllerActivity::class.java).putExtra("profile", store.current))
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(bar)

        refreshStatus()
    }

    private fun refreshStatus() {
        pill?.apply {
            val on = BtHid.connected
            text = if (on) "● Connected" else "○ Not connected"
            setTextColor(if (on) Pal.GOOD else Pal.SUB)
            background = rounded(Pal.FIELD, 20)
        }
        statusLine?.text = BtHid.status
    }

    // --- Startup ----------------------------------------------------------------------------------

    private fun startupTab(col: LinearLayout) {
        val bt = card("Bluetooth", col)
        val steps = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun step(text: String, f: () -> Unit) = steps.addView(actionButton(text) { f() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })
        step("1  Turn on") { withBtPermission { BtHid.start(this, cfg.mouseDevice) } }
        step("2  Discoverable") {
            withBtPermission {
                startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                    .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120))
            }
        }
        step("3  Connect…") { withBtPermission { pickPairedDevice() } }
        bt.addView(steps)
        statusLine = label(BtHid.status, 13f, color = Pal.GOOD).also { bt.addView(it) }
        bt.addView(hint("Pair \"${Build.MODEL}\" from the other device, then use step 3 if it doesn't connect."))

        val opts = card("When the app opens", col)
        opts.addView(switchRow("Turn on Bluetooth automatically", cfg.autoStart) { cfg.autoStart = it })
        opts.addView(switchRow("Also appear as a mouse", cfg.mouseDevice) { v ->
            cfg.mouseDevice = v
            if (BtHid.active) withBtPermission { BtHid.start(this, v) }
        })
        opts.addView(hint("The mouse touchpad needs this. Pair again after changing it."))
    }

    // --- Look & feel ------------------------------------------------------------------------------

    private fun lookTab(col: LinearLayout) {
        val look = card("Look", col)
        val skins = Skin.values().toList()
        look.addView(dropdownRow("Skin", skins, skins.indexOf(profile().skin), { Skins.title(it) }) {
            saveProfile(profile().copy(skin = it))
        })

        val fx = card("Press effects", col)
        fx.addView(dropdownRow("Animation", PressAnim.values().toList(), cfg.anim.ordinal, { it.title }) { cfg.anim = it })
        if (Haptics(this, cfg).supported) {
            val names = listOf("Off", "Light", "Medium", "Strong")
            fx.addView(dropdownRow("Vibration", (0..3).toList(), cfg.vibration, { names[it] }) { cfg.vibration = it })
        }
    }

    // --- Controls ---------------------------------------------------------------------------------

    private fun controlsTab(col: LinearLayout) {
        val touch = card("Touch", col)
        touch.addView(touchOptionsView(profile().touch) { t -> saveProfile(profile().copy(touch = t)) })

        val mouse = card("Mouse touchpad", col)
        mouse.addView(switchRow("Show on screen", isShown(listOf("MOUSEPAD"))) { setShown(listOf("MOUSEPAD"), it) })
        mouse.addView(mouseOptionsView(profile().touch) { t -> saveProfile(profile().copy(touch = t)) })

        val turbo = card("Turbo", col)
        turbo.addView(switchRow("Enable turbo", cfg.turboEnabled) { cfg.turboEnabled = it })
        turbo.addView(sliderRow({ ms -> "Speed: ${(1000 / ms).toInt()} presses per second" }, 40f, 400f, 10f, cfg.turboMs.toFloat()) {
            cfg.turboMs = it.toInt()
        })
        turbo.addView(hint("Hold a button, then tap TURBO."))

        val macros = MacroStore(this)
        val mc = card("Macros", col)
        val names = (1..4).map { n ->
            "Macro $n: " + (macros.get(n)?.let { "%.1f s".format(it.durationMs / 1000.0) } ?: "empty")
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(spinner((1..4).toList(), macroSel - 1, { names[it - 1] }) { macroSel = it; window.decorView.post { build() } },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(chip("Record") {
            startActivity(Intent(this, ControllerActivity::class.java)
                .putExtra("profile", store.current).putExtra("record", macroSel))
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
        if (macros.get(macroSel) != null) {
            row.addView(chip("Clear") { macros.clear(macroSel); build() },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6) })
        }
        mc.addView(row)
        mc.addView(hint("Map a button to Macro 1-4 in the editor."))
    }

    // --- Editor -----------------------------------------------------------------------------------

    private fun editorTab(col: LinearLayout) {
        val ed = card("Layout editor", col)
        ed.addView(actionButton("Edit layout & mapping", primary = true) {
            startActivity(Intent(this, EditorActivity::class.java).putExtra("profile", store.current))
        })
        ed.addView(hint("Drag to move, pinch to resize, Remap to change what a control sends."))

        val show = card("Show on screen", col)
        val extras = listOf(
            "TURBO button" to listOf("TURBO"),
            "Macro buttons (M1–M4)" to listOf("M1", "M2", "M3", "M4"),
            "Touchpad (moves a stick)" to listOf("TOUCHPAD"),
            "Mouse touchpad" to listOf("MOUSEPAD")
        )
        extras.forEach { (name, ids) -> show.addView(switchRow(name, isShown(ids)) { setShown(ids, it) }) }
    }

    private fun isShown(ids: List<String>) = profile().controls.any { it.id in ids && it.visible }

    private fun setShown(ids: List<String>, on: Boolean) {
        val p = profile()
        saveProfile(p.copy(controls = p.controls.map { if (it.id in ids) it.copy(visible = on) else it }))
    }

    // --- Bluetooth helpers ------------------------------------------------------------------------

    private fun pickPairedDevice() {
        val devices = BtHid.bonded(this)
        if (devices.isEmpty()) {
            Toast.makeText(this, "No paired devices yet. Pair from the other device first.", Toast.LENGTH_LONG).show()
            return
        }
        @Suppress("MissingPermission")
        val names = devices.map { it.name ?: it.address }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Connect to…")
            .setItems(names) { _, i -> BtHid.connect(devices[i]) }
            .show()
    }

    private fun withBtPermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT >= 31) {
            val need = arrayOf(android.Manifest.permission.BLUETOOTH_CONNECT, android.Manifest.permission.BLUETOOTH_ADVERTISE)
                .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (need.isNotEmpty()) {
                pendingAfterPermission = action
                requestPermissions(need.toTypedArray(), 1)
                return
            }
        }
        action()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            pendingAfterPermission?.invoke()
        } else {
            Toast.makeText(this, "Bluetooth permission is needed", Toast.LENGTH_LONG).show()
        }
        pendingAfterPermission = null
    }
}
