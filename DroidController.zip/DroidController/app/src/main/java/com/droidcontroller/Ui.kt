package com.droidcontroller

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

/** Tiny helpers so the screens can be built in code without layout XML. */
fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** App colours (main screens only; the controller itself uses the skins). */
object Pal {
    val BG = 0xFF0E0E12.toInt()
    val CARD = 0xFF191920.toInt()
    val FIELD = 0xFF272731.toInt()
    val ACCENT = 0xFF4C8DFF.toInt()
    val SUB = 0xFF9A9AAA.toInt()
    val GOOD = 0xFF7CFC9A.toInt()
    val WARN = 0xFFFFB74D.toInt()
}

fun Context.rounded(color: Int, radiusDp: Int = 14): GradientDrawable =
    GradientDrawable().apply { setColor(color); cornerRadius = dp(radiusDp).toFloat() }

fun Context.label(text: String, sizeSp: Float = 14f, bold: Boolean = false, color: Int = Color.WHITE): TextView =
    TextView(this).apply {
        this.text = text
        textSize = sizeSp
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(6), 0, dp(2))
    }

/** Small grey explanation line. Keep these to one short sentence. */
fun Context.hint(text: String): TextView = label(text, 12f, color = Pal.SUB)

fun Context.button(text: String, onClick: () -> Unit): Button =
    Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

/** Rounded button. [primary] = accent colour. */
fun Context.actionButton(text: String, primary: Boolean = false, onClick: () -> Unit): Button =
    Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 14f
        setTextColor(Color.WHITE)
        background = rounded(if (primary) Pal.ACCENT else Pal.FIELD, 12)
        minHeight = dp(44)
        minimumHeight = dp(44)
        setOnClickListener { onClick() }
    }

fun <T> Context.spinner(items: List<T>, selected: Int, name: (T) -> String, onPick: (T) -> Unit): Spinner =
    Spinner(this).apply {
        adapter = ArrayAdapter(this@spinner, android.R.layout.simple_spinner_dropdown_item, items.map(name))
        setSelection(selected.coerceAtLeast(0))
        var first = true // ignore the initial callback fired on layout
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (first) { first = false; return }
                onPick(items[pos])
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

/** A line with the name on the left and a dropdown on the right (saves space over a title + full-width list). */
fun <T> Context.dropdownRow(title: String, items: List<T>, selected: Int, name: (T) -> String, onPick: (T) -> Unit): LinearLayout =
    LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(label(title, 14f), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addView(spinner(items, selected, name, onPick), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.4f))
    }

fun Context.column(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(16), dp(16), dp(16), dp(16))
}

/** A rounded section with a title. Added to [parent] with space below it. */
fun Context.card(title: String, parent: LinearLayout): LinearLayout {
    val c = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(Pal.CARD, 16)
        setPadding(dp(16), dp(12), dp(16), dp(14))
    }
    c.addView(label(title.uppercase(), 12f, bold = true, color = Pal.ACCENT).apply { letterSpacing = .08f })
    parent.addView(c, LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) })
    return c
}

fun Context.switchRow(text: String, on: Boolean, onChange: (Boolean) -> Unit): Switch =
    Switch(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 14f
        isChecked = on
        setPadding(0, dp(8), 0, dp(8))
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

/** A caption showing the current value, with a slider under it. */
fun Context.sliderRow(text: (Float) -> String, lo: Float, hi: Float, step: Float, value: Float, onChange: (Float) -> Unit): LinearLayout {
    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    val caption = label(text(value), 13f)
    val steps = Math.round((hi - lo) / step)
    col.addView(caption)
    col.addView(SeekBar(this).apply {
        this.max = steps
        progress = Math.round((value - lo) / step).coerceIn(0, steps)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val v = lo + p * step
                caption.text = text(v)
                if (fromUser) onChange(v)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    })
    return col
}

/** Small compact button for toolbars. */
fun Context.chip(text: String, onClick: () -> Unit): Button =
    Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 11f
        minWidth = 0
        minimumWidth = 0
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(10), dp(4), dp(10), dp(4))
        setOnClickListener { onClick() }
    }

/**
 * The per-profile touch options: touch look (right stick), look sensitivity and invert,
 * floating left and right sticks, and the optional forward lock. [onChange] gets the new values after every change.
 */
fun Context.touchOptionsView(start: TouchOpts, onChange: (TouchOpts) -> Unit): LinearLayout {
    var cur = start
    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    fun update(n: TouchOpts) { cur = n; onChange(n) }
    lateinit var swLook: Switch
    lateinit var swFloatR: Switch
    swLook = switchRow("Touch look", start.lookOn) { v ->
        if (v) swFloatR.isChecked = false
        update(cur.copy(lookOn = v, floatRight = if (v) false else cur.floatRight))
    }
    swFloatR = switchRow("Floating right stick", start.floatRight) { v ->
        if (v) swLook.isChecked = false
        update(cur.copy(floatRight = v, lookOn = if (v) false else cur.lookOn))
    }
    col.addView(swLook)
    col.addView(switchRow("Invert look Y", start.lookInvertY) { v -> update(cur.copy(lookInvertY = v)) })
    col.addView(sliderRow({ "Look sensitivity: %.1fx".format(it) }, 0.5f, 2.5f, 0.05f, start.lookSens) { v ->
        update(cur.copy(lookSens = v))
    })
    col.addView(switchRow("Floating left stick", start.floatLeft) { v -> update(cur.copy(floatLeft = v)) })
    col.addView(swFloatR)
    col.addView(switchRow("Lock left stick forward", start.lockForward) { v -> update(cur.copy(lockForward = v)) })
    return col
}

/** The per-profile mouse touchpad options: speed, acceleration, tap to click, scroll direction, click strip. */
fun Context.mouseOptionsView(start: TouchOpts, onChange: (TouchOpts) -> Unit): LinearLayout {
    var cur = start
    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    fun update(n: TouchOpts) { cur = n; onChange(n) }
    col.addView(sliderRow({ "Cursor speed: %.1fx".format(it) }, 0.4f, 3f, 0.1f, start.mouseSpeed) { v ->
        update(cur.copy(mouseSpeed = v))
    })
    col.addView(switchRow("Pointer acceleration", start.mouseAccel) { v -> update(cur.copy(mouseAccel = v)) })
    col.addView(switchRow("Tap to click", start.mouseTap) { v -> update(cur.copy(mouseTap = v)) })
    col.addView(hint("2 fingers = right click, 3 = middle, tap then drag = hold. 2-finger swipe scrolls."))
    col.addView(switchRow("Natural scrolling", start.mouseNatural) { v -> update(cur.copy(mouseNatural = v)) })
    col.addView(switchRow("Click buttons (L / R strip)", start.mouseButtons) { v -> update(cur.copy(mouseButtons = v)) })
    return col
}
