package com.droidcontroller

import android.content.Context
import android.graphics.Color
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

/** Tiny helpers so the screens can be built in code without layout XML. */
fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.label(text: String, sizeSp: Float = 14f, bold: Boolean = false, color: Int = Color.WHITE): TextView =
    TextView(this).apply {
        this.text = text
        textSize = sizeSp
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(6), 0, dp(2))
    }

fun Context.button(text: String, onClick: () -> Unit): Button =
    Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

fun <T> Context.spinner(items: List<T>, selected: Int, name: (T) -> String, onPick: (T) -> Unit): Spinner =
    Spinner(this).apply {
        adapter = ArrayAdapter(this@spinner, android.R.layout.simple_spinner_dropdown_item, items.map(name))
        setSelection(selected.coerceAtLeast(0))
        var first = true // ignore the initial callback fired on layout
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (first) { first = false; return }
                onPick(items[pos])
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

fun Context.column(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(16), dp(16), dp(16), dp(16))
}

/** A section title with a thin divider above it, so groups of settings are visibly separate. */
fun Context.section(title: String, first: Boolean = false): LinearLayout =
    LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        if (!first) {
            addView(View(this@section).apply { setBackgroundColor(0x33FFFFFF) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply {
                    topMargin = dp(18)
                    bottomMargin = dp(6)
                })
        }
        addView(label(title, 16f, bold = true))
    }

/** Small compact button for toolbars. */
fun Context.chip(text: String, onClick: () -> Unit): Button =
    Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 11f
        minWidth = 0
        minimumWidth = 0
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(10), dp(4), dp(10), dp(4))
        setOnClickListener { onClick() }
    }

/**
 * The per-profile touch options: touch look (right stick), look sensitivity and invert,
 * floating left and right sticks, and the optional forward lock. [onChange] gets the new values after every tap.
 */
fun Context.touchOptionsView(start: TouchOpts, onChange: (TouchOpts) -> Unit): LinearLayout {
    var cur = start
    val grey = 0xFFAAAAAA.toInt()
    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    fun update(n: TouchOpts) { cur = n; onChange(n) }
    fun sw(text: String, on: Boolean, f: (TouchOpts, Boolean) -> TouchOpts) = Switch(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        isChecked = on
        setPadding(0, dp(6), 0, dp(6))
        setOnCheckedChangeListener { _, v -> update(f(cur, v)) }
    }
    var swLook: Switch? = null
    var swFloatR: Switch? = null
    swLook = sw("Touch look", start.lookOn) { o, v ->
        if (v) swFloatR?.isChecked = false
        o.copy(lookOn = v, floatRight = if (v) false else o.floatRight)
    }
    col.addView(swLook)
    val sens = label("", 12f, color = grey)
    fun showSens(v: Float) { sens.text = "Look sensitivity: %.1fx".format(v) }
    showSens(start.lookSens)
    col.addView(sens)
    col.addView(SeekBar(this).apply {
        max = 40 // 0.5x .. 2.5x in 0.05 steps
        progress = ((start.lookSens - 0.5f) / 0.05f).toInt().coerceIn(0, 40)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val v = 0.5f + p * 0.05f
                showSens(v)
                update(cur.copy(lookSens = v))
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    })
    col.addView(sw("Invert look", start.lookInvertY) { o, v -> o.copy(lookInvertY = v) })
    col.addView(sw("Floating left stick", start.floatLeft) { o, v -> o.copy(floatLeft = v) })
    swFloatR = sw("Floating right stick", start.floatRight) { o, v ->
        if (v) swLook?.isChecked = false
        o.copy(floatRight = v, lookOn = if (v) false else o.lookOn)
    }
    col.addView(swFloatR)
    col.addView(sw("Forward lock", start.lockForward) { o, v -> o.copy(lockForward = v) })
    return col
}
