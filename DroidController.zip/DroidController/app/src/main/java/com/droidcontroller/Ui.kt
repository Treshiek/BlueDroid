package com.droidcontroller

import android.content.Context
import android.graphics.Color
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

/** Tiny helpers so the screens can be built in code without layout XML. */
fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.label(text: String, sizeSp: Float = 14f, bold: Boolean = false, color: Int = Color.WHITE): TextView =
    TextView(this).apply {
        this.text = text
        textSize = sizeSp
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(6), 0, dp(2))
    }

fun Context.button(text: String, onClick: () -> Unit): Button =
    Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

fun <T> Context.spinner(items: List<T>, selected: Int, name: (T) -> String, onPick: (T) -> Unit): Spinner =
    Spinner(this).apply {
        adapter = ArrayAdapter(this@spinner, android.R.layout.simple_spinner_dropdown_item, items.map(name))
        setSelection(selected.coerceAtLeast(0))
        var first = true // ignore the initial callback fired on layout
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (first) { first = false; return }
                onPick(items[pos])
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

fun Context.column(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(16), dp(16), dp(16), dp(16))
}

/** Small compact button for toolbars. */
fun Context.chip(text: String, onClick: () -> Unit): Button =
    Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 11f
        minWidth = 0
        minimumWidth = 0
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(10), dp(4), dp(10), dp(4))
        setOnClickListener { onClick() }
    }

/**
 * The per-profile touch options: touch look (right stick), look sensitivity and invert,
 * floating left and right sticks, and the optional forward lock. [onChange] gets the new values after every tap.
 */
fun Context.touchOptionsView(start: TouchOpts, onChange: (TouchOpts) -> Unit): LinearLayout {
    var cur = start
    val grey = 0xFFAAAAAA.toInt()
    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    fun update(n: TouchOpts) { cur = n; onChange(n) }
    fun sw(text: String, on: Boolean, f: (TouchOpts, Boolean) -> TouchOpts) = Switch(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        isChecked = on
        setPadding(0, dp(6), 0, dp(6))
        setOnCheckedChangeListener { _, v -> update(f(cur, v)) }
    }
    var swLook: Switch? = null
    var swFloatR: Switch? = null
    swLook = sw("Touch look (right stick)", start.lookOn) { o, v ->
        if (v) swFloatR?.isChecked = false
        o.copy(lookOn = v, floatRight = if (v) false else o.floatRight)
    }
    col.addView(swLook)
    val sens = label("", 12f, color = grey)
    fun showSens(v: Float) { sens.text = "Look sensitivity: %.1fx".format(v) }
    showSens(start.lookSens)
    col.addView(sens)
    col.addView(SeekBar(this).apply {
        max = 40 // 0.5x .. 2.5x in 0.05 steps
        progress = ((start.lookSens - 0.5f) / 0.05f).toInt().coerceIn(0, 40)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val v = 0.5f + p * 0.05f
                showSens(v)
                update(cur.copy(lookSens = v))
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    })
    col.addView(sw("Invert look up / down", start.lookInvertY) { o, v -> o.copy(lookInvertY = v) })
    col.addView(sw("Floating left stick", start.floatLeft) { o, v -> o.copy(floatLeft = v) })
    swFloatR = sw("Floating right stick", start.floatRight) { o, v ->
        if (v) swLook?.isChecked = false
        o.copy(floatRight = v, lookOn = if (v) false else o.lookOn)
    }
    col.addView(swFloatR)
    col.addView(sw("Lock left stick forward", start.lockForward) { o, v -> o.copy(lockForward = v) })
    return col
}

/** The per-profile mouse options: cursor speed, acceleration and scroll direction. [onChange] gets the new values after every tap. */
fun Context.mouseOptionsView(start: MouseOpts, onChange: (MouseOpts) -> Unit): LinearLayout {
    var cur = start
    val grey = 0xFFAAAAAA.toInt()
    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    fun update(n: MouseOpts) { cur = n; onChange(n) }
    fun sw(text: String, on: Boolean, f: (MouseOpts, Boolean) -> MouseOpts) = Switch(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        isChecked = on
        setPadding(0, dp(6), 0, dp(6))
        setOnCheckedChangeListener { _, v -> update(f(cur, v)) }
    }
    val sens = label("", 12f, color = grey)
    fun showSens(v: Float) { sens.text = "Cursor speed: %.2fx".format(v) }
    showSens(start.sens)
    col.addView(sens)
    col.addView(SeekBar(this).apply {
        max = 54 // 0.3x .. 3.0x in 0.05 steps
        progress = ((start.sens - 0.3f) / 0.05f).toInt().coerceIn(0, 54)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val v = 0.3f + p * 0.05f
                showSens(v)
                update(cur.copy(sens = v))
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    })
    col.addView(sw("Pointer acceleration (fast swipes go further)", start.accel) { o, v -> o.copy(accel = v) })
    col.addView(sw("Natural scrolling (page follows your fingers)", start.natural) { o, v -> o.copy(natural = v) })
    col.addView(label("One finger moves the cursor. Tap = left click, two-finger tap = right click, " +
        "two fingers up / down = scroll, tap then drag = click and drag.", 12f, color = grey))
    return col
}
