package com.droidcontroller

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Edits a profile directly on the controller: drag a control to move it, pinch (or +/−) to resize it,
 * Remap to choose what it sends (any gamepad button, trigger, stick or D-pad), Hide/Show to remove clutter.
 * Changes are saved as you go.
 */
class EditorActivity : Activity() {

    private lateinit var store: ProfileStore
    private lateinit var profile: Profile
    private lateinit var view: ControllerView
    private lateinit var bottom: LinearLayout
    private var selected: String? = null

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        window.attributes = window.attributes.also {
            it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        store = ProfileStore(this)
        profile = store.get(intent.getStringExtra("profile") ?: store.current)

        val root = FrameLayout(this)
        view = ControllerView(this, profile.skin, profile.controls, true, Settings(this), profile.touch, onEdit = { list, sel, changed ->
            selected = sel
            if (changed) {
                profile = profile.copy(controls = list)
                store.upsert(profile)
            }
            refreshBottom(list)
        })
        root.addView(view)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xAA000000.toInt())
            setPadding(dp(8), dp(2), dp(8), dp(2))
        }
        top.addView(label("Editing: ${profile.name}", 13f, bold = true))
        top.addView(chip("Look") { pickSkin() })
        top.addView(chip("Touch") { touchDialog() })
        top.addView(chip("Motion & keys") { motionDialog() })
        top.addView(chip("Save as…") { saveAs() })
        top.addView(chip("Reset") { resetLayout() })
        if (!store.isBuiltin(profile.name)) top.addView(chip("Delete") { deleteProfile() })
        top.addView(chip("Done") { finish() })
        root.addView(top, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xAA000000.toInt())
            setPadding(dp(8), dp(2), dp(8), dp(2))
        }
        root.addView(bottom, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        setContentView(root)
        refreshBottom(profile.controls)
    }

    private fun refreshBottom(list: List<Control>) {
        bottom.removeAllViews()
        val c = list.firstOrNull { it.id == selected }
        if (c == null) {
            bottom.addView(label("Tap a control. Drag to move it, pinch or use + / − to resize.", 12f, color = 0xFFCCCCCC.toInt()))
            return
        }
        bottom.addView(label("${c.id.replace('_', ' ')}  →  ${Outputs.display(profile.skin, c.out)}" +
            if (c.visible) "" else "  (hidden)", 13f, bold = true))
        bottom.addView(chip("Remap") { remap(c) })
        if (c.kind == Kind.BUTTON) bottom.addView(chip(if (c.icon.isEmpty()) "Icon" else "Icon: " + Icons.nameOf(c.icon)) { pickIcon(c) })
        bottom.addView(chip("−") { view.resizeSelected(0.9f); view.commit() })
        bottom.addView(chip("+") { view.resizeSelected(1.1f); view.commit() })
        bottom.addView(chip(if (c.visible) "Hide" else "Show") { view.toggleVisible(c.id) })
    }

    private fun remap(c: Control) {
        val options = Outputs.options(c.kind)
        AlertDialog.Builder(this)
            .setTitle("What should ${c.id.replace('_', ' ')} send?")
            .setItems(options.map { it.label }.toTypedArray()) { _, i -> view.setOut(c.id, options[i].code) }
            .show()
    }

    /** Pick a picture for a button instead of its text. What the button sends does not change. */
    private fun pickIcon(c: Control) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        var dialog: AlertDialog? = null
        fun row(id: String, name: String) {
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
                setOnClickListener { view.setIcon(c.id, id); dialog?.dismiss() }
            }
            r.addView(IconPreview(this, id), LinearLayout.LayoutParams(dp(40), dp(40)))
            r.addView(label(name, 15f), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(12) })
            col.addView(r)
        }
        row("", "None (show text)")
        Icons.all.forEach { row(it.id, it.name) }
        dialog = AlertDialog.Builder(this).setTitle("Icon for ${c.id.replace('_', ' ')}")
            .setView(android.widget.ScrollView(this).apply { addView(col) })
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Tilt and volume keys have no spot on the screen, so they are mapped from here. */
    private fun motionDialog() {
        val items = listOf(
            "TILT_X" to "Tilt left / right",
            "TILT_Y" to "Tilt forward / back",
            "VOL_UP" to "Volume up key",
            "VOL_DOWN" to "Volume down key"
        )
        val now = view.controls()
        val names = items.map { (id, name) ->
            val out = now.firstOrNull { it.id == id }?.out ?: "OFF"
            "$name  →  ${Outputs.display(profile.skin, out)}"
        }
        AlertDialog.Builder(this)
            .setTitle("Motion & keys")
            .setItems(names.toTypedArray()) { _, i ->
                now.firstOrNull { it.id == items[i].first }?.let { remap(it) }
            }
            .show()
    }

    /** Touch look, floating left stick and lock: saved with this profile. */
    private fun touchDialog() {
        val body = touchOptionsView(profile.touch) { t ->
            profile = profile.copy(touch = t)
            store.upsert(profile)
            view.setTouch(t)
        }
        body.setPadding(dp(20), dp(8), dp(20), dp(8))
        AlertDialog.Builder(this).setTitle("Touch controls for \"${profile.name}\"")
            .setView(android.widget.ScrollView(this).apply { addView(body) })
            .setPositiveButton("Done", null)
            .show()
    }

    private fun pickSkin() {
        val skins = Skin.values()
        val names = skins.map { Skins.title(it) }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Look (labels and colours)")
            .setItems(names) { _, i ->
                view.setSkin(skins[i])
                profile = profile.copy(skin = skins[i])
                store.upsert(profile)
                refreshBottom(view.controls())
            }.show()
    }

    private fun saveAs() {
        val input = EditText(this).apply {
            hint = "Profile name"
            inputType = InputType.TYPE_CLASS_TEXT
            setTextColor(Color.WHITE)
        }
        AlertDialog.Builder(this).setTitle("Save a copy as…").setView(input)
            .setPositiveButton("Save") { _, _ ->
                val base = input.text.toString().trim().ifEmpty { "${profile.name} copy" }
                val names = store.all().map { it.name }.toSet()
                var name = base
                var n = 2
                while (name in names) name = "$base $n".also { n++ }
                val copy = profile.copy(name = name, controls = view.controls())
                store.upsert(copy)
                store.current = name
                intent.putExtra("profile", name)
                recreate()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun resetLayout() {
        AlertDialog.Builder(this).setTitle("Reset layout?")
            .setMessage("Puts every control back to where it started for this profile.")
            .setPositiveButton("Reset") { _, _ ->
                val fresh = store.defaultFor(profile.name)?.controls ?: Layouts.gamepad(false)
                view.reset(fresh)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteProfile() {
        AlertDialog.Builder(this).setTitle("Delete \"${profile.name}\"?")
            .setPositiveButton("Delete") { _, _ ->
                store.delete(profile.name)
                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
