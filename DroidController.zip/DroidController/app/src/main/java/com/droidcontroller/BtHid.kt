package com.droidcontroller

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import kotlin.math.roundToInt

/**
 * HID report descriptor for a gamepad laid out like the Xbox One S / Xbox Wireless Controller
 * (16-bit sticks on X/Y/Z/Rz, 10-bit triggers as Brake/Accelerator, hat switch, 15 buttons).
 * Report ID 1, 15 bytes of payload.
 *
 * NOTE: this copies the *layout*, not the identity. Android does not let an app set the
 * USB/Bluetooth vendor and product ID, so hosts see a generic gamepad, not literally an Xbox pad.
 */
object HidGamepad {
    const val REPORT_ID = 1

    val DESCRIPTOR: ByteArray = intArrayOf(
        0x05, 0x01,             // Usage Page (Generic Desktop)
        0x09, 0x05,             // Usage (Game Pad)
        0xA1, 0x01,             // Collection (Application)
        0x85, REPORT_ID,        //   Report ID
        // Left stick: X, Y (16 bit)
        0x09, 0x01, 0xA1, 0x00,
        0x09, 0x30, 0x09, 0x31,
        0x15, 0x00, 0x27, 0xFF, 0xFF, 0x00, 0x00,
        0x95, 0x02, 0x75, 0x10, 0x81, 0x02,
        0xC0,
        // Right stick: Z, Rz (16 bit)
        0x09, 0x01, 0xA1, 0x00,
        0x09, 0x32, 0x09, 0x35,
        0x15, 0x00, 0x27, 0xFF, 0xFF, 0x00, 0x00,
        0x95, 0x02, 0x75, 0x10, 0x81, 0x02,
        0xC0,
        // Left trigger: Brake (10 bit + 6 pad)
        0x05, 0x02, 0x09, 0xC5,
        0x15, 0x00, 0x26, 0xFF, 0x03,
        0x95, 0x01, 0x75, 0x0A, 0x81, 0x02,
        0x15, 0x00, 0x25, 0x00, 0x75, 0x06, 0x95, 0x01, 0x81, 0x03,
        // Right trigger: Accelerator (10 bit + 6 pad)
        0x05, 0x02, 0x09, 0xC4,
        0x15, 0x00, 0x26, 0xFF, 0x03,
        0x95, 0x01, 0x75, 0x0A, 0x81, 0x02,
        0x15, 0x00, 0x25, 0x00, 0x75, 0x06, 0x95, 0x01, 0x81, 0x03,
        // D-pad: hat switch (4 bit + 4 pad), 0 = released, 1..8 = N..NW
        0x05, 0x01, 0x09, 0x39,
        0x15, 0x01, 0x25, 0x08,
        0x35, 0x00, 0x46, 0x3B, 0x01, 0x66, 0x14, 0x00,
        0x75, 0x04, 0x95, 0x01, 0x81, 0x42,
        0x75, 0x04, 0x95, 0x01, 0x15, 0x00, 0x25, 0x00, 0x35, 0x00, 0x45, 0x00, 0x65, 0x00, 0x81, 0x03,
        // 15 buttons + 1 pad bit
        0x05, 0x09, 0x19, 0x01, 0x29, 0x0F,
        0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x0F, 0x81, 0x02,
        0x75, 0x01, 0x95, 0x01, 0x15, 0x00, 0x25, 0x00, 0x81, 0x03,
        0xC0                    // End Collection
    ).map { it.toByte() }.toByteArray()

    private fun axis16(v: Float): Int = ((v.coerceIn(-1f, 1f) * 127f).roundToInt() + 127) * 65535 / 254
    private fun trig10(v: Float): Int = (v.coerceIn(0f, 1f) * 255f).roundToInt() * 1023 / 255

    /** 15-byte report. Values are slightly quantised so tiny sensor noise doesn't flood Bluetooth. */
    fun report(s: GamepadState): ByteArray {
        val out = ByteArray(15)
        fun put16(i: Int, v: Int) { out[i] = (v and 0xFF).toByte(); out[i + 1] = ((v shr 8) and 0xFF).toByte() }
        put16(0, axis16(s.lx))
        put16(2, axis16(s.ly))
        put16(4, axis16(s.rx))
        put16(6, axis16(s.ry))
        put16(8, trig10(s.lt))
        put16(10, trig10(s.rt))
        out[12] = (s.hat and 0x0F).toByte()
        put16(13, s.buttons and 0x7FFF)
        return out
    }
}

/** Makes this phone act as a real Bluetooth gamepad (Android 9+ "HID Device" profile). */
@SuppressLint("MissingPermission")
object BtHid {
    private val ui = Handler(Looper.getMainLooper())
    private var proxy: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private var lastReport: ByteArray? = null

    var status: String = "Bluetooth gamepad is off"
        private set
    var listener: ((String) -> Unit)? = null

    private fun set(msg: String) {
        status = msg
        ui.post { listener?.invoke(msg) }
    }

    val connected: Boolean get() = host != null

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            set(if (registered) "Gamepad ready. Pair or connect from the other device." else "Gamepad registration failed or was removed")
        }

        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> {
                    host = device
                    lastReport = null
                    set("Connected to ${device?.name ?: "device"}")
                }
                BluetoothProfile.STATE_CONNECTING -> set("Connecting…")
                BluetoothProfile.STATE_DISCONNECTED -> {
                    if (device == host) host = null
                    set("Disconnected. Gamepad still visible to hosts.")
                }
            }
        }
    }

    /** Needs BLUETOOTH_CONNECT granted on Android 12+. */
    fun start(ctx: Context) {
        val adapter = ctx.getSystemService(BluetoothManager::class.java)?.adapter
        if (adapter == null || !adapter.isEnabled) {
            set("Turn Bluetooth on first")
            return
        }
        if (proxy != null) { register(); return }
        val ok = adapter.getProfileProxy(ctx.applicationContext, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, p: BluetoothProfile) {
                proxy = p as BluetoothHidDevice
                register()
            }

            override fun onServiceDisconnected(profile: Int) {
                proxy = null
                host = null
                set("Bluetooth gamepad service stopped")
            }
        }, BluetoothProfile.HID_DEVICE)
        if (!ok) set("This phone does not support Bluetooth gamepad mode")
    }

    private fun register() {
        val sdp = BluetoothHidDeviceAppSdpSettings(
            "DroidController", "Gamepad", "DroidController",
            BluetoothHidDevice.SUBCLASS2_GAMEPAD, HidGamepad.DESCRIPTOR
        )
        val ok = proxy?.registerApp(sdp, null, null, Executors.newSingleThreadExecutor(), callback) ?: false
        if (!ok) set("Could not register the gamepad (some phones block this)")
    }

    fun bonded(ctx: Context): List<BluetoothDevice> =
        ctx.getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices?.toList() ?: emptyList()

    fun connect(d: BluetoothDevice) {
        if (proxy?.connect(d) != true) set("Could not start connection")
    }

    fun send(s: GamepadState) {
        val h = host ?: return
        val r = HidGamepad.report(s)
        if (lastReport?.contentEquals(r) == true) return
        lastReport = r
        proxy?.sendReport(h, HidGamepad.REPORT_ID, r)
    }

    fun stop() {
        proxy?.unregisterApp()
        host = null
        set("Bluetooth gamepad is off")
    }
}
