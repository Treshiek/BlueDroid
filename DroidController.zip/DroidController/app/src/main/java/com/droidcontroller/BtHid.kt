package com.droidcontroller

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import kotlin.math.roundToInt

/**
 * HID report descriptor for a gamepad laid out like the Xbox One S / Xbox Wireless Controller
 * (16-bit sticks on X/Y/Z/Rz, 10-bit triggers as Brake/Accelerator, hat switch, 15 buttons).
 * Report ID 1, 15 bytes of payload.
 *
 * NOTE: this copies the *layout*, not the identity. Android does not let an app set the
 * USB/Bluetooth vendor and product ID, so hosts see a generic gamepad, not literally an Xbox pad.
 */
object HidGamepad {
    const val REPORT_ID = 1
    const val RUMBLE_ID = 3
    const val TOUCHPAD_ID = 2
    const val TOUCHPAD_FEATURE_ID = 4
    const val TP_MAX_X = 4095
    const val TP_MAX_Y = 2047

    val DESCRIPTOR: ByteArray = intArrayOf(
        0x05, 0x01,             // Usage Page (Generic Desktop)
        0x09, 0x05,             // Usage (Game Pad)
        0xA1, 0x01,             // Collection (Application)
        0x85, REPORT_ID,        //   Report ID
        // Left stick: X, Y (16 bit)
        0x09, 0x01, 0xA1, 0x00,
        0x09, 0x30, 0x09, 0x31,
        0x15, 0x00, 0x27, 0xFF, 0xFF, 0x00, 0x00,
        0x95, 0x02, 0x75, 0x10, 0x81, 0x02,
        0xC0,
        // Right stick: Z, Rz (16 bit)
        0x09, 0x01, 0xA1, 0x00,
        0x09, 0x32, 0x09, 0x35,
        0x15, 0x00, 0x27, 0xFF, 0xFF, 0x00, 0x00,
        0x95, 0x02, 0x75, 0x10, 0x81, 0x02,
        0xC0,
        // Left trigger: Brake (10 bit + 6 pad)
        0x05, 0x02, 0x09, 0xC5,
        0x15, 0x00, 0x26, 0xFF, 0x03,
        0x95, 0x01, 0x75, 0x0A, 0x81, 0x02,
        0x15, 0x00, 0x25, 0x00, 0x75, 0x06, 0x95, 0x01, 0x81, 0x03,
        // Right trigger: Accelerator (10 bit + 6 pad)
        0x05, 0x02, 0x09, 0xC4,
        0x15, 0x00, 0x26, 0xFF, 0x03,
        0x95, 0x01, 0x75, 0x0A, 0x81, 0x02,
        0x15, 0x00, 0x25, 0x00, 0x75, 0x06, 0x95, 0x01, 0x81, 0x03,
        // D-pad: hat switch (4 bit + 4 pad), 0 = released, 1..8 = N..NW
        0x05, 0x01, 0x09, 0x39,
        0x15, 0x01, 0x25, 0x08,
        0x35, 0x00, 0x46, 0x3B, 0x01, 0x66, 0x14, 0x00,
        0x75, 0x04, 0x95, 0x01, 0x81, 0x42,
        0x75, 0x04, 0x95, 0x01, 0x15, 0x00, 0x25, 0x00, 0x35, 0x00, 0x45, 0x00, 0x65, 0x00, 0x81, 0x03,
        // 15 buttons + 1 pad bit
        0x05, 0x09, 0x19, 0x01, 0x29, 0x0F,
        0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x0F, 0x81, 0x02,
        0x75, 0x01, 0x95, 0x01, 0x15, 0x00, 0x25, 0x00, 0x81, 0x03,
        // Rumble output report (ID 3), same layout as the Xbox One S: enable, 4 magnitudes, duration, delay, loop
        0x05, 0x0F, 0x09, 0x21, 0xA1, 0x02,
        0x85, RUMBLE_ID,
        0x09, 0x97, 0x15, 0x00, 0x25, 0x01, 0x75, 0x04, 0x95, 0x01, 0x91, 0x02,
        0x15, 0x00, 0x25, 0x00, 0x75, 0x04, 0x95, 0x01, 0x91, 0x03,
        0x09, 0x70, 0x15, 0x00, 0x25, 0x64, 0x75, 0x08, 0x95, 0x04, 0x91, 0x02,
        0x09, 0x50, 0x66, 0x01, 0x10, 0x55, 0x0E, 0x15, 0x00, 0x26, 0xFF, 0x00, 0x75, 0x08, 0x95, 0x01, 0x91, 0x02,
        0x09, 0xA7, 0x66, 0x01, 0x10, 0x55, 0x0E, 0x15, 0x00, 0x26, 0xFF, 0x00, 0x75, 0x08, 0x95, 0x01, 0x91, 0x02,
        0x65, 0x00, 0x55, 0x00,
        0x09, 0x7C, 0x15, 0x00, 0x26, 0xFF, 0x00, 0x75, 0x08, 0x95, 0x01, 0x91, 0x02,
        0xC0,
        0xC0                    // End Collection
    ).map { it.toByte() }.toByteArray()

    /**
     * Optional second top-level device: a one-finger touchpad (Digitizer / Touch Pad, report ID 2), so the other
     * device lists a touchpad next to the gamepad. 4 x 2 inch surface (same 2:1 shape as the on-screen pad).
     * Report: tip switch (+7 pad bits), contact id, X (16 bit), Y (16 bit), contact count = 7 bytes.
     * Feature report ID 4 answers "Contact Count Maximum" (1).
     */
    private val TOUCHPAD_PART: ByteArray = intArrayOf(
        0x05, 0x0D, 0x09, 0x05, 0xA1, 0x01,                    // Usage Page (Digitizers), Usage (Touch Pad), Collection (Application)
        0x85, TOUCHPAD_ID,                                     //   Report ID
        0x09, 0x22, 0xA1, 0x02,                                //   Usage (Finger), Collection (Logical)
        0x09, 0x42, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x01, 0x81, 0x02,   // Tip Switch
        0x75, 0x07, 0x95, 0x01, 0x81, 0x03,                    //     7 pad bits
        0x09, 0x51, 0x15, 0x00, 0x25, 0x0F, 0x75, 0x08, 0x95, 0x01, 0x81, 0x02,   // Contact Identifier
        0x05, 0x01, 0x09, 0x30, 0x15, 0x00, 0x26, 0xFF, 0x0F,  //     X: 0..4095
        0x35, 0x00, 0x46, 0x90, 0x01, 0x55, 0x0E, 0x65, 0x13,  //        physical 0..4.00 in
        0x75, 0x10, 0x95, 0x01, 0x81, 0x02,
        0x09, 0x31, 0x26, 0xFF, 0x07, 0x46, 0xC8, 0x00, 0x81, 0x02,               // Y: 0..2047, 0..2.00 in
        0xC0,                                                  //   End finger collection
        0x65, 0x00, 0x55, 0x00,                                //   no unit for the counts below
        0x05, 0x0D, 0x09, 0x54, 0x15, 0x00, 0x25, 0x05, 0x75, 0x08, 0x95, 0x01, 0x81, 0x02,  // Contact Count
        0x85, TOUCHPAD_FEATURE_ID,                             //   Feature report
        0x09, 0x55, 0x25, 0x01, 0xB1, 0x02,                    //   Contact Count Maximum = 1
        0xC0
    ).map { it.toByte() }.toByteArray()

    /** The gamepad alone, or the gamepad plus the touchpad. */
    fun descriptor(withTouchpad: Boolean): ByteArray = if (withTouchpad) DESCRIPTOR + TOUCHPAD_PART else DESCRIPTOR

    /** 7-byte touchpad report. [x] and [y] are 0..1 across the pad. */
    fun touchpadReport(down: Boolean, x: Float, y: Float): ByteArray {
        val xi = (x.coerceIn(0f, 1f) * TP_MAX_X).roundToInt()
        val yi = (y.coerceIn(0f, 1f) * TP_MAX_Y).roundToInt()
        return byteArrayOf(
            if (down) 1 else 0, 0,
            (xi and 0xFF).toByte(), ((xi shr 8) and 0xFF).toByte(),
            (yi and 0xFF).toByte(), ((yi shr 8) and 0xFF).toByte(),
            if (down) 1 else 0
        )
    }

    private fun axis16(v: Float): Int = ((v.coerceIn(-1f, 1f) * 127f).roundToInt() + 127) * 65535 / 254
    private fun trig10(v: Float): Int = (v.coerceIn(0f, 1f) * 255f).roundToInt() * 1023 / 255

    /** 15-byte report. Values are slightly quantised so tiny sensor noise doesn't flood Bluetooth. */
    fun report(s: GamepadState): ByteArray {
        val out = ByteArray(15)
        fun put16(i: Int, v: Int) { out[i] = (v and 0xFF).toByte(); out[i + 1] = ((v shr 8) and 0xFF).toByte() }
        put16(0, axis16(s.lx))
        put16(2, axis16(s.ly))
        put16(4, axis16(s.rx))
        put16(6, axis16(s.ry))
        put16(8, trig10(s.lt))
        put16(10, trig10(s.rt))
        out[12] = (s.hat and 0x0F).toByte()
        put16(13, s.buttons and 0x7FFF)
        return out
    }
}

/** Makes this phone act as a real Bluetooth gamepad (Android 9+ "HID Device" profile). */
@SuppressLint("MissingPermission")
object BtHid {
    private val ui = Handler(Looper.getMainLooper())
    private var proxy: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private var lastReport: ByteArray? = null

    // Real touchpad (optional second HID device)
    private var wantTouchpad = false
    private var pendingRegister = false
    private var lastTouchpad: ByteArray? = null
    private var tpX = 0f
    private var tpY = 0f

    /** True when the gamepad is registered together with a touchpad, so touchpad reports reach the other device. */
    var touchpadReady: Boolean = false
        private set

    var status: String = "Bluetooth gamepad is off"
        private set
    var listener: ((String) -> Unit)? = null

    private fun set(msg: String) {
        status = msg
        ui.post { listener?.invoke(msg) }
    }

    val connected: Boolean get() = host != null

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            if (!registered && pendingRegister) { // switching between gamepad and gamepad + touchpad: register again
                pendingRegister = false
                register()
                return
            }
            touchpadReady = registered && wantTouchpad
            set(when {
                !registered -> "Gamepad registration failed or was removed"
                wantTouchpad -> "Gamepad + touchpad ready. Pair or connect from the other device."
                else -> "Gamepad ready. Pair or connect from the other device."
            })
        }

        override fun onGetReport(device: BluetoothDevice?, type: Byte, id: Byte, bufferSize: Int) {
            // The touchpad asks how many fingers it supports.
            if (type == BluetoothHidDevice.REPORT_TYPE_FEATURE && id.toInt() == HidGamepad.TOUCHPAD_FEATURE_ID) {
                proxy?.replyReport(device, type, id, byteArrayOf(1))
            }
        }

        override fun onSetReport(device: BluetoothDevice?, type: Byte, id: Byte, data: ByteArray?) {
            proxy?.reportError(device, BluetoothHidDevice.ERROR_RSP_SUCCESS)
        }

        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> {
                    host = device
                    lastReport = null
                    lastTouchpad = null
                    set("Connected to ${device?.name ?: "device"}")
                }
                BluetoothProfile.STATE_CONNECTING -> set("Connecting…")
                BluetoothProfile.STATE_DISCONNECTED -> {
                    if (device == host) host = null
                    set("Disconnected. Gamepad still visible to hosts.")
                }
            }
        }
    }

    /**
     * Needs BLUETOOTH_CONNECT granted on Android 12+.
     * [touchpad] = also present a real touchpad (see Settings.realTouchpad). Changing it re-registers the gamepad.
     */
    fun start(ctx: Context, touchpad: Boolean = false) {
        val adapter = ctx.getSystemService(BluetoothManager::class.java)?.adapter
        if (adapter == null || !adapter.isEnabled) {
            set("Turn Bluetooth on first")
            return
        }
        if (proxy != null) {
            if (touchpad != wantTouchpad) {
                wantTouchpad = touchpad
                touchpadReady = false
                pendingRegister = true
                proxy?.unregisterApp() // registers again from onAppStatusChanged
                ui.postDelayed({ if (pendingRegister) { pendingRegister = false; register() } }, 800) // in case that callback never comes
            } else register()
            return
        }
        wantTouchpad = touchpad
        val ok = adapter.getProfileProxy(ctx.applicationContext, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, p: BluetoothProfile) {
                proxy = p as BluetoothHidDevice
                register()
            }

            override fun onServiceDisconnected(profile: Int) {
                proxy = null
                host = null
                set("Bluetooth gamepad service stopped")
            }
        }, BluetoothProfile.HID_DEVICE)
        if (!ok) set("This phone does not support Bluetooth gamepad mode")
    }

    private fun register() {
        val sdp = BluetoothHidDeviceAppSdpSettings(
            "DroidController", "Gamepad", "DroidController",
            BluetoothHidDevice.SUBCLASS2_GAMEPAD, HidGamepad.descriptor(wantTouchpad)
        )
        val ok = proxy?.registerApp(sdp, null, null, Executors.newSingleThreadExecutor(), callback) ?: false
        if (!ok) set("Could not register the gamepad (some phones block this)")
    }

    fun bonded(ctx: Context): List<BluetoothDevice> =
        ctx.getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices?.toList() ?: emptyList()

    fun connect(d: BluetoothDevice) {
        if (proxy?.connect(d) != true) set("Could not start connection")
    }

    fun send(s: GamepadState) {
        val h = host ?: return
        val r = HidGamepad.report(s)
        if (lastReport?.contentEquals(r) != true) {
            lastReport = r
            proxy?.sendReport(h, HidGamepad.REPORT_ID, r)
        }
        if (touchpadReady) sendTouchpad(h, s)
    }

    /** Sends the finger position while it is down and one "finger lifted" report; nothing before the first touch. */
    private fun sendTouchpad(h: BluetoothDevice, s: GamepadState) {
        if (lastTouchpad == null && !s.tpDown) return
        if (s.tpDown) { tpX = s.tpX; tpY = s.tpY } // when lifted, keep the last position
        val t = HidGamepad.touchpadReport(s.tpDown, tpX, tpY)
        if (lastTouchpad?.contentEquals(t) == true) return
        lastTouchpad = t
        proxy?.sendReport(h, HidGamepad.TOUCHPAD_ID, t)
    }

    fun stop() {
        proxy?.unregisterApp()
        host = null
        touchpadReady = false
        set("Bluetooth gamepad is off")
    }
}
