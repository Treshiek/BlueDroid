package com.droidcontroller

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Game icons drawn in code (no image files), so they take the skin's colours.
 * Everything is drawn in a -1..1 box and scaled to the control.
 */
object Icons {
    class Icon(val id: String, val name: String)

    val all = listOf(
        Icon("JUMP", "Jump"), Icon("SPRINT", "Sprint"), Icon("CROUCH", "Crouch"),
        Icon("SLIDE", "Slide / dodge"), Icon("PRONE", "Prone"),
        Icon("SHOOT", "Shoot"), Icon("AIM", "Aim / scope"), Icon("RELOAD", "Reload"),
        Icon("MELEE", "Melee"), Icon("GRENADE", "Grenade"), Icon("SWAP", "Weapon swap"),
        Icon("BLOCK", "Block / shield"), Icon("ABILITY", "Special ability"),
        Icon("USE", "Interact / use"), Icon("INVENTORY", "Inventory"), Icon("MAP", "Map"),
        Icon("HEAL", "Heal"), Icon("FLASHLIGHT", "Flashlight"), Icon("VEHICLE", "Vehicle enter / exit"),
        Icon("PING", "Ping / mark"),
        Icon("GAS", "Gas"), Icon("BRAKE", "Brake"), Icon("NITRO", "Nitro"), Icon("HANDBRAKE", "Handbrake")
    )

    fun has(id: String) = all.any { it.id == id }
    fun nameOf(id: String) = all.firstOrNull { it.id == id }?.name ?: "None"

    private val st = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = .15f
    }
    private val fl = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val rect = RectF()

    /** Draws icon [id] centred at ([cx], [cy]); [r] is half its size in pixels. */
    fun draw(canvas: Canvas, id: String, cx: Float, cy: Float, r: Float, color: Int) {
        if (!has(id)) return
        st.color = color
        fl.color = color
        canvas.save()
        canvas.translate(cx, cy)
        canvas.scale(r, r)
        shape(canvas, id)
        canvas.restore()
    }

    private fun ln(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) = c.drawLine(x1, y1, x2, y2, st)

    private fun poly(c: Canvas, close: Boolean, vararg p: Float) {
        path.reset()
        path.moveTo(p[0], p[1])
        var i = 2
        while (i < p.size) { path.lineTo(p[i], p[i + 1]); i += 2 }
        if (close) path.close()
        c.drawPath(path, st)
    }

    private fun arrowHead(c: Canvas, x: Float, y: Float, dx: Float, dy: Float, size: Float = .38f) {
        val len = hypot(dx, dy)
        val ux = dx / len
        val uy = dy / len
        val nx = -uy
        val ny = ux
        poly(c, false,
            x - ux * size + nx * size, y - uy * size + ny * size,
            x, y,
            x - ux * size - nx * size, y - uy * size - ny * size)
    }

    private fun shape(c: Canvas, id: String) {
        when (id) {
            "JUMP" -> {
                ln(c, 0f, -.85f, 0f, .35f)
                arrowHead(c, 0f, -.85f, 0f, -1f, .5f)
                ln(c, -.65f, .8f, .65f, .8f)
            }
            "SPRINT" -> {
                poly(c, false, -.75f, -.6f, -.15f, 0f, -.75f, .6f)
                poly(c, false, .05f, -.6f, .65f, 0f, .05f, .6f)
            }
            "CROUCH" -> {
                ln(c, 0f, -.8f, 0f, .3f)
                arrowHead(c, 0f, .35f, 0f, 1f, .5f)
                ln(c, -.65f, .85f, .65f, .85f)
            }
            "SLIDE" -> {
                ln(c, -.5f, 0f, .75f, 0f)
                arrowHead(c, .75f, 0f, 1f, 0f, .5f)
                ln(c, -.9f, -.45f, -.35f, -.45f)
                ln(c, -.9f, .45f, -.35f, .45f)
            }
            "PRONE" -> {
                c.drawCircle(-.62f, -.05f, .2f, fl)
                ln(c, -.3f, .05f, .65f, .05f)
                ln(c, .65f, .05f, .9f, .4f)
                ln(c, -.9f, .65f, .9f, .65f)
            }
            "SHOOT" -> {
                path.reset()
                path.moveTo(-.28f, .55f)
                path.lineTo(-.28f, -.15f)
                path.quadTo(-.28f, -.65f, 0f, -.9f)
                path.quadTo(.28f, -.65f, .28f, -.15f)
                path.lineTo(.28f, .55f)
                path.close()
                c.drawPath(path, fl)
                ln(c, -.4f, .8f, .4f, .8f)
            }
            "AIM" -> {
                c.drawCircle(0f, 0f, .55f, st)
                ln(c, 0f, -.95f, 0f, -.3f); ln(c, 0f, .3f, 0f, .95f)
                ln(c, -.95f, 0f, -.3f, 0f); ln(c, .3f, 0f, .95f, 0f)
                c.drawCircle(0f, 0f, .1f, fl)
            }
            "RELOAD" -> {
                rect.set(-.6f, -.6f, .6f, .6f)
                c.drawArc(rect, -60f, 280f, false, st)
                val a = Math.toRadians(220.0)
                val px = (cos(a) * .6).toFloat()
                val py = (sin(a) * .6).toFloat()
                val dx = (-sin(a)).toFloat()
                val dy = cos(a).toFloat()
                path.reset()
                path.moveTo(px + dx * .4f, py + dy * .4f)
                path.lineTo(px - dy * .3f, py + dx * .3f)
                path.lineTo(px + dy * .3f, py - dx * .3f)
                path.close()
                c.drawPath(path, fl)
            }
            "MELEE" -> {
                ln(c, -.45f, .45f, .8f, -.8f)
                ln(c, -.03f, .67f, -.67f, .03f)
                ln(c, -.35f, .35f, -.8f, .8f)
            }
            "GRENADE" -> {
                c.drawCircle(0f, .25f, .55f, st)
                ln(c, 0f, -.3f, 0f, -.6f)
                ln(c, -.22f, -.6f, .22f, -.6f)
                ln(c, .22f, -.6f, .6f, -.3f)
                c.drawCircle(.62f, -.72f, .13f, st)
            }
            "SWAP" -> {
                ln(c, -.75f, -.35f, .75f, -.35f)
                arrowHead(c, .75f, -.35f, 1f, 0f, .4f)
                ln(c, .75f, .4f, -.75f, .4f)
                arrowHead(c, -.75f, .4f, -1f, 0f, .4f)
            }
            "BLOCK" -> {
                path.reset()
                path.moveTo(-.7f, -.7f)
                path.lineTo(.7f, -.7f)
                path.lineTo(.7f, .1f)
                path.quadTo(.7f, .7f, 0f, .95f)
                path.quadTo(-.7f, .7f, -.7f, .1f)
                path.close()
                c.drawPath(path, st)
                ln(c, 0f, -.5f, 0f, .65f)
            }
            "ABILITY" -> {
                path.reset()
                path.moveTo(.18f, -.95f)
                path.lineTo(-.55f, .1f)
                path.lineTo(-.05f, .1f)
                path.lineTo(-.2f, .95f)
                path.lineTo(.55f, -.2f)
                path.lineTo(.05f, -.2f)
                path.close()
                c.drawPath(path, fl)
            }
            "USE" -> {
                c.drawCircle(-.4f, -.35f, .38f, st)
                ln(c, -.12f, -.07f, .8f, .8f)
                ln(c, .45f, .45f, .72f, .18f)
                ln(c, .62f, .62f, .9f, .35f)
            }
            "INVENTORY" -> {
                rect.set(-.3f, -.95f, .3f, -.15f)
                c.drawArc(rect, 180f, 180f, false, st)
                rect.set(-.6f, -.45f, .6f, .9f)
                c.drawRoundRect(rect, .25f, .25f, st)
                ln(c, -.6f, .2f, .6f, .2f)
            }
            "MAP" -> {
                poly(c, true, -.85f, -.6f, -.3f, -.8f, .3f, -.6f, .85f, -.8f, .85f, .6f, .3f, .8f, -.3f, .6f, -.85f, .8f)
                ln(c, -.3f, -.8f, -.3f, .6f)
                ln(c, .3f, -.6f, .3f, .8f)
            }
            "HEAL" -> {
                c.drawCircle(0f, 0f, .92f, st)
                ln(c, 0f, -.5f, 0f, .5f)
                ln(c, -.5f, 0f, .5f, 0f)
            }
            "FLASHLIGHT" -> {
                poly(c, true, -.85f, -.22f, -.05f, -.22f, .35f, -.55f, .35f, .55f, -.05f, .22f, -.85f, .22f)
                ln(c, .62f, -.45f, .95f, -.65f)
                ln(c, .68f, 0f, 1f, 0f)
                ln(c, .62f, .45f, .95f, .65f)
            }
            "VEHICLE" -> {
                poly(c, true, -.9f, .3f, -.9f, -.05f, -.5f, -.12f, -.25f, -.5f, .4f, -.5f, .65f, -.1f, .9f, 0f, .9f, .3f)
                c.drawCircle(-.5f, .38f, .2f, fl)
                c.drawCircle(.5f, .38f, .2f, fl)
            }
            "PING" -> {
                c.drawCircle(0f, -.3f, .55f, st)
                poly(c, false, -.5f, -.02f, 0f, .95f, .5f, -.02f)
                c.drawCircle(0f, -.3f, .18f, fl)
            }
            "GAS" -> {
                poly(c, true, -.45f, -.9f, .45f, -.9f, .58f, .9f, -.58f, .9f)
                ln(c, -.3f, -.4f, .3f, -.4f)
                ln(c, -.33f, .05f, .33f, .05f)
                ln(c, -.38f, .5f, .38f, .5f)
            }
            "BRAKE" -> {
                rect.set(-.88f, -.45f, .88f, .45f)
                c.drawRoundRect(rect, .2f, .2f, st)
                ln(c, -.4f, -.25f, -.4f, .25f)
                ln(c, 0f, -.25f, 0f, .25f)
                ln(c, .4f, -.25f, .4f, .25f)
            }
            "NITRO" -> {
                path.reset()
                path.moveTo(.1f, -.95f)
                path.cubicTo(.9f, -.2f, .85f, .3f, .5f, .62f)
                path.cubicTo(.35f, .92f, -.4f, .92f, -.6f, .5f)
                path.cubicTo(-.9f, 0f, -.3f, -.3f, -.2f, -.6f)
                path.cubicTo(0f, -.45f, .05f, -.7f, .1f, -.95f)
                path.close()
                c.drawPath(path, fl)
            }
            "HANDBRAKE" -> {
                c.drawCircle(0f, 0f, .55f, st)
                ln(c, 0f, -.28f, 0f, .12f)
                c.drawCircle(0f, .32f, .08f, fl)
                rect.set(-.95f, -.95f, .95f, .95f)
                c.drawArc(rect, 125f, 110f, false, st)
                c.drawArc(rect, -55f, 110f, false, st)
            }
        }
    }
}

/** Small view that draws one icon, used in the icon picker. */
class IconPreview(ctx: Context, private val id: String) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f }

    override fun onDraw(canvas: Canvas) {
        val r = minOf(width, height) / 2f * .8f
        if (id.isEmpty()) {
            p.color = 0xFF888888.toInt()
            canvas.drawText("Aa", width / 2f - r * .5f, height / 2f + r * .3f, p.apply { style = Paint.Style.FILL; textSize = r })
        } else Icons.draw(canvas, id, width / 2f, height / 2f, r, 0xFFFFFFFF.toInt())
    }
}
